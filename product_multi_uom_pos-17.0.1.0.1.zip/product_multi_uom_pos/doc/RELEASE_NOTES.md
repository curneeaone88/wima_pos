## Module <product_multi_uom_pos>

#### 08.01.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for POS Product Multiple UOM

#### 9.05.2024
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix-Resolved the issue in the refund page.

#### 13.06.2024
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix-Resolved the issue in the picking 