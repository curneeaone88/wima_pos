## Module <total_quantity_pos>

#### 15.05.2024
#### Version 17.0.1.0.0
#### ADD
Initial Commit for Total Items and Total Quantity in POS.
