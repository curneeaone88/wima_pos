from odoo import models, fields, _, api
from odoo.tools import drop_view_if_exists
from odoo.exceptions import UserError

class WorkOrderLineProduct(models.Model):
    _name = 'work.order.line.product'
    _description = 'Work Order Line by Product'
    _auto = False

    sale_quotation_id = fields.Many2one(
        'sale.quotation'
    )
    sale_order_id = fields.Many2one(
        'sale.order'
    )
    work_order_id = fields.Many2one(
        'work.order'
    )
    product_template_id = fields.Many2one(
        comodel_name='product.template'
    )
    type = fields.Selection(
        selection=[
            ('recurring', 'Recurring'),
            ('one_time', 'One Time Fee')
        ],
        compute='_compute_type'
    )
    quantity = fields.Integer(
        default=0
    )

    def _compute_type(self):
        for rec in self:
            if rec.product_template_id.recurring_invoice:
                rec.type = 'recurring'
            else:
                rec.type = 'one_time'

    def init(self):
        drop_view_if_exists(self.env.cr, 'work_order_line_product')
        self.env.cr.execute("SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'work_order_line') AS table_existence;")
        (check_table_dependency, ) = self.env.cr.fetchone()
        if not check_table_dependency:
            return
        self.env.cr.execute("""
            CREATE VIEW work_order_line_product AS (
                select 
                    row_number() over (order by wol.work_order_id, pp.product_tmpl_id) id,
                    sql2.quotation_id as sale_quotation_id,
                    sl.sale_order_id,
                    wol.work_order_id,
                    pp.product_tmpl_id product_template_id,
                    count(sl.id) quantity 
                from work_order_line wol 
                    left join work_order_line_2_subscription_line_rel wolslr on wolslr.work_order_line_id = wol.id
                    left join subscription_line sl on sl.id = wolslr.subscription_line_id 
                    left join sale_quotation_line sql2 on sql2.id = sl.quotation_line_id 
                    left join product_product pp on pp.id = sql2.product_id 
                group by wol.work_order_id, sl.sale_order_id, sql2.quotation_id, pp.product_tmpl_id
            )
                            """)


class WorkOrderLine(models.Model):
    _name = 'work.order.line'
    _description = 'Planned Fleet / Container'
    
    name = fields.Char(
        string='Identifier',
        required=True
    )
    type = fields.Selection(
        selection=[
            ('vehicle', 'Vehicle'),
            ('container', 'Container'),
            ('user', 'User'),
            ('domain', 'Domain'),
        ],
        default='vehicle',
        required=True
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        default=lambda self: self.env.company)
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        domain="[('company_id', 'in', (False, company_id))]")

    identifier = fields.Many2one(
        comodel_name='entity.asset',
        string='Existing Identifier'
    )
    new_identifier = fields.Many2one(
        comodel_name='entity.asset',
        string='New Identifier'
    )
    work_order_id = fields.Many2one(
        comodel_name='work.order',
        ondelete='cascade'
    )
    after_sale_order_line_id = fields.Many2one(
        comodel_name='after.sale.order.line'
    )
    after_sale_order_id = fields.Many2one(
        related='after_sale_order_line_id.after_sale_order_id'
    )
    partner_domain_id = fields.Many2one(
        related='identifier.partner_domain_id'
    )
    assigned_owner_id = fields.Many2one(
        comodel_name='res.partner',
        related='work_order_id.assigned_owner_id'
    )
    subscription_line_ids = fields.Many2many(
        comodel_name='subscription.line',
        relation='work_order_line_2_subscription_line_rel',
        string='Product'
    )
    inventory_transfers = fields.One2many(
        comodel_name='work.order.line.transfer',
        inverse_name='work_order_line_id',
        string='Component Transfer'
    )
    inventory_transfer_id = fields.Many2one(
        comodel_name='stock.picking',
        compute='_compute_inventory_transfer_id',
    )
    inventory_pickings = fields.One2many(
        comodel_name='stock.picking',
        compute='_compute_inventory_pickings',
    )
    inventory_transfer_state = fields.Selection(
        selection=lambda x: x.env['stock.picking']._fields['state'].selection,
        compute='_compute_inventory_transfer_state'
    )
    note = fields.Text()

    @api.onchange('identifier')
    def _onchange_identifier(self):
        if len(self.identifier) == 1:
            self.name = self.identifier.name
            self.type = self.identifier.type
            self.company_id = self.identifier.company_id.id
            self.partner_id = self.identifier.partner_id.id
        else:
            self.name = False
            self.company_id = self.work_order_id.company_id.id
            self.partner_id = self.work_order_id.partner_id.id
    
    @api.onchange('name', 'type')
    def _onchange_name(self):
        if self.name == False or len(self.name) == 0:
            return
    
        existing_identifier = self.env['entity.asset'].search([
            ('name', '=', self.name.strip()),
            ('type', '=', self.type),
            ('company_id', '=', self.work_order_id.company_id.id),
            ('partner_id', '=', self.work_order_id.partner_id.id),
        ])
        if len(existing_identifier) == 1:
            if len(self.work_order_id.partner_domain_id) > 0 and existing_identifier.partner_domain_id.id != self.work_order_id.partner_domain_id.id:
                raise UserError(f"Sorry, {self.name.strip()} already registered on domain {existing_identifier.partner_domain_id.name}, please check the Customer Domain.")
            self.identifier = existing_identifier
    
    def check_identifier(self):
        self._onchange_name()
    
    @api.depends('work_order_id')
    def _compute_inventory_transfer_id(self):
        for rec in self:
            rec.inventory_transfer_id = False
            if rec.work_order_id.state == 'draft':
                continue
            picking = self.env['stock.picking'].search([
                ('work_order_line_id', '=', rec.id)
            ], limit=1)
            if len(picking) == 1:
                rec.inventory_transfer_id = picking
    
    @api.depends('work_order_id')
    def _compute_inventory_pickings(self):
        for rec in self:
            rec.inventory_pickings = self.env['stock.picking'].browse()
            if rec.work_order_id.state == 'draft':
                continue
            pickings = self.env['stock.picking'].search([
                ('work_order_line_id', '=', rec.id)
            ])
            for p in pickings:
                rec.inventory_pickings += p

    @api.depends('inventory_transfer_id')
    def _compute_inventory_transfer_state(self):
        for rec in self:
            rec.inventory_transfer_state = rec.inventory_transfer_id.state

    def get_expected_entity_asset(self, picking_type):
        if self.work_order_id.work_order_type == 'move' and picking_type.asset_activity == 'attach':
            return self.new_identifier.id
        return self.identifier.id