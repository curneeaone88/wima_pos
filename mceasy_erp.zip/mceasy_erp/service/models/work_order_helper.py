from odoo import models, fields


class WorkOrderHelper(models.Model):
    _name = 'work.order.helper'
    _description = 'Helper'

    work_order_id = fields.Many2one(
        comodel_name='work.order',
        required=True,
        ondelete='cascade'
    )
    assigned_id = fields.Many2one(
        comodel_name='res.partner',
        string='Technician / Implementor',
        required=True,
    )
    note = fields.Text(
        required=True
    )