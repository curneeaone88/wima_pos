from odoo import models, fields, _, api
from odoo.exceptions import UserError, MissingError
from collections import deque
import math


WORK_ORDER_SALE_TYPES = [
    ('install', 'Installasi'),
    ('activation', 'Aktifasi'),
    # TODO: Used when the customer churn and the sparepart is still on the vehicle / container 
    # ('reactivation', 'Reaktifasi'),
    ('delivery', 'Pengiriman'),
    ('migrate', 'Migrasi'),
    ('implementation', 'Implementasi'),
    ('maintenance', 'Maintenance')
]

WORK_ORDER_SUPPORT_TYPES = [
    ('move', 'Pindah Unit'),
    ('maintenance', 'Maintenance')
]

WORK_ORDER_CHURN_TYPES = [
    ('deactivation', 'Non-aktif'),
    ('uninstall', 'Pelepasan')
]

WORK_ORDER_TYPES = WORK_ORDER_SALE_TYPES \
    + WORK_ORDER_SUPPORT_TYPES \
    + WORK_ORDER_CHURN_TYPES


WORK_ORDER_STATE_DRAFT = 'draft'
WORK_ORDER_STATE_PLAN = 'plan'
WORK_ORDER_STATE_READY = 'ready'
WORK_ORDER_STATE_PROGRESS = 'progress'
WORK_ORDER_STATE_AFTER_SALE_TRANSFER = 'after_sale_transfer'
WORK_ORDER_STATE_REQUEST = 'request'
WORK_ORDER_STATE_REJECTED = 'rejected'
WORK_ORDER_STATE_DONE = 'done'
WORK_ORDER_STATE_CANCEL = 'canceled'

WORK_ORDER_STATE = [
    (WORK_ORDER_STATE_DRAFT, 'Draft'),
    (WORK_ORDER_STATE_PLAN, 'Plan'),
    (WORK_ORDER_STATE_READY, 'Ready'),
    (WORK_ORDER_STATE_PROGRESS, 'In Progress'),
    (WORK_ORDER_STATE_AFTER_SALE_TRANSFER, 'After Sales Transfer'),
    (WORK_ORDER_STATE_REQUEST, 'Request'),
    (WORK_ORDER_STATE_REJECTED, 'Rejected'),
    (WORK_ORDER_STATE_DONE, 'Done'),
    (WORK_ORDER_STATE_CANCEL, 'Cancelled'),
]

class WorkOrder(models.Model):
    _name = 'work.order'
    _description = 'Work Order'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'approval.mixin']
    _order = 'id desc'

    name = fields.Char(
        string="Number",
        required=True,
        default=_("New"),
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        default=lambda self: self.env.company)
    company_partner_id = fields.Many2one(
        related='company_id.partner_id'
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        tracking=1,
        domain="[('company_id', 'in', (False, company_id)), ('parent_id', '=', False)]")
    contract_id = fields.Many2one(
        'sale.contract',
        string="Current Contract",
        index=True,
        ondelete='restrict',
        required=True,
        readonly=True
    )
    state = fields.Selection(
        selection=WORK_ORDER_STATE,
        string="Status",
        readonly=True, copy=False, index=True,
        tracking=3,
        default='draft')
    work_order_type = fields.Selection(
        selection=WORK_ORDER_TYPES,
        string='Type',
        required=True,
    )
    partner_domain_id = fields.Many2one(
        comodel_name='partner.domain',
        string='Registered on Domain',
    )
    procurement_group_id = fields.Many2one(
        comodel_name='procurement.group',
    )
    route = fields.Many2one(
        'stock.route',
        string='Operation',
    )
    is_have_route = fields.Boolean(
        compute='_compute_is_have_route'
    )
    pic = fields.Char(
        compute='_compute_pic',
        string='Customer & PIC'
    )
    customer_pic_id = fields.Many2one(
        comodel_name='res.partner',
        string='Customer PIC',
        required=True,
    )
    customer_pic_number = fields.Char(
        related='customer_pic_id.contact_number',
        required=True,
        string='Contact PIC'
    )
    location_id = fields.Many2one(
        comodel_name='res.partner',
        string='Location',
        required=True,
    )
    location_address = fields.Char(
        compute='_compute_location_name',
        string='Location Address',
        required=True,
        store=True
    )
    assigned_owner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Technician / Implementor',
        required=True,
    )
    planner_id = fields.Many2one(
        'res.users',
        string='Planner',
        required=True,
        default=lambda self: self.env.user
    )
    quantity_entity_plan = fields.Integer(
        string='Fleet / Container Plan',
        help='Number of planned Fleets / Containers'
    )
    quantity_entity_actual = fields.Integer(
        string='Fleet / Container Actual',
        help='Number of actual Fleets / Containers',
        default=False,
    )
    maximum_quantity_plan = fields.Integer(
        compute='_compute_maximum_quantity_plan'
    )
    maximum_quantity_activity = fields.Integer(
        compute='_compute_maximum_quantity_activity'
    )
    plan_datetime = fields.Datetime(
        string='Plan Datetime',
        default=fields.Datetime.now,
        required=True
    )
    actual_datetime = fields.Datetime(
        string='Actual Datetime',
    )
    work_order_lines = fields.One2many(
        comodel_name='work.order.line',
        inverse_name='work_order_id'
    )
    work_order_products = fields.One2many(
        comodel_name='work.order.line.product',
        inverse_name='work_order_id'
    )
    work_order_product_contracts = fields.One2many(
        comodel_name='sale.product.contract',
        compute='_compute_work_order_product_contracts'
    )
    work_order_activities = fields.One2many(
        comodel_name='work.order.activity',
        inverse_name='work_order_id'
    )
    inventory_transfers = fields.One2many(
        comodel_name='work.order.line.transfer',
        inverse_name='work_order_id',
        string='Component Transfers'
    )
    after_sale_components_check = fields.One2many(
        comodel_name='work.order.line.component.check',
        inverse_name='work_order_id',
        string='Components Check'
    )
    is_have_activity = fields.Boolean(
        compute='_compute_is_have_activity'
    )
    is_ready_to_done = fields.Boolean(
        compute='_compute_is_ready_to_done'
    )
    is_have_after_sale_transfer = fields.Boolean(
        compute='_compute_is_have_after_sale_transfer'
    )
    domain_subscription_lines = fields.One2many(
        comodel_name='subscription.line',
        compute='_compute_domain_subscription_lines'
    )
    domain_activity_lines = fields.One2many(
        comodel_name='sale.product.contract.activity',
        compute='_compute_domain_activity_lines'
    )
    domain_helpers = fields.One2many(
        comodel_name='res.partner',
        compute='_compute_domain_helpers'
    )
    creation_source = fields.Selection(
        selection=[
            ('work_order_menu', 'Menu Work Order'),
            ('outstanding_work_order_menu', 'Menu Outstanding Work Order'),
        ],
        default='work_order_menu'
    )
    ctx_outstanding_work_order_id = fields.Many2one(
        comodel_name='outstanding.work.order'
    )
    ctx_sale_order_id = fields.Many2one(
        comodel_name='sale.order'
    )
    ctx_after_sale_order_id = fields.Many2one(
        comodel_name='after.sale.order'
    )
    ctx_product_contract_template_id = fields.Many2one(
        comodel_name='product.template'
    )
    force_readonly = fields.Boolean(
        compute='_compute_force_readonly'
    )
    inventory_transfer_count = fields.Integer(
        compute='_compute_inventory_transfer_count'
    )
    subscription_count = fields.Integer(
        compute='_compute_subscription_count'
    )
    note = fields.Html(
        string='Internal Notes'
    )
    bast_report_signed = fields.Binary()
    bast_report_signed_name = fields.Char()
    helpers = fields.One2many(
        comodel_name='work.order.helper',
        inverse_name='work_order_id',
        string='Helper'
    )

    @api.depends('partner_id', 'work_order_type')
    def _compute_is_have_route(self):
        self.is_have_route = self.env['stock.route'].search_count([
            ('work_order_applicable', '=', self.work_order_type),
            ('work_order_applicable', '!=', False)
        ]) > 0

    @api.depends('partner_id', 'work_order_type')
    def _compute_is_have_activity(self):
        domain = [
            ('outstanding_work_order', '=', self.work_order_type),
            ('contract_id', '=', self.contract_id.id),
            ('work_order_id', '=', False),
        ]
        if len(self.ctx_product_contract_template_id) == 1:
            domain.append(('product_template_id', '=', self.ctx_product_contract_template_id.id))
        self.is_have_activity = self.env['sale.product.contract.activity'].search_count(domain) > 0

    @api.depends('after_sale_components_check')
    def _compute_is_have_after_sale_transfer(self):
        self.is_have_after_sale_transfer = False
        if self.state not in [WORK_ORDER_STATE_PROGRESS, WORK_ORDER_STATE_REQUEST, WORK_ORDER_STATE_REJECTED]:
            return
        if self.work_order_type not in ['maintenance', 'move', 'uninstall']:
            return
        
        if self.work_order_type == 'maintenance':
            for c in self.after_sale_components_check:
                if len(c.work_order_line_id.inventory_transfer_id) == 1:
                    continue
                if c.healthy == 'bad':
                    self.is_have_after_sale_transfer = True
                    continue
                if c.healthy == 'need_check':
                    self.is_have_after_sale_transfer = False
                    return
        elif self.work_order_type in ['move', 'uninstall']:
            self.is_have_after_sale_transfer = True

    @api.depends('work_order_lines', 'work_order_type')
    @api.onchange('partner_domain_id')
    def _onchange_partner_domain_id(self):
        if self.work_order_type in ['maintenance', 'move', 'deactivation', 'uninstall']:
            return

        for line in self.work_order_lines:
            if len(line.identifier) == 0:
                continue
            if line.identifier.partner_domain_id.id == self.partner_domain_id.id:
                continue
            line.name = False
            line.identifier = False

    @api.onchange('maximum_quantity_activity')
    def _onchange_maximum_quantity_activity(self):
        self.write({
            'work_order_activities': [fields.Command.clear()]
        })

        if self.is_have_activity:
            activities = []
            domain = [
                ('outstanding_work_order', '=', self.work_order_type),
                ('contract_id', '=', self.contract_id.id),
                ('work_order_id', '=', False),
            ]
            if len(self.ctx_product_contract_template_id) == 1:
                domain.append(('product_template_id', '=', self.ctx_product_contract_template_id.id))
            contract_activities = self.env['sale.product.contract.activity'].search(domain)
            for act in contract_activities:
                activities.append(fields.Command.create({
                    'work_order_id': self.id,
                    'sale_product_contract_activity': act.id
                }))
            self.write({
                'work_order_activities': activities
            })

    def _compute_display_name(self):
        for rec in self:
            rec.display_name = f'{rec.name} / {rec.partner_id.name}'

    @api.depends('creation_source')
    def _compute_force_readonly(self):
        self.force_readonly = self.creation_source == 'outstanding_work_order_menu'

    @api.depends('work_order_lines', 'after_sale_components_check')
    def _compute_is_ready_to_done(self):
        self.is_ready_to_done = False
        if self.state not in ['progress', 'after_sale_transfer']:
            return
        if self.work_order_type == 'implementation' and self.bast_report_signed == False:
            return
        for wo_line in self.work_order_lines:
            if wo_line.inventory_transfer_state and wo_line.inventory_transfer_state not in ['done', 'cancel']:
                return
        if self.work_order_type == 'maintenance':
            for component_check_line in self.after_sale_components_check:
                if component_check_line.healthy == 'need_check':
                    return
        self.is_ready_to_done = True
        

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        self.contract_id = self.partner_id.contract_id

    @api.depends('assigned_owner_id', 'helpers')
    def _compute_domain_helpers(self):
        helpers = self.env['res.partner'].browse()
        for h in self.helpers:
            helpers += h.assigned_id
        
        self.domain_helpers = helpers

    @api.onchange('assigned_owner_id')
    def _onchange_assigned_owner_id(self):
        if len(self.assigned_owner_id) == 0:
            return
        
        self.helpers = [fields.Command.clear()]
        
    @api.depends('partner_id', 'work_order_type')
    def _compute_maximum_quantity_plan(self):
        for rec in self:
            rec.maximum_quantity_plan = 0

            if rec.state != 'draft':
                continue

            if len(rec.partner_id) == 0 or rec.work_order_type is False:
                rec.quantity_entity_plan = 0
                continue
            
            domain_outstanding = [
                ('outstanding_work_order', '=', rec.work_order_type),
                ('partner_id', '=', rec.partner_id.id)
            ]
            if len(rec.ctx_outstanding_work_order_id) == 1:
                domain_outstanding += [
                    ('id', '=', rec.ctx_outstanding_work_order_id.id)
                ]
            outstandings = self.env['outstanding.work.order'].search(domain_outstanding)
            if len(outstandings) == 0:
                rec.quantity_entity_plan = 0
                continue

            total_recurring = 0
            total_one_time_fee = 0
            total_after_sale_unit = 0
            for outstanding in outstandings:
                total_recurring += outstanding.qty_recurring 
                total_one_time_fee += outstanding.qty_one_time
                total_after_sale_unit += outstanding.qty_after_sale_unit
            
            if total_after_sale_unit == 0:
                rec.maximum_quantity_plan = max([total_recurring, total_one_time_fee])
            else:
                rec.maximum_quantity_plan = total_after_sale_unit

            if not rec.force_readonly:
                rec.quantity_entity_plan = rec.maximum_quantity_plan
    
    @api.depends('partner_id', 'work_order_type')
    def _compute_maximum_quantity_activity(self):
        for rec in self:
            rec.maximum_quantity_activity = 0
            if len(rec.partner_id) == 0 or rec.work_order_type is False:
                continue
            
            domain = [
                ('outstanding_work_order', '=', self.work_order_type),
                ('contract_id', '=', self.contract_id.id),
                ('work_order_id', '=', False),
            ]
            if len(self.ctx_product_contract_template_id) == 1:
                domain.append(('product_template_id', '=', self.ctx_product_contract_template_id.id))
            rec.maximum_quantity_activity = self.env['sale.product.contract.activity'].search_count(domain)
    
    @api.depends('location_id')
    def _compute_location_name(self):
        self.location_address = False
        if self.location_id is False:
            self.location_address = False
            return
        location_address = self.location_id.with_context(
            show_address=True
        ).display_name

        if location_address == self.location_id.display_name:
            location_address = False
        if location_address != False:
            self.location_address = location_address.replace(self.location_id.display_name, '').strip()

    @api.depends('customer_pic_id', 'customer_pic_number')
    def _compute_pic(self):
        for item in self:
            item.pic = f'{item.customer_pic_id.display_name} ({item.customer_pic_number})'
        
    @api.depends('work_order_lines')
    def _compute_domain_subscription_lines(self):
        sub_lines = []
        for line in self.work_order_lines:
            for sub_line in line.subscription_line_ids:
                sub_lines.append(sub_line.id)
        if len(self.ctx_sale_order_id) > 0:
            domain_search = [
                ('contract_id', '=', self.contract_id.id),
                ('outstanding_work_order', '=', self.work_order_type),
                ('start_date', '=', False),
                ('sale_order_id', '!=', self.ctx_sale_order_id.id)
            ]
            if self.work_order_type in ['install', 'activation', 'migrate', 'delivery']:
                domain_search.append(('entity_asset_id', '=', False))
            
            other_subs = self.env['subscription.line'].search(domain_search)
            for line in other_subs:
                sub_lines.append(line.id)

        if len(sub_lines) > 0:
            self.domain_subscription_lines = sub_lines
        else:
            self.domain_subscription_lines = False
    
    @api.depends('work_order_activities')
    def _compute_domain_activity_lines(self):
        activity_lines = []
        for line in self.work_order_activities:
            activity_lines.append(line.sale_product_contract_activity.id)
        
        if len(self.ctx_product_contract_template_id) > 0:
            domain_search = [
                ('contract_id', '=', self.contract_id.id),
                ('outstanding_work_order', '=', self.work_order_type),
                ('work_order_id', '=', False),
                ('product_template_id', '!=', self.ctx_product_contract_template_id.id)
            ]
            other_activities = self.env['sale.product.contract.activity'].search(domain_search)
            for line in other_activities:
                activity_lines.append(line.id)
        
        if len(activity_lines) > 0:
            self.domain_activity_lines = activity_lines
        else:
            self.domain_activity_lines = False

    @api.depends('work_order_activities')
    def _compute_work_order_product_contracts(self):
        product_contracts = []
        for line in self.work_order_activities:
            if line.sale_product_contract_activity.sale_product_contract_id.id not in product_contracts:
                product_contracts.append(line.sale_product_contract_activity.sale_product_contract_id.id)

        if len(product_contracts) > 0:
            self.work_order_product_contracts = product_contracts
        else:
            self.work_order_product_contracts = False

    @api.depends('domain_subscription_lines', 'maximum_quantity_plan')
    @api.onchange('quantity_entity_plan')
    def _onchange_quantity_entity_plan(self):
        if self.quantity_entity_plan > self.maximum_quantity_plan:
            raise UserError("Sorry, Cannot plan larger than confirmed order")

        if self.quantity_entity_plan < len(self.work_order_lines):
            total_removed = len(self.work_order_lines) - self.quantity_entity_plan
            reversed_ids = list(reversed(self.work_order_lines._ids))
            for i in range(total_removed):
                self.write({
                    'work_order_lines': [fields.Command.delete(reversed_ids[i])]
                })
            return

        total_new_plan = self.quantity_entity_plan - len(self.work_order_lines)
        if total_new_plan == 0:
            return

        # self.work_order_lines = [fields.Command.clear()]
        selected_subscription_lines = []
        for selected_line in self.domain_subscription_lines:
            selected_subscription_lines.append(selected_line._origin.id)

        domain = [
            ('contract_id', '=', self.contract_id.id),
            ('outstanding_work_order', '=', self.work_order_type),
            ('id', 'not in', selected_subscription_lines)
        ]

        if self.work_order_type in ['move', 'maintenance', 'deactivation']:
            domain += [('end_date', '=', False)]
        elif self.work_order_type in ['uninstall']:
            domain += [('end_date', '!=', False), ('start_date', '!=', False), ('entity_asset_id', '!=', False)]
        else:
            domain += [('start_date', '=', False)]

        if len(self.ctx_sale_order_id) > 0:
            domain.append(('sale_order_id', '=', self.ctx_sale_order_id.id))
        if len(self.ctx_after_sale_order_id) > 0:
            domain.append(('entity_asset_id', 'in', self.ctx_after_sale_order_id.domain_entity_assets.ids))

        if self.work_order_type in ['install', 'activation', 'migrate', 'delivery']:
            domain.append(('entity_asset_id', '=', False))
        outstandings = self.env['subscription.line'].search(domain)
        if self.work_order_type in ['maintenance', 'move', 'deactivation', 'uninstall']:
            plan = self._compute_after_sale_plan(outstandings)
        else:
            plan = self._compute_sale_plan(outstandings)

        self.work_order_lines = plan
        for line in self.work_order_lines:
            line.check_identifier()

    def _compute_sale_plan(self, outstandings):
        plan = []
        outstanding_subscriptions = {}
        for out_rec in outstandings:
            if out_rec.product_id.id not in outstanding_subscriptions:
                outstanding_subscriptions[out_rec.product_id.id] = {
                    'total': 0,
                    'lines': []
                }
            outstanding_subscriptions[out_rec.product_id.id]['lines'].append(out_rec)
            outstanding_subscriptions[out_rec.product_id.id]['total'] += 1

        minimum_quantity = 0
        for k in outstanding_subscriptions.keys():
            outstanding_subscriptions[k]['lines'] = deque(outstanding_subscriptions[k]['lines'])
            if minimum_quantity == 0:
                minimum_quantity = outstanding_subscriptions[k]['total']
                continue

            if outstanding_subscriptions[k]['total'] < minimum_quantity:
                minimum_quantity = outstanding_subscriptions[k]['total']

        total_asset = self.env['entity.asset'].search_count([('partner_id', '=', self.partner_id.id)])
        total_new_asset = 0
        for w in self.work_order_lines:
            if len(w.identifier) == 1:
                continue
            total_new_asset = total_new_asset + 1

        for i in range(1, self.quantity_entity_plan - len(self.work_order_lines) + 1):
            subscription_lines = []
            for k in outstanding_subscriptions:
                recurring_ids = outstanding_subscriptions[k]['lines']
                minimum_composition = int(math.ceil(outstanding_subscriptions[k]['total'] / minimum_quantity))
                for _ in range(minimum_composition):
                    try:
                        recurring_id = recurring_ids.popleft()
                        subscription_lines.append(recurring_id)
                    except IndexError:
                        pass

            if len(subscription_lines) == 0:
                self.write({
                    'quantity_entity_plan': len(plan) + len(self.work_order_lines)
                })
                break


            plan.append(fields.Command.create({
                'identifier': False,
                'name': f'ID {total_new_asset + total_asset + i}',
                'type': 'vehicle',
                'company_id': self.company_id.id,
                'partner_id': self.partner_id.id,
                'subscription_line_ids': [sub.id for sub in subscription_lines],
            }))
        return plan

    def _compute_after_sale_plan(self, outstandings):
        plan = []
        map_identifiers = {}
        for o in outstandings:
            if o.entity_asset_id not in map_identifiers:
                map_identifiers[o.entity_asset_id] = []
            map_identifiers[o.entity_asset_id].append(o.id)
        
        qty_plan = 0
        for k in map_identifiers.keys():
            after_sale_type = self.work_order_type
            if after_sale_type in ['deactivation', 'uninstall']:
                after_sale_type = 'churn'

            after_sale_order_line = self.env['after.sale.order.line'].search([
                ('entity_asset_id', '=', k.id),
                ('after_sale_order_id.state', '=', 'requested'),
                ('after_sale_order_id.type', '=', after_sale_type),
            ])
            if len(after_sale_order_line) != 1:
                raise UserError(f"Integrity of {self.name} error for {k.name}, please contact administrator !")
            plan.append(fields.Command.create({
                'name': k.name,
                'type': k.type,
                'identifier': k.id,
                'new_identifier': after_sale_order_line.new_entity_asset_id.id,
                'company_id': self.company_id.id,
                'partner_id': self.partner_id.id,
                'after_sale_order_line_id': after_sale_order_line.id,
                'subscription_line_ids': map_identifiers[k],
                'note': after_sale_order_line.note,
            }))
            qty_plan += 1
            if qty_plan >= self.quantity_entity_plan - len(self.work_order_lines):
                break

        return plan
    
    def _action_sale_plan(self):
        for line in self.work_order_lines:    
            line.inventory_transfers = [fields.Command.clear()]
            inventory_transfers = []
            map_component_placements = []
            for subscription_line in line.subscription_line_ids:
                reserved_products = subscription_line.quotation_line_id.get_reserved_products()
                for reserved_product in reserved_products:
                    if len(reserved_product.component_line_id) == 0:
                        continue
                    if reserved_product.uom_qty == 0:
                        continue

                    tracked_components = self.env['entity.asset.component'].search([
                        ('subscription_line_id', '=', subscription_line.id),
                        ('component_line_id', '=', reserved_product.component_line_id.id),
                    ])
                    tracked_component_qty = 0
                    for t in tracked_components:
                        tracked_component_qty += t.quantity
                        if t.entity_asset_id.id != line.identifier.id:
                            raise UserError(
                                f"Inconsistent identifier, Product ({subscription_line.name}) is registered to identifier: {t.entity_asset_id.name} and not match planned identifier: {line.identifier.name}"
                            )
                    
                    rest_quantity = (reserved_product.uom_qty/reserved_product.quotation_line_id.uom_qty) - tracked_component_qty
                    if rest_quantity <= 0:
                        continue

                    # check old planning if exist
                    old_move = self.env['stock.move'].search([
                        ('component_line_id', '=', reserved_product.component_line_id.id),
                        ('subscription_line_id', '=', subscription_line.id),
                        ('entity_asset_id', '=', line.identifier.id)
                    ], limit=1)

                    rp_id = reserved_product.id
                    if len(old_move) == 1:
                        old_rp = self.env['sale.contract.reserved.product'].search([
                            ('component_product_id', '=', old_move.product_id.product_tmpl_id.id),
                            ('component_line_id', '=', reserved_product.component_line_id.id),
                            ('quotation_line_id', '=', reserved_product.quotation_line_id.id)
                        ], limit=1)
                        if len(old_rp) == 1:
                            rp_id = old_rp.id
                    
                    if reserved_product.component_id.fulfill_quantity:
                        for i in range(int(rest_quantity)):
                            component_placement_id = False
                            if len(reserved_product.component_id.available_placements) != 0:
                                all_keys = []
                                attached_placement_ids = line.identifier.components.filtered(
                                    lambda x: x.component_line_id == reserved_product.component_line_id
                                ).mapped('component_placement_id').ids

                                for placement in reserved_product.component_id.available_placements:
                                    if placement.id in attached_placement_ids:
                                        continue
                                    key = (line.id, placement.id)
                                    all_keys.append(key)
                                    if key not in map_component_placements:
                                        map_component_placements.append(key)
                                        component_placement_id = placement.id
                                        break
                                if component_placement_id is False:
                                    for key in all_keys:
                                        map_component_placements.remove(key)
                                        (line_id, placement_id) = key
                                        if component_placement_id is False:
                                            component_placement_id = placement_id
                                            map_component_placements.append(key)
                                    
                            inventory_transfers.append(fields.Command.create({
                                'work_order_line_id': line.id,
                                'subscription_line_id': subscription_line.id,
                                'reserved_product_id': rp_id,
                                'component_placement_id': component_placement_id,
                                'quantity': 1
                            }))
                    else:
                        inventory_transfers.append(fields.Command.create({
                            'work_order_line_id': line.id,
                            'subscription_line_id': subscription_line.id,
                            'reserved_product_id': rp_id,
                            'component_placement_id': False,
                            'quantity': rest_quantity
                        }))
            line.inventory_transfers = inventory_transfers
    
    def _action_after_sale_plan(self):
        after_sale_components_check = []
        for line in self.work_order_lines:
            # check old maintenance move, if already replaced don't include in the operation
            old_moves = []
            old_lines = self.env['work.order.line'].search([
                ('after_sale_order_line_id', '=', line.after_sale_order_line_id.id),
                ('id', '!=', line.id),
            ])
            for ol in old_lines:
                for p in ol.inventory_pickings:
                    for m in p.move_ids:
                        if m.asset_activity is False:
                            continue
                        old_moves.append(m.id)
            for component in line.identifier.components:
                if component.active == False:
                    continue
                if component.move_id.id in old_moves:
                    continue
                if component.subscription_line_id.id not in line.subscription_line_ids.ids:
                    continue
                if component.product_id.type != 'product' or component.component_line_id.component_id.fulfill_quantity is False:
                    continue
                if component.quantity <= 0:
                    continue
                if component.quantity == 1:
                    after_sale_components_check.append(fields.Command.create({
                        'subscription_line_id': component.subscription_line_id.id,
                        'new_entity_asset_id': line.new_identifier.id,
                        'work_order_line_id': line.id,
                        'after_sale_order_line_id': line.after_sale_order_line_id.id,
                        'entity_asset_component_id': component.id,
                        'component_placement_id': component.component_placement_id.id,
                        'quantity': 1,
                    }))
                    continue
                else:
                    for i in range(int(component.quantity)):
                        after_sale_components_check.append(fields.Command.create({
                            'subscription_line_id': component.subscription_line_id.id,
                            'new_entity_asset_id': line.new_identifier.id,
                            'work_order_line_id': line.id,
                            'after_sale_order_line_id': line.after_sale_order_line_id.id,
                            'entity_asset_component_id': component.id,
                            'component_placement_id': component.component_placement_id.id,
                            'quantity': 1,
                        })) 
        
        self.after_sale_components_check = after_sale_components_check

    def _domain_inventory_transfer(self):
        return [
            ('origin', 'ilike', self.name),
            ('state', '!=', 'cancel')
        ]

    def _compute_inventory_transfer_count(self):
        self.inventory_transfer_count = self.env['stock.picking'].search_count(
            self._domain_inventory_transfer()
        )

    def action_plan(self):
        if len(self.work_order_activities) == 0 and len(self.work_order_lines) == 0:
            raise UserError("Sorry, You can't planning empty activity or fleet / container")
        
        if self.work_order_type in ['install', 'activation', 'migrate', 'delivery']:
            for line in self.work_order_lines:
                if len(line.subscription_line_ids) == 0:
                    raise UserError(f"Sorry, Make sure you fill product in identifier")
                if len(line.identifier) == 0:
                    existing_identifier = self.env['entity.asset'].search([
                        ('name', '=', line.name.strip()),
                        ('type', '=', line.type),
                        ('company_id', '=', line.company_id.id),
                        ('partner_id', '=', line.partner_id.id),
                    ])
                    if len(existing_identifier) == 1:
                        if existing_identifier.partner_domain_id.id != self.partner_domain_id.id:
                            raise UserError(f"Sorry, {line.name.strip()} already registered on domain {existing_identifier.partner_domain_id.name}, please check the Customer Domain.")
                        line.identifier = existing_identifier
                    else:
                        identifier = self.env['entity.asset'].create({
                            'name': line.name.strip(),
                            'type': line.type,
                            'company_id': line.company_id.id,
                            'partner_id': line.partner_id.id,
                            'partner_domain_id': self.partner_domain_id.id
                        })

                        line.identifier = identifier

        if self.work_order_type not in ['maintenance', 'move', 'deactivation', 'uninstall']:
            self._action_sale_plan()
        elif self.work_order_type in ['maintenance', 'move', 'uninstall']:
            self._action_after_sale_plan()
        
        for line in self.work_order_activities:
            line.sale_product_contract_activity.action_activate_line(line)

        if self.assigned_owner_id.id not in self.helpers.mapped('assigned_id').ids:
            self.helpers = [fields.Command.create({
                'assigned_id': self.assigned_owner_id.id,
                'note': 'Main PIC'
            })]

        self.state = WORK_ORDER_STATE_PLAN

    def action_draft(self):
        self.state = WORK_ORDER_STATE_DRAFT
        self._unreserve_subscription()
        self._unreserve_activity()
        self._remove_all_related_transfer()
        self._remove_all_related_component_check()

    def action_ready(self):
        if self.name == 'New':
            self.name = self.env['ir.sequence'].next_by_code('work.order')
        
        self._process_procurement()
        self._reserve_subscription()
        self.state = WORK_ORDER_STATE_READY
    
    def action_progress(self):
        if self.work_order_type not in ['maintenance', 'move', 'uninstall']:
            for wo_line in self.work_order_lines:
                if wo_line.inventory_transfer_state and wo_line.inventory_transfer_state in ['waiting', 'confirmed', 'draft']:
                    raise UserError("To start operation, all fleet / container transfer must be in ready state")
        else:
            self._remove_all_related_transfer()
        if self.actual_datetime is False:
            self.actual_datetime = fields.Datetime.now()
        self.state = WORK_ORDER_STATE_PROGRESS

    def action_after_sale_transfer(self):
        if len(self.route) == 0:
            return
        group_id = self.env['procurement.group'].search([
            ('name', '=', self.name),
            ('work_order_id', '=', self.id),
        ])
        if len(group_id) == 0:
            group_id = self.env['procurement.group'].create({
                'name': f'{self.name}',
                'move_type': 'direct',
                'partner_id': self.assigned_owner_id.id,
                'work_order_id': self.id
            })
        else:
            group_id.partner_id = self.assigned_owner_id

        self.procurement_group_id = group_id
        if self.work_order_type == 'maintenance':
            destination_locations = [self.route.rule_ids[-1].location_dest_id, self.route.rule_ids[-1].location_src_id]
        else:
            destination_locations = [self.route.rule_ids[-1].location_dest_id]

        need_transfers = {}
        for c in self.after_sale_components_check:
            if self.work_order_type == 'maintenance' and c.healthy != 'bad':
                continue
            if c.entity_asset_id not in need_transfers:
                need_transfers[c.entity_asset_id] = {
                    'group_id': group_id,
                    'route_ids': self.route,
                    'partner_id': self.partner_id.id,
                    'date_planned': self.plan_datetime,
                    'work_order_line_id': c.work_order_line_id.id,
                    'entity_asset_id': c.entity_asset_id.id,
                    'procurements': []
                }
            op = need_transfers[c.entity_asset_id].copy()
            del op['procurements']
            op['subscription_line_id'] = c.subscription_line_id.id
            op['component_line_id'] = c.entity_asset_component_id.component_line_id.id
            op['component_placement_id'] = c.entity_asset_component_id.component_placement_id.id
            for d in destination_locations:
                need_transfers[c.entity_asset_id]['procurements'].append(self.env['procurement.group'].Procurement(
                    c.product_id,
                    c.quantity,
                    c.product_id.uom_id,
                    d,
                    c.product_id.name,
                    f'{self.name}/{c.entity_asset_id.id}',
                    self.company_id,
                    op
                ))
        
        for k in need_transfers.keys():
            self.env['procurement.group'].run(need_transfers[k]['procurements'])
        
        self.state = WORK_ORDER_STATE_AFTER_SALE_TRANSFER
    
    def get_approval_state(self):
        return WORK_ORDER_STATE_REQUEST
    
    def get_rejection_state(self):
        return WORK_ORDER_STATE_REJECTED

    def action_request(self):
        if not self.is_ready_to_done or self.is_have_after_sale_transfer:
            return True
        if not self.is_need_approval:
            raise UserError("There is no approval configuration !")
        return self.action_request_approval()

    def action_done(self):
        if self.work_order_type == 'implementation' and self.bast_report_signed == False:
            raise UserError("Sorry, Please upload BAST Implementation.")
        for wo_line in self.work_order_lines:
            if wo_line.inventory_transfer_state and wo_line.inventory_transfer_state in ['assigned']:
                raise UserError("To confirm, all fleet / container transfer must be done or cancel")
        
        if self.work_order_type == 'maintenance':
            for component_check_line in self.after_sale_components_check:
                if component_check_line.healthy == 'need_check':
                    raise UserError("To confirm, all Components Check -> Healthy must be set to Good / Bad")

        if self.actual_datetime < self.plan_datetime:
            raise UserError("Sorry, Actual datetime cannot lower than Plan datetime")
        
        quantity_actual = 0
        uncomplete_subscription_ids = self.env['subscription.line']
        asset_components = []
        next_operations = []
        after_sale_orders = self.env['after.sale.order'].browse()

        operation_action = 'action_activate'
        if self.work_order_type in ['deactivation', 'uninstall']:
            operation_action = 'action_deactivate'

        work_order_line_processed = []
        for line in self.work_order_lines:
            if len(line.after_sale_order_id) == 1 and line.after_sale_order_id.id not in after_sale_orders.ids:
                after_sale_orders += line.after_sale_order_id

            uncomplete_moves = line.inventory_transfer_id.check_uncomplete()
            if len(uncomplete_moves) == 0:
                quantity_actual += 1
                if line.id not in work_order_line_processed:
                    work_order_line_processed.append(line.id)

            else:
                for m in uncomplete_moves:
                    uncomplete_subscription_ids += m.subscription_line_id

            for p in line.inventory_pickings:
                if p.state == 'cancel':
                    continue

                if line.id not in work_order_line_processed:
                    work_order_line_processed.append(line.id)

                for move in p.move_ids:
                    if move.asset_activity is False:
                        continue
                    
                    if move.id in uncomplete_moves.ids:
                        continue
                    
                    entity_asset_id = line.get_expected_entity_asset(move.picking_type_id)

                    component_transfered = {
                        'move_id': move.id,
                        'entity_asset_id': entity_asset_id,
                        'subscription_line_id': move.subscription_line_id.id,
                        'component_line_id': move.component_line_id.id,
                        'component_placement_id': move.component_placement_id.id,
                        'product_id': move.product_id.id,
                        'quantity': move._get_picked_quantity(),
                    }
                    if move.has_tracking == 'none':
                        asset_components.append((move.asset_activity, move.date, component_transfered))
                        continue

                    for item_tracking in move.lot_ids:
                        component_transfered['lot_id'] = item_tracking.id
                        asset_components.append((move.asset_activity, move.date, component_transfered))
            
            if len(line.inventory_pickings) == 0 and line.id not in work_order_line_processed:
                work_order_line_processed.append(line.id)
        
        for asset_activity, activity_date, component in asset_components:
            if asset_activity == 'attach':
                is_exist = self.env['entity.asset.component'].search_count([
                    ('move_id', '=', component['move_id'])
                ]) > 0
                if is_exist:
                    continue
                component['attached_on'] = activity_date
                self.env['entity.asset.component'].create(component)
            else:
                detached_component = self.env['entity.asset.component'].search([
                    ('entity_asset_id', '=', component['entity_asset_id']),
                    ('subscription_line_id', '=', component['subscription_line_id']),
                    ('component_line_id', '=', component['component_line_id']),
                    ('product_id', '=', component['product_id']),
                    ('quantity', '=', component['quantity']),
                    ('active', '=', True),
                ], limit=1)
                if len(detached_component) == 0:
                    raise UserError("Integrity error, multiple detached component, please contact administrator")
                detached_component.detached_on = activity_date
                detached_component.active = False
        
        self.quantity_entity_actual = quantity_actual
        
        # need to check all activities is completed (this means outstanding activity count must be zero)
        product_contract_outstanding_activity = {}
        for line in self.work_order_activities:
            # initiate dictionary
            if line.product_template_id.id not in product_contract_outstanding_activity:
                product_contract_outstanding_activity[
                    line.product_template_id.id
                ] = {
                    'count': self.env['sale.product.contract.activity'].search_count([
                        ('contract_id', '=', self.contract_id.id),
                        ('product_template_id', '=', line.product_template_id.id),
                        ('outstanding_work_order', '=', self.work_order_type),
                        ('work_order_id', '=', False),
                    ]),
                    # 'count': len(line.sale_product_contract_activity.product_operation_line_id.activities),
                    'have_for_billing_action': False
                }

            # complete activity
            getattr(line.sale_product_contract_activity, operation_action)(self)

            # decrement completed activity
            product_contract_outstanding_activity[
                line.sale_product_contract_activity.product_template_id.id
            ]['count'] -= 1

            # check product contract trigger (for_billing_action)
            if not product_contract_outstanding_activity[
                line.sale_product_contract_activity.product_template_id.id
            ]['have_for_billing_action'] and line.sale_product_contract_activity.for_billing_action:
                product_contract_outstanding_activity[
                    line.sale_product_contract_activity.product_template_id.id
                ]['have_for_billing_action'] = line.sale_product_contract_activity.for_billing_action

        next_operation_product_contract = {}
        for line in self.work_order_lines:
            if line.id not in work_order_line_processed:
                # unreserve all subscription that not processed
                for subscription_line in line.subscription_line_ids:
                    if subscription_line.id not in uncomplete_subscription_ids.ids:
                        uncomplete_subscription_ids += subscription_line

                continue

            for subscription_line in line.subscription_line_ids:
                if subscription_line.id in uncomplete_subscription_ids.ids:
                    continue

                # change the subscription identifier
                if self.work_order_type == 'move':
                    subscription_line.entity_asset_id = line.new_identifier
                elif self.work_order_type == 'uninstall':
                    subscription_line.entity_asset_id = False

                product_contract_activity = product_contract_outstanding_activity.get(
                    subscription_line.product_template_id.id,
                    False
                )
                # no product contract activity
                if product_contract_activity == False:
                    if subscription_line.product_operation_line_id.for_billing_action:
                        getattr(subscription_line, operation_action)(self.actual_datetime)

                    next_operation = subscription_line.product_operation_line_id.operation_template_id.get_next_operation(
                        subscription_line.product_operation_line_id.type,
                        self.work_order_type
                    )
                    if next_operation and not subscription_line.product_operation_line_id.for_billing_action:
                        # need to check is next_operation (product_contract) already done? if done then it should be activated and mark as done too
                        if next_operation.scope == 'product_contract':
                            key = (self.contract_id.id, subscription_line.product_template_id.id)
                            if key not in next_operation_product_contract:
                                oppt = self.env['sale.product.contract'].search([
                                    ('contract_id', '=', self.contract_id.id),
                                    ('product_template_id', '=', subscription_line.product_template_id.id),
                                ], limit=1)
                                next_operation_product_contract[key] = oppt
                            if len(next_operation_product_contract[key]) == 1:
                                # TODO: Need to check recursive to chaining operation
                                if next_operation_product_contract[key].is_billed:
                                    getattr(subscription_line, operation_action)(self.actual_datetime)
                                
                                if next_operation_product_contract[key].is_done:
                                    subscription_line.outstanding_work_order = None
                                    subscription_line.product_operation_line_id = None
                                else:
                                    subscription_line.outstanding_work_order = next_operation.work_order_type
                                    subscription_line.product_operation_line_id = next_operation.id
                                # END TODO
                            else:
                                subscription_line.outstanding_work_order = next_operation.work_order_type
                                subscription_line.product_operation_line_id = next_operation.id
                        else:
                            subscription_line.outstanding_work_order = next_operation.work_order_type
                            subscription_line.product_operation_line_id = next_operation.id
                    else:
                        if next_operation is not None and next_operation.scope == 'product_unit':
                            subscription_line.outstanding_work_order = next_operation.work_order_type
                            subscription_line.product_operation_line_id = next_operation.id
                        else:
                            subscription_line.outstanding_work_order = None
                            subscription_line.product_operation_line_id = None
                    
                    if next_operation is None:
                        continue
                        
                    key = (next_operation, subscription_line.sale_order_id)
                    if len(line.after_sale_order_id) == 1:
                        key += (False, line.after_sale_order_id)
                    else:
                        key += (subscription_line.quotation_line_id.product_template_id, False)
                    if key not in next_operations:
                        next_operations.append(key)
                else:
                    if product_contract_activity['have_for_billing_action']:
                        getattr(subscription_line, operation_action)(self.actual_datetime)
                    
                    if product_contract_activity['count'] == 0:
                        next_operation = subscription_line.product_operation_line_id.operation_template_id.get_next_operation(
                            subscription_line.product_operation_line_id.type,
                            self.work_order_type
                        )
                        if next_operation and not subscription_line.product_operation_line_id.for_billing_action:
                            subscription_line.outstanding_work_order = next_operation.work_order_type
                            subscription_line.product_operation_line_id = next_operation.id
                        else:
                            if next_operation is not None and next_operation.scope == 'product_unit':
                                subscription_line.outstanding_work_order = next_operation.work_order_type
                                subscription_line.product_operation_line_id = next_operation.id
                            else:
                                subscription_line.outstanding_work_order = None
                                subscription_line.product_operation_line_id = None

                        if next_operation is None:
                            continue

                        key = (next_operation, subscription_line.sale_order_id)
                        if len(line.after_sale_order_id) == 1:
                            key += (False, line.after_sale_order_id)
                        else:
                            key += (subscription_line.quotation_line_id.product_template_id, False)

                        if key not in next_operations:
                            next_operations.append(key)

        for (next_operation, sale_order_id, product_id, after_sale_order_id) in next_operations:
            outstanding_workorder = {
                'company_id': self.company_id.id,
                'partner_id': self.partner_id.id,
                'contract_id': self.contract_id.id,
                'outstanding_work_order': next_operation.work_order_type
            }
            if self.work_order_type in ['maintenance', 'move', 'deactivation', 'uninstall']:
                outstanding_workorder['after_sale_order_id'] = after_sale_order_id.id
                self.env['outstanding.work.order'].create(outstanding_workorder)
                continue

            if next_operation.scope != 'product_contract':
                outstanding_workorder['quotation_id'] = sale_order_id.contract_id.id
                outstanding_workorder['sale_order_id'] = sale_order_id.id
            else:
                product_contract = self.env['sale.product.contract'].search([
                    ('contract_id', '=', self.contract_id.id),
                    ('product_template_id', '=', product_id.id),
                ], limit=1)

                if product_contract:
                    continue
                else:
                    product_contract = self.env['sale.product.contract'].create({
                        'name': product_id.name,
                        'contract_id': self.contract_id.id,
                        'product_template_id': product_id.id,
                    })
                    activities = []
                    for act in next_operation.activities:
                        activities.append(fields.Command.create({
                            'sale_product_contract_id': product_contract.id,
                            'product_operation_line_id': next_operation.id,
                            'product_operation_line_activity_id': act.id,
                            'outstanding_work_order': next_operation.work_order_type
                        }))
                    product_contract.write({
                        'activities': activities
                    })
                outstanding_workorder['product_contract_template_id'] = product_id.id

            self.env['outstanding.work.order'].create(outstanding_workorder)
        
        if len(uncomplete_subscription_ids) > 0:
            self._unreserve_subscription(uncomplete_subscription_ids)

        self.cleanup_outstanding_work_order()
        self.action_done_after_sales(after_sale_orders)
        self.state = WORK_ORDER_STATE_DONE
    
    def action_reject(self):
        self.state = WORK_ORDER_STATE_REJECTED
    
    def action_revision(self):
        self.clean_approvers()
        if self.is_have_after_sale_transfer:
            self.state = WORK_ORDER_STATE_AFTER_SALE_TRANSFER
        else:
            self.state = WORK_ORDER_STATE_PROGRESS

    def cleanup_outstanding_work_order(self):
        outstandings = self.env['outstanding.work.order'].search([
            ('contract_id', '=', self.contract_id.id),
            ('active', '=', True),
        ])
        
        for outstanding in outstandings:
            if outstanding.qty_after_sale_unit == 0 and outstanding.qty_activity == 0 and outstanding.qty_recurring == 0 and outstanding.qty_one_time == 0:
                outstanding.action_archive()
    
    def action_done_after_sales(self, after_sale_orders):
        for after_sale_order in after_sale_orders:
            after_sale_order.action_done(quite=True)

    def _process_procurement(self):
        if len(self.route) == 0:
            return
        if self.work_order_type in ['maintenance', 'move', 'deactivation', 'uninstall']:
            return

        group_id = self.env['procurement.group'].search([
            ('name', '=', self.name),
            ('work_order_id', '=', self.id),
        ])
        if len(group_id) == 0:
            group_id = self.env['procurement.group'].create({
                'name': f'{self.name}',
                'move_type': 'direct',
                'partner_id': self.assigned_owner_id.id,
                'work_order_id': self.id
            })
        else:
            group_id.partner_id = self.assigned_owner_id

        self.procurement_group_id = group_id
        destination_location = self.route.rule_ids[-1].location_dest_id
        for line in self.work_order_lines:
            for subscription_line in line.subscription_line_ids:
                if len(subscription_line.entity_asset_id) > 0:
                    raise UserError(
                        _(f"Sorry, {subscription_line.display_name} in {line.identifier.name} already attached to another Fleet / Container: {subscription_line.entity_asset_id.name}")
                    )

            operation = {
                'group_id': group_id,
                'route_ids': self.route,
                'partner_id': self.partner_id.id,
                'date_planned': self.plan_datetime,
                'work_order_line_id': line.id,
                'entity_asset_id': line.identifier.id
            }
            operation_products = []
            
            for inv_transfer in line.inventory_transfers:
                reserved_product = inv_transfer.reserved_product_id
                if len(reserved_product.component_line_id) == 0:
                    continue

                if inv_transfer.is_need_component_placement and len(inv_transfer.component_placement_id) == 0:
                    raise UserError(
                        f"Sorry, {subscription_line.display_name} in {line.identifier.name} need to set Component Placement"
                    )

                op = operation.copy()
                op['subscription_line_id'] = inv_transfer.subscription_line_id.id
                op['component_line_id'] = reserved_product.component_line_id.id
                op['component_placement_id'] = inv_transfer.component_placement_id.id
                component = reserved_product.component_product_id
                operation_products.append(self.env['procurement.group'].Procurement(
                    component.product_variant_id,
                    inv_transfer.quantity,
                    reserved_product.product_uom,
                    destination_location,
                    reserved_product.name,
                    f'{self.name}/{line.identifier.id}',
                    reserved_product.company_id,
                    op
                ))
            self.env['procurement.group'].run(operation_products)
    
    def action_view_inventory_transfer(self):
        action = self.env["ir.actions.actions"]._for_xml_id("stock.action_picking_tree_all")
        action['domain'] = self._domain_inventory_transfer()
        return action
    
    def action_download_bast_implementation(self):
        return self.env.ref('mceasy_erp.action_report_implementation_bast').report_action(self)
        
    def _reserve_subscription(self):
        need_check_subs = self.work_order_type in ['install', 'activation', 'migrate', 'delivery']
        for line in self.work_order_lines:
            if need_check_subs and len(line.subscription_line_ids) == 0:
                raise UserError(f"Sorry, Make sure you fill product in identifier")
            for sub_line in line.subscription_line_ids:
                if self.work_order_type in ['install', 'activation', 'migrate', 'delivery']:
                    sub_line.entity_asset_id = line.identifier

    def _unreserve_subscription(self, subscription_line_ids=[]):
        if len(subscription_line_ids) == 0:
            subscription_line_ids = self.env['subscription.line']
            for line in self.work_order_lines:
                subscription_line_ids |= line.subscription_line_ids

        for sub_line in subscription_line_ids:
            if self.work_order_type in ['install', 'activation', 'migrate', 'delivery']:
                sub_line.entity_asset_id = False

    def _unreserve_activity(self):
        for line in self.work_order_activities:
            line.sale_product_contract_activity.action_activate_line(False)
    
    def _remove_all_related_transfer(self):
        pickings = self.env['stock.picking'].search([
            ('work_order_line_id', 'in', self.work_order_lines.ids)
        ])
        deleted_pickings = []
        moves = self.env['stock.move'].search([
            ('work_order_line_id', 'in', self.work_order_lines.ids)
        ])
        origin_moves = moves.mapped('move_orig_ids')
        origin_pickings = origin_moves.mapped('picking_id')
        pickings.action_cancel()
        origin_pickings_data = {}
        for origin_picking in origin_pickings:
            origin_pickings_data[origin_picking.id] = {
                'documents': [],
                'total_qty': 0
            }
            
            origin_picking.do_unreserve()
            if origin_picking.is_locked:
                origin_picking.action_toggle_is_locked()
        
        for origin_move in origin_moves:
            quantity = 0
            documents = []
            for chained_move in origin_move.move_dest_ids:
                quantity = quantity + chained_move.product_uom_qty
                if len(chained_move.group_id) == 0:
                    continue

                picking_document = chained_move.group_id.name
                if picking_document not in origin_pickings_data[origin_move.picking_id.id]['documents']:
                    origin_pickings_data[origin_move.picking_id.id]['documents'].append(picking_document)
                if picking_document not in documents:
                    documents.append(picking_document)
            if len(documents) > 0:
                origin_move.origin = '/'.join(documents)
            origin_move.product_uom_qty = quantity
            origin_pickings_data[origin_move.picking_id.id]['total_qty'] = origin_pickings_data[origin_move.picking_id.id]['total_qty'] + quantity
        

        for origin_picking in origin_pickings:
            documents = origin_pickings_data[origin_picking.id]['documents']
            if len(documents) > 0:
                origin_picking.origin = ','.join(documents)
            
            if origin_pickings_data[origin_picking.id]['total_qty'] == 0:
                origin_picking.action_cancel()
                origin_picking.unlink()
                deleted_pickings.append(origin_picking.id)
                continue

            origin_picking.action_assign()
        for p in pickings:
            if p.id in deleted_pickings:
                continue
            p.unlink()

    def _remove_all_related_component_check(self):
        for l in self.after_sale_components_check:
            l.unlink()

    def _get_active_subscription(self):
        subscription_ids = []
        for line in self.work_order_lines:
            for subscription_line in line.subscription_line_ids:
                if subscription_line.start_date == False:
                    continue

                if subscription_line.subscription_id.id not in subscription_ids:
                    subscription_ids.append(subscription_line.subscription_id.id)
        return subscription_ids
    
    @api.depends('work_order_lines')
    def _compute_subscription_count(self):
        self.subscription_count = len(self._get_active_subscription())

    def action_view_subscription(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'subscription',
            'view_mode': 'tree,form',
            'name': _('Subscriptions'),
            'domain': [
                ('id', 'in', self._get_active_subscription())
            ]
        }
    
        
