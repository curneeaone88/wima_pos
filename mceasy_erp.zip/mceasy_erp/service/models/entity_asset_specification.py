from odoo import models, fields, api


class EntityAssetSpecification(models.Model):
    _name = 'entity.asset.specification'
    _description = 'Asset Specification'

    manufacturer_id = fields.Many2one(
        related='model_id.manufacturer_id',
        store=True
    )
    model_id = fields.Many2one(
        comodel_name='entity.asset.specification.model',
        required=True
    )
    category_id = fields.Many2one(
        comodel_name='entity.asset.specification.category'
    )
    name = fields.Char(
        required=True
    )

    @api.depends('model_id')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = f'{rec.manufacturer_id.name} {rec.model_id.name} {rec.name}'

    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, order=None, name_get_uid=None):
        args = list(args or [])
        args += ['|', '|', '|', ('name', operator, name), ('model_id', operator, name), ('manufacturer_id', operator, name), ('category_id', operator, name)]
        return self._search(args, limit=limit, order=order, access_rights_uid=name_get_uid)
