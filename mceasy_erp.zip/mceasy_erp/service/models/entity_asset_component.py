from odoo import fields, models, api


class EntityAssetComponent(models.Model):
    _name = 'entity.asset.component'
    _description = 'Asset Component'

    move_id = fields.Many2one(
        comodel_name='stock.move',
        required=True,
        ondelete='restrict'
    )
    name = fields.Many2one(
        related='product_id.product_tmpl_id.component_id'
    )
    work_order_id = fields.Many2one(
        related='move_id.work_order_line_id.work_order_id'
    )
    assigned_owner_name = fields.Char(
        related='work_order_id.assigned_owner_id.name'
    )
    picking_id = fields.Many2one(
        related='move_id.picking_id'
    )
    component_line_id = fields.Many2one(
        comodel_name='product.package.component',
        string="Component Line",
        required=True
    )
    component_placement_id = fields.Many2one(
        comodel_name='product.component.placement',
        ondelete='restrict'
    )
    component_placement_external_code = fields.Char(
        related='component_placement_id.external_code'
    )
    entity_asset_id = fields.Many2one(
        comodel_name='entity.asset',
        required=True,
        ondelete='restrict'
    )
    subscription_line_id = fields.Many2one(
        comodel_name='subscription.line',
        required=True,
        ondelete='restrict'
    )
    product_id = fields.Many2one(
        comodel_name='product.product',
        required=True,
        ondelete='restrict'
    )
    product_tmpl_id = fields.Many2one(
        'product.template', string='Product Template',
        related='product_id.product_tmpl_id',
    )
    lot_id = fields.Many2one(
        comodel_name='stock.lot',
        ondelete='restrict'
    )
    quantity = fields.Float(
        'Quantity',
        required=True,
    )
    attached_on = fields.Datetime(
        required=True,
    )
    detached_on = fields.Datetime()
    active = fields.Boolean(
        default=True
    )