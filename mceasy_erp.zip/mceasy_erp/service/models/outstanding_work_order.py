from odoo import models, fields, api
from odoo.addons.mceasy_erp.service.models.work_order import WORK_ORDER_TYPES


class OutstandingWorkOrder(models.Model):
    _name = 'outstanding.work.order'
    _description = 'Outstanding Work Order'
    _order = 'id desc'

    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        default=lambda self: self.env.company)
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Partner',
        readonly=True
    )
    contract_id = fields.Many2one(
        comodel_name='sale.contract',
        string='Current Contract',
        readonly=True
    )
    contract = fields.Char(
        string='Contract',
        compute='_compute_contract'
    )
    quotation_id = fields.Many2one(
        comodel_name='sale.quotation',
        string='Quotation',
        readonly=True
    )
    sale_order_id = fields.Many2one(
        comodel_name='sale.order',
        string='Order',
        readonly=True
    )
    after_sale_order_id = fields.Many2one(
        comodel_name='after.sale.order',
        string='After Sale Order',
        readonly=True
    )
    product_contract_template_id = fields.Many2one(
        comodel_name='product.template',
        string='Product'
    )
    outstanding_work_order = fields.Selection(
        selection=WORK_ORDER_TYPES,
        string='Outstanding Work Order'
    )
    qty_after_sale_unit = fields.Integer(
        string='Qty Unit',
        compute='_compute_after_sale_unit'
    )
    qty_activity = fields.Integer(
        string='Qty Activity',
        compute='_compute_qty_activity'
    )
    qty_recurring = fields.Integer(
        string='Qty Subscription',
        compute='_compute_qty_recurring',
    )
    qty_one_time = fields.Integer(
        string='Qty One Time Fee',
        compute='_compute_qty_one_time',
    )
    active = fields.Boolean(
        default=True
    )
        
    def action_create_wo(self):
        qty_plans = []
        if self.qty_recurring > 0:
            qty_plans.append(self.qty_recurring)
        if self.qty_one_time > 0:
            qty_plans.append(self.qty_one_time)
        if self.qty_after_sale_unit > 0:
            qty_plans.append(self.qty_after_sale_unit)

        qty_plan = 0
        if len(qty_plans) > 0:
            qty_plan = min(qty_plans)

        ctx = {
            'default_partner_id': self.partner_id.id,
            'default_contract_id': self.contract_id.id,
            'default_company_id': self.company_id.id,
            'default_work_order_type': self.outstanding_work_order,
            'default_quantity_entity_plan': qty_plan,
            'default_creation_source': 'outstanding_work_order_menu',
            'default_ctx_sale_order_id': self.sale_order_id.id,
            'default_ctx_after_sale_order_id': self.after_sale_order_id.id,
            'default_ctx_product_contract_template_id': self.product_contract_template_id.id,
            'default_ctx_outstanding_work_order_id': self.id,
        }
        if len(self.after_sale_order_id) == 1:
            ctx.update({
                'default_plan_datetime': self.after_sale_order_id.scheduled_date
            })
        
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'work.order',
            'view_mode': 'form',
            'context': ctx
        }
    
    def _compute_contract(self):
        for rec in self:
            if len(rec.quotation_id) == 1:
                rec.contract = rec.quotation_id.contract_name
            else:
                rec.contract = rec.contract_id.name
    
    def _compute_qty_activity(self):
        for rec in self:
            domain = [
                ('outstanding_work_order', '=', rec.outstanding_work_order),
                ('contract_id', '=', rec.contract_id.id),
                ('work_order_id', '=', False),
            ]
            if len(rec.product_contract_template_id) > 0:
                domain.append(('product_template_id', '=', rec.product_contract_template_id.id))
            rec.qty_activity = self.env['sale.product.contract.activity'].search_count(domain)
    
    def _compute_after_sale_unit(self):
        for rec in self:
            rec.qty_after_sale_unit = 0
            if len(rec.after_sale_order_id) == 0:
                continue
            
            qty = 0
            for l in rec.after_sale_order_id.lines:
                is_all_subscription_done = True
                for s in l.subscription_line_ids:
                    if s.outstanding_work_order is False:
                        continue
                    if s.outstanding_work_order != rec.outstanding_work_order:
                        continue
                    is_all_subscription_done = False
                    break
                if not is_all_subscription_done:
                    qty += 1
            rec.qty_after_sale_unit = qty
    
    def _compute_qty_recurring(self):
        for rec in self:
            domain = [
                ('outstanding_work_order', '=', rec.outstanding_work_order),
                ('contract_id', '=', rec.contract_id.id),
                ('product_type', '=', 'package'),
            ]
            if len(rec.sale_order_id) > 0:
                domain.append(('sale_order_id', '=', rec.sale_order_id.id))
            if len(rec.after_sale_order_id) > 0:
                domain.append(('id', 'in', rec.after_sale_order_id.lines.subscription_line_ids.ids))
            if len(rec.product_contract_template_id) > 0:
                domain.append(('product_template_id', '=', rec.product_contract_template_id.id))
            rec.qty_recurring = self.env['subscription.line'].search_count(domain)

    def _compute_qty_one_time(self):
        for rec in self:
            domain = [
                ('outstanding_work_order', '=', rec.outstanding_work_order),
                ('contract_id', '=', rec.contract_id.id),
                ('product_type', '!=', 'package'),
            ]
            if len(rec.sale_order_id) > 0:
                domain.append(('sale_order_id', '=', rec.sale_order_id.id))
            if len(rec.product_contract_template_id) > 0:
                domain.append(('product_template_id', '=', rec.product_contract_template_id.id))
            rec.qty_one_time = self.env['subscription.line'].search_count(domain)