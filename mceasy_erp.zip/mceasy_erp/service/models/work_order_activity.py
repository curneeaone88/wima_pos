from odoo import models, fields


class WorkOrderActivity(models.Model):
    _name = 'work.order.activity'
    _description = 'Activities'

    work_order_id = fields.Many2one(
        comodel_name='work.order',
        ondelete='cascade'
    )
    name = fields.Char(
        related='sale_product_contract_activity.name'
    )
    product = fields.Char(
        related='sale_product_contract_activity.sale_product_contract_id.name'
    )
    product_template_id = fields.Many2one(
        related='sale_product_contract_activity.product_template_id'
    )
    description = fields.Text(
        string='Note'
    )
    sale_product_contract_activity = fields.Many2one(
        comodel_name='sale.product.contract.activity',
        required=True
    )
    actual_datetime = fields.Datetime(
        related='work_order_id.actual_datetime'
    )