from odoo import fields, models, api


class WorkOrderLineTransfer(models.Model):
    _name = 'work.order.line.transfer'
    _description = 'Transfered Product'

    work_order_id = fields.Many2one(
        related='work_order_line_id.work_order_id'
    )
    work_order_line_id = fields.Many2one(
        comodel_name='work.order.line',
        ondelete='cascade',
        required=True
    )
    quotation_line_id = fields.Many2one(
        related='subscription_line_id.quotation_line_id'
    )
    subscription_line_id = fields.Many2one(
        comodel_name='subscription.line',
        ondelete='restrict',
        required=True
    )
    reserved_product_id = fields.Many2one(
        comodel_name='sale.contract.reserved.product',
        ondelete='restrict',
        required=True
    )
    type = fields.Many2one(
        related='reserved_product_id.component_line_id'
    )
    component_id = fields.Many2one(
        related='reserved_product_id.component_line_id.component_id'
    )
    is_need_component_placement = fields.Boolean(
        compute='_compute_is_need_component_placement'
    )
    component_type = fields.Char(
        related='component_id.name'
    )
    component_placement_id = fields.Many2one(
        comodel_name='product.component.placement',
        ondelete='restrict'
    )
    component_product_id = fields.Many2one(
        comodel_name='product.template',
        related='reserved_product_id.component_product_id'
    )
    component_placement_external_code = fields.Char(
        related='component_placement_id.external_code'
    )
    component_product_default_code = fields.Char(
        related='reserved_product_id.component_product_id.default_code'
    )
    quantity = fields.Integer(
        default=None,
        required=True
    )
    quantity_actual = fields.Integer(
        compute='_compute_quantity_actual'
    )

    def _compute_quantity_actual(self):
        for rec in self:
            rec.quantity_actual = False
            move = self.env['stock.move'].search([
                ('work_order_line_id', '=', rec.work_order_line_id.id),
                ('subscription_line_id', '=', rec.subscription_line_id.id),
                ('product_id', '=', rec.reserved_product_id.component_product_id.product_variant_id.id),
            ], limit=1)
            if len(move) == 0:
                continue
            rec.quantity_actual = int(move._get_picked_quantity())

    @api.depends('component_id')
    def _compute_is_need_component_placement(self):
        for rec in self:
            if len(rec.component_id.available_placements) == 0:
                rec.is_need_component_placement = False
            else:
                rec.is_need_component_placement = True