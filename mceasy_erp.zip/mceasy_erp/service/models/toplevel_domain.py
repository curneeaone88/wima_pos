from odoo import models, fields


class ToplevelDomain(models.Model):
    _name = 'toplevel.domain'
    _description = 'Top Level Domain'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(
        required=True,
        tracking=1
    )
    status = fields.Boolean(
        default=True,
        tracking=1
    )