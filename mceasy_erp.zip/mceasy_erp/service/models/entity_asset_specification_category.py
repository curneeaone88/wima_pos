from odoo import models, fields


class EntityAssetSpecificationCategory(models.Model):
    _name = 'entity.asset.specification.category'
    _description = 'Asset Category'

    name = fields.Char(
        required=True
    )