from odoo import models, fields, api


class EntityAsset(models.Model):
    _name = 'entity.asset'
    _description = 'Fleet / Container'
    _sql_constraints = [
        ('unique_asset', 'unique (name, type, company_id, partner_id)', 'Asset already exist !')
    ]
    _order = 'id desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(
        string='Identifier',
        required=True,
        tracking=1
    )
    type = fields.Selection(
        selection=[
            ('vehicle', 'Vehicle'),
            ('container', 'Container'),
            ('user', 'User'),
            ('domain', 'Domain'),
        ],
        default='vehicle',
        required=True,
        tracking=1
    )
    specification_id = fields.Many2one(
        comodel_name='entity.asset.specification',
        tracking=True
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        default=lambda self: self.env.company)
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        domain="[('company_id', 'in', (False, company_id))]")
    contract_id = fields.Many2one(
        related='partner_id.contract_id',
    )
    partner_domain_id = fields.Many2one(
        comodel_name='partner.domain',
        string='Registered on Domain',
        tracking=1
    )
    components = fields.One2many(
        comodel_name='entity.asset.component',
        inverse_name='entity_asset_id',
        string='Components',
        context={
            'active_test': False,
        }
    )

    inventory_components = fields.One2many(
        comodel_name='stock.quant',
        inverse_name='entity_asset_id',
        string='Inventory Components',
        domain=[
            ('quantity', '>', 0)
        ]
    )
    subscriptions = fields.One2many(
        comodel_name='subscription.line',
        inverse_name='entity_asset_id',
        string='Subscriptions'
    )

    def action_detail(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'entity.asset',
            'res_id': self.id,
            'view_mode': 'form'
        }

