from odoo import models, fields


class EntityAssetSpecificationManufacturer(models.Model):
    _name = 'entity.asset.specification.manufacturer'
    _description = 'Manufacturer'

    name = fields.Char(
        required=True
    )