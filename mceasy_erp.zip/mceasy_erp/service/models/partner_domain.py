import json

from odoo import models, fields, api, _
from odoo.exceptions import UserError
import requests


class PartnerDomain(models.Model):
    _name = 'partner.domain'
    _description = 'Customer Domain'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _sql_constraints = [
        ('unique_name', 'UNIQUE(name,tld_id)', 'Domain Name already exist, please create unique per customer!'),
        ('unique_user_email', 'UNIQUE(user_email)', 'Email already exist, please use another email!')
    ]

    name = fields.Char(
        required=True,
        tracking=1
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        default=lambda x: x.env.company.id
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        required=True,
        tracking=1
    )
    status = fields.Boolean(
        default=True,
        tracking=1
    )
    entity_assets = fields.One2many(
        comodel_name='entity.asset',
        inverse_name='partner_domain_id'
    )
    user_email = fields.Char(
        required=True,
        tracking=1
    )
    tld_id = fields.Many2one(
        'toplevel.domain',
        required=True,
        tracking=1
    )
    branch_ids = fields.One2many('partner.branch.domain', 'domain_id')

    @api.onchange('partner_id')
    def _compute_get_email(self):
        for rec in self:
            if not rec.partner_id:
                continue

            if rec.partner_id.email:
                rec.user_email = rec.partner_id.email
                continue

            get_mail = self.env['res.partner'].search_read(
                [['parent_id', '=', rec.partner_id.id], ['contact_type', '=', 'employee']], ['email']
            )
            rec.user_email = get_mail[0]['email']

    def tools_config(self):
        url = self.env['ir.config_parameter'].get_param('tools.host', 'https://api-release.mceasy.com/tools/v1/company')
        secret = self.env['ir.config_parameter'].get_param('tools.secret', 'secret')
        headers = {
            'Authorization': f'Bearer {secret}',
            'Content-Type': 'application/json'
        }
        return url, headers

    def generate_paylod(self,isSendEmail):
        payload = {
            "companyName": self.partner_id.name,
            "domainName": f"{self.name}.{self.tld_id.name}",
            "userEmail": self.user_email,
            "isSendEmail": isSendEmail,
            "isWhitelabel": False,
        }
        return payload

    def get_company_id_by_domain(self,domain):
        url, headers = self.tools_config()
        filters = f'?page=1&size=10&q={domain}'
        search_wo = requests.get(f'{url}{filters}', headers=headers)
        return search_wo.json()

    def create_domain(self):
        url, headers = self.tools_config()
        data = self.generate_paylod(isSendEmail=True)

        try:
            response = requests.post(f"{url}", headers=headers, json=data)
            response.raise_for_status()
            self.chatter_note(
                'Set Domain Success',
                f"Domain {self.name}.{self.tld_id.name} set to {self.partner_id.name}"
            )
        except requests.exceptions.HTTPError as e:
            responses = json.loads(e.response.content.decode('utf-8'))
            message = responses
            if len(responses['details']) > 0:
                message = responses['details'][0]['message']
            self.chatter_note(
                'Error Setup Domain',
                f"Error {message} for {self.name}.{self.tld_id.name}"
            )

    def update_domain(self, last_domain):
        url, headers = self.tools_config()
        partner_id=self.get_company_id_by_domain(last_domain)

        if len(partner_id.get('data')) < 1:
            self.create_domain()
            return

        patch_url = f"{url}/{partner_id.get('data')[0]['companyId']}"        
        data = self.generate_paylod(isSendEmail = False)
        
        try:
            response = requests.patch(f"{patch_url}", headers=headers, json=data)
            response.raise_for_status()
            self.chatter_note(
                'Set Domain Success',
                f"Domain {self.name}.{self.tld_id.name} set to {self.partner_id.name}"
            )
        except requests.exceptions.HTTPError as e:
            responses = json.loads(e.response.content.decode('utf-8'))
            message = responses
            if len(responses['details']) > 0:
                message = responses['details'][0]['message']
            
            self.chatter_note(
                'Error Setup Domain',
                f"Error {message} for {self.name}.{self.tld_id.name}"
            )

    def chatter_note(self, sbj, msg):
        self._message_log(
            subject=sbj,
            body=msg,
            author_id=self.env.user.partner_id.id,
            partner_ids=[self.partner_id.id],
            message_type='notification'
        )

    @api.model
    def create(self, vals):
        res = super(PartnerDomain, self).create(vals)
        res.create_domain()

        return res

    @api.model
    def write(self, vals):
        last_domain = f"{self.name}.{self.tld_id.name}"
        res = super(PartnerDomain, self).write(vals)
        self.update_domain(last_domain)

        return res

class BranchDomain(models.Model):
    _name = 'partner.branch.domain'
    _description = 'Partner Branch'

    domain_id = fields.Many2one('partner.domain')
    partner_id = fields.Many2one('res.partner')
