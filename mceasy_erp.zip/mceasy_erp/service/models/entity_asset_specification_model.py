from odoo import models, fields


class EntityAssetSpecificationModel(models.Model):
    _name = 'entity.asset.specification.model'
    _description = 'Model'

    manufacturer_id = fields.Many2one(
        comodel_name='entity.asset.specification.manufacturer',
        required=True
    )
    name = fields.Char(
        required=True
    )