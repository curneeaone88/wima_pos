from odoo import models, fields, _


class WorkOrderLineComponentCheck(models.Model):
    _name = 'work.order.line.component.check'
    _description = 'After Sale Component Check'

    work_order_id = fields.Many2one(
        related='work_order_line_id.work_order_id',
        store=True,
        ondelete='cascade'
    )
    work_order_line_id = fields.Many2one(
        comodel_name='work.order.line'
    )
    after_sale_order_id = fields.Many2one(
        comodel_name='after.sale.order',
        related='after_sale_order_line_id.after_sale_order_id',
        store=True
    )
    subscription_line_id = fields.Many2one(
        comodel_name='subscription.line'
    )
    after_sale_order_line_id = fields.Many2one(
        comodel_name='after.sale.order.line',
        required=True
    )
    entity_asset_id = fields.Many2one(
        related='entity_asset_component_id.entity_asset_id',
        store=True
    )
    new_entity_asset_id = fields.Many2one(
        comodel_name='entity.asset'
    )
    entity_asset_component_id = fields.Many2one(
        comodel_name='entity.asset.component'
    )
    component_id = fields.Many2one(
        related='entity_asset_component_id.component_line_id.component_id'
    )
    component_placement_id = fields.Many2one(
        comodel_name='product.component.placement',
        ondelete='restrict'
    )
    component_placement_external_code = fields.Char(
        related='component_placement_id.external_code'
    )
    component_product_default_code = fields.Char(
        related='entity_asset_component_id.product_tmpl_id.default_code'
    )
    product_id = fields.Many2one(
        related='entity_asset_component_id.product_id',
        store=True
    )
    lot_id = fields.Many2one(
        related='entity_asset_component_id.lot_id',
        store=True
    )
    quantity = fields.Float(
        'Quantity',
        required=True,
    )
    healthy = fields.Selection(
        selection=[
            ('need_check', 'Need to Check'),
            ('good', 'Good'),
            ('bad', 'Bad'),
        ],
        default='need_check',
        required=True,
    )
    action = fields.Selection(
        selection=[
            ('not_checked', 'Not Checked'),
            ('checked', 'Checked'),
            ('replaced', 'Replaced'),
        ]
    )
    note = fields.Text()
