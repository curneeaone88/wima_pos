from odoo import models, fields


class UomCategory(models.Model):
    _inherit = 'uom.category'

    for_sale_quotation = fields.Boolean(
        default=False
    )