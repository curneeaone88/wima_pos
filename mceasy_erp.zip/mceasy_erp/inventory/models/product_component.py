from odoo import models, fields, api


class ProductComponent(models.Model):
    _name = 'product.component'
    _description = 'Component Type'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Name', required=True, tracking=True)
    fulfill_quantity = fields.Boolean(
        string='Quantity must fulfilled',
        default=True,
        tracking=True
    )
    available_placements = fields.One2many(
        comodel_name='product.component.placement',
        inverse_name='product_component_id',
        tracking=True
    )