from odoo import _, fields, models, api, tools
from odoo.addons.mceasy_erp.common.helper import domain_quotation_pricelist_by_uom_category
from odoo.addons.mceasy_erp.service.models.work_order import WORK_ORDER_SALE_TYPES, WORK_ORDER_CHURN_TYPES
from odoo.exceptions import ValidationError

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    detailed_type = fields.Selection(selection_add=[('package', 'Subscription / Purchase Package')], ondelete={'package': 'set default'})
    type = fields.Selection(selection_add=[('package', 'Subscription / Purchase Package')], ondelete={'package': 'set service'})

    package_component_ids = fields.One2many('product.package.component', 'product_id', string='Components')
    deduction_account_ids = fields.One2many('product.deduction.account', 'product_id', string='Deduction Journal Item')
    component_id = fields.Many2one('product.component', string='Component Type')
    discounted_price = fields.Float(digits=(16, 2), string="Discounted Price", default=False, tracking=True)
    list_price = fields.Float(
        'Standart Price', default=1.0,
        digits='Product Price',
        help="Price at which the product is sold to customers.",
        tracking=True
    )
    recurring_invoice = fields.Boolean(string='Recurring', default=False, compute='_compute_recurring_invoice', store=True)
    uom_category = fields.Many2one(related='uom_id.category_id')
    product_operation_id = fields.Many2one(
        comodel_name='product.operation.template',
        string='Product Operation'
    )
    domain_routes = fields.Many2many(
        comodel_name='stock.route',
        compute='_compute_domain_routes'
    )

    domain_uom_package = fields.One2many(
        comodel_name='uom.category',
        compute='_domain_uom_package'
    )
    is_quotation_pricelist = fields.Boolean(
        compute='_compute_is_quotation_pricelist',
        string="For Quotation",
        store=True
    )

    point = fields.Float(string="Point")

    @api.constrains("point")
    def _validate_point(self):
        for rec in self:
            if rec.point < 0:
                raise ValidationError("Maaf, point tidak boleh kurang dari 0")


    def _compute_product_tooltip(self):
        super()._compute_product_tooltip()
        for record in self:
            if record.detailed_type == 'package':
                record.product_tooltip += _(
                    "Subscription Package is a recurring product which need a work order to do when it purchased or returned"
                )

    @api.onchange('detailed_type')
    def _onchange_detailed_type_package(self):
        if self.detailed_type == 'package':
            self.uom_id = self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month')
        else:
            for component_id in self.package_component_ids:
                self.write({'package_component_ids': [(2, component_id._origin.id, 0)]})

            for account_id in self.deduction_account_ids:
                self.write({'deduction_account_ids': [(2, account_id._origin.id, 0)]})

    @api.depends('detailed_type', 'uom_id')
    def _compute_recurring_invoice(self):
        for rec in self:
            rec.recurring_invoice = False
            if len(rec.uom_id) == 0:
                continue
            if rec.detailed_type != 'package':
                continue

            recurring_uoms = [
                self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month').id,
                self.env.ref('mceasy_erp.product_uom_package_subscription_usage_month').id,
            ]
            rec.recurring_invoice = rec.uom_id.id in recurring_uoms 
    
    @api.onchange('is_quotation_pricelist')
    def _onchange_is_quotation_pricelist(self):
        if not self.is_quotation_pricelist:
            self.product_operation_id = False
            self.uom_id = self.env.ref('uom.product_uom_unit')
            self.uom_po_id = self.env.ref('uom.product_uom_unit')

    @api.depends('detailed_type')
    def _domain_uom_package(self):
        for rec in self:
            rec.domain_uom_package = [
                self.env.ref('mceasy_erp.product_uom_categ_purchase').id,
                self.env.ref('mceasy_erp.product_uom_categ_package_subscription').id,
            ]

    @api.depends('uom_id')
    def _compute_is_quotation_pricelist(self):
        for rec in self:
            rec.is_quotation_pricelist = rec.uom_category in domain_quotation_pricelist_by_uom_category(self)
    
    @api.depends('product_operation_id', 'is_quotation_pricelist')
    def _compute_domain_routes(self):
        if not self.is_quotation_pricelist:
            self.domain_routes = self.env['stock.route'].search([
                ('product_selectable', '=', True)
            ])
            return

        domain = []
        if len(self.product_operation_id) == 1:
            for line in self.product_operation_id.sale_operations:
                domain.append(line.work_order_type)
            for line in self.product_operation_id.churn_operations:
                domain.append(line.work_order_type)
        
        self.domain_routes = self.env['stock.route'].search([
            ('product_selectable', '=', True),
            ('work_order_applicable', 'in', domain)
        ])