from odoo import _, models, fields, api
from odoo.tools.float_utils import float_compare, float_is_zero, float_round
from odoo.tools.misc import OrderedSet, groupby

class StockMove(models.Model):
    _inherit = 'stock.move'

    is_owner_handover = fields.Boolean(
        related='picking_id.is_owner_handover'
    )

    owner_src_id = fields.Many2one(
        comodel_name='res.partner',
        compute='_compute_owner_src_id'
    )

    work_order_line_id = fields.Many2one(
        comodel_name='work.order.line'
    )

    asset_activity = fields.Selection(
        related='picking_id.asset_activity'
    )

    entity_asset_id = fields.Many2one(
        comodel_name='entity.asset',
        string='Asset'
    )
    new_entity_asset_id = fields.Many2one(
        comodel_name='entity.asset',
        related='work_order_line_id.new_identifier'
    )
    subscription_line_id = fields.Many2one(
        comodel_name='subscription.line',
        string='Product by Subscription'
    )
    component_line_id = fields.Many2one(
        comodel_name='product.package.component',
        string="Component Line",
    )
    component_id = fields.Many2one(
        related='component_line_id.component_id'
    )
    available_placements = fields.One2many(
        related='component_id.available_placements'
    )
    component_placement_id = fields.Many2one(
        comodel_name='product.component.placement',
        ondelete='restrict'
    )
    component_placement_external_code = fields.Char(
        related='component_placement_id.external_code',
        store=True
    )

    @api.depends('picking_id')
    def _compute_owner_src_id(self):
        if self.picking_id.is_owner_handover:
            self.owner_src_id = self.picking_id.owner_src_id
        else:
            self.owner_src_id = False

    def _action_assign(self, force_qty=False):
        """ Reserve stock moves by creating their stock move lines. A stock move is
        considered reserved once the sum of `reserved_qty` for all its move lines is
        equal to its `product_qty`. If it is less, the stock move is considered
        partially available.
        """
        StockMove = self.env['stock.move']
        assigned_moves_ids = OrderedSet()
        partially_available_moves_ids = OrderedSet()
        # Read the `reserved_availability` field of the moves out of the loop to prevent unwanted
        # cache invalidation when actually reserving the move.
        reserved_availability = {move: move.quantity for move in self}

        roundings = {move: move.product_id.uom_id.rounding for move in self}
        move_line_vals_list = []
        # Once the quantities are assigned, we want to find a better destination location thanks
        # to the putaway rules. This redirection will be applied on moves of `moves_to_redirect`.
        moves_to_redirect = OrderedSet()
        moves_to_assign = self
        if not force_qty:
            moves_to_assign = moves_to_assign.filtered(
                lambda m: not m.picked and m.state in ['confirmed', 'waiting', 'partially_available']
            )
        moves_to_reserve = moves_to_assign.filtered(lambda m: not m._should_bypass_reservation())
        quants_by_product = self.env['stock.quant']._get_quants_by_products_locations(moves_to_reserve.product_id, moves_to_reserve.location_id)


        for move in moves_to_assign:
            # store entity_asset_id
            if move.picking_id.is_owner_handover and move.asset_activity in ['attach', 'detach']:
                move.entity_asset_id = move.picking_id.entity_asset_id

            rounding = roundings[move]
            if not force_qty:
                missing_reserved_uom_quantity = move.product_uom_qty - reserved_availability[move]
            else:
                missing_reserved_uom_quantity = force_qty
            if float_compare(missing_reserved_uom_quantity, 0, precision_rounding=rounding) <= 0:
                assigned_moves_ids.add(move.id)
                continue
            missing_reserved_quantity = move.product_uom._compute_quantity(missing_reserved_uom_quantity, move.product_id.uom_id, rounding_method='HALF-UP')
            quants = quants_by_product[move.product_id.id]
            if move._should_bypass_reservation():
                # create the move line(s) but do not impact quants
                if move.move_orig_ids:
                    available_move_lines = move._get_available_move_lines(assigned_moves_ids, partially_available_moves_ids)
                    for (location_id, lot_id, package_id, owner_id, entity_asset_id), quantity in available_move_lines.items():
                        qty_added = min(missing_reserved_quantity, quantity)
                        move_line_vals = move._prepare_move_line_vals(qty_added)
                        move_line_vals.update({
                            'location_id': location_id.id,
                            'lot_id': lot_id.id,
                            'lot_name': lot_id.name,
                            'owner_id': owner_id.id,
                            'entity_asset_id': entity_asset_id.id,
                            'package_id': package_id.id,
                        })
                        move_line_vals_list.append(move_line_vals)
                        missing_reserved_quantity -= qty_added
                        if float_is_zero(missing_reserved_quantity, precision_rounding=move.product_id.uom_id.rounding):
                            break

                if missing_reserved_quantity and move.product_id.tracking == 'serial' and (move.picking_type_id.use_create_lots or move.picking_type_id.use_existing_lots):
                    for i in range(0, int(missing_reserved_quantity)):
                        move_line_vals_list.append(move._prepare_move_line_vals(quantity=1))
                elif missing_reserved_quantity:
                    to_update = move.move_line_ids.filtered(lambda ml: ml.product_uom_id == move.product_uom and
                                                            ml.location_id == move.location_id and
                                                            ml.location_dest_id == move.location_dest_id and
                                                            ml.picking_id == move.picking_id and
                                                            not ml.picked and
                                                            not ml.lot_id and
                                                            not ml.result_package_id and
                                                            not ml.package_id and
                                                            not ml.owner_id and
                                                            not ml.entity_asset_id)
                    if to_update:
                        to_update[0].quantity += move.product_id.uom_id._compute_quantity(
                            missing_reserved_quantity, move.product_uom, rounding_method='HALF-UP')
                    else:
                        move_line_vals_list.append(move._prepare_move_line_vals(quantity=missing_reserved_quantity))
                assigned_moves_ids.add(move.id)
                moves_to_redirect.add(move.id)
            else:
                if float_is_zero(move.product_uom_qty, precision_rounding=move.product_uom.rounding) and not force_qty:
                    assigned_moves_ids.add(move.id)
                elif not move.move_orig_ids:
                    if move.procure_method == 'make_to_order':
                        continue
                    # If we don't need any quantity, consider the move assigned.
                    need = missing_reserved_quantity
                    if float_is_zero(need, precision_rounding=rounding):
                        assigned_moves_ids.add(move.id)
                        continue
                    # Reserve new quants and create move lines accordingly.
                    forced_package_id = move.package_level_id.package_id or None
                    entity_asset_detach = move.picking_id.entity_asset_id if move.picking_id.asset_activity == 'detach' else (type('',(object,),{"id": -1}))()
                    if len(move.picking_id) == 1 and move.picking_id.is_owner_handover:
                        from_owner_id = move.picking_id.owner_src_id if len(move.picking_id.owner_src_id) == 1 else (type('',(object,),{"id": -1}))()
                        lot_id = False
                        if move.has_tracking in ['serial', 'lot']:
                            lot_id = (type('',(object,),{"id": -1}))()
                        taken_quantity = move._update_reserved_quantity(need, move.location_id, quant_ids=quants, lot_id=lot_id, package_id=forced_package_id, owner_id=from_owner_id, entity_asset_id=entity_asset_detach, strict=False)
                    else:
                        taken_quantity = move._update_reserved_quantity(need, move.location_id, quant_ids=quants, package_id=forced_package_id, entity_asset_id=entity_asset_detach, strict=False)
                    
                    if float_is_zero(taken_quantity, precision_rounding=rounding):
                        continue
                    moves_to_redirect.add(move.id)
                    if float_compare(need, taken_quantity, precision_rounding=rounding) == 0:
                        assigned_moves_ids.add(move.id)
                    else:
                        partially_available_moves_ids.add(move.id)
                else:
                    # Check what our parents brought and what our siblings took in order to
                    # determine what we can distribute.
                    # `quantity` is in `ml.product_uom_id` and, as we will later increase
                    # the reserved quantity on the quants, convert it here in
                    # `product_id.uom_id` (the UOM of the quants is the UOM of the product).
                    available_move_lines = move._get_available_move_lines(assigned_moves_ids, partially_available_moves_ids)
                    if not available_move_lines:
                        continue
                    for move_line in move.move_line_ids.filtered(lambda m: m.quantity_product_uom):
                        if available_move_lines.get((move_line.location_id, move_line.lot_id, move_line.result_package_id, move_line.owner_id, move_line.entity_asset_id)):
                            available_move_lines[(move_line.location_id, move_line.lot_id, move_line.result_package_id, move_line.owner_id, move_line.entity_asset_id)] -= move_line.quantity_product_uom
                    for (location_id, lot_id, package_id, owner_id, entity_asset_id), quantity in available_move_lines.items():
                        need = move.product_qty - sum(move.move_line_ids.mapped('quantity_product_uom'))
                        # `quantity` is what is brought by chained done move lines. We double check
                        # here this quantity is available on the quants themselves. If not, this
                        # could be the result of an inventory adjustment that removed totally of
                        # partially `quantity`. When this happens, we chose to reserve the maximum
                        # still available. This situation could not happen on MTS move, because in
                        # this case `quantity` is directly the quantity on the quants themselves.
                        entity_asset_detach = entity_asset_id if move.asset_activity == 'detach' else (type('',(object,),{"id": -1}))()
                        if len(self.picking_id) == 1 and self.picking_id.is_owner_handover:
                            from_owner_id = self.picking_id.owner_src_id if len(self.picking_id.owner_src_id) == 1 else (type('',(object,),{"id": -1}))()
                            taken_quantity = move._update_reserved_quantity(min(quantity, need), location_id, quants, lot_id, package_id, from_owner_id, entity_asset_detach)
                        else:
                            taken_quantity = move._update_reserved_quantity(min(quantity, need), location_id, quants, lot_id, package_id, owner_id, entity_asset_detach)

                        if float_is_zero(taken_quantity, precision_rounding=rounding):
                            continue
                        moves_to_redirect.add(move.id)
                        if float_is_zero(need - taken_quantity, precision_rounding=rounding):
                            assigned_moves_ids.add(move.id)
                            break
                        partially_available_moves_ids.add(move.id)
            if move.product_id.tracking == 'serial':
                move.next_serial_count = move.product_uom_qty

        self.env['stock.move.line'].create(move_line_vals_list)
        StockMove.browse(partially_available_moves_ids).write({'state': 'partially_available'})
        StockMove.browse(assigned_moves_ids).write({'state': 'assigned'})
        if not self.env.context.get('bypass_entire_pack'):
            self.picking_id._check_entire_pack()
        StockMove.browse(moves_to_redirect).move_line_ids._apply_putaway_strategy()

    def _key_assign_picking(self):
        keys = super(StockMove, self)._key_assign_picking()
        if self.work_order_line_id:
            extra_keys = (self.work_order_line_id, )
            keys = keys + extra_keys
        return keys
    
    def _search_picking_for_assignation_domain(self):
        domain = super(StockMove, self)._search_picking_for_assignation_domain()
        group = self.env['procurement.group'].search([
            ('name', '=', self.origin)
        ])
        if len(group) == 1 and len(group.work_order_id) == 1:
            domain += [('owner_id', '=', group.work_order_id.assigned_owner_id.id)]

        if self.work_order_line_id:
            domain += [('work_order_line_id', '=', self.work_order_line_id.id)]
        return domain
    
    def _get_new_picking_values(self):
        picking = super(StockMove, self)._get_new_picking_values()
        if self.work_order_line_id:
            picking['work_order_line_id'] = self.work_order_line_id.id
            picking['entity_asset_id'] = self.work_order_line_id.get_expected_entity_asset(self.mapped('picking_type_id'))
        return picking
    
    def _assign_picking(self):
        """ Try to assign the moves to an existing picking that has not been
        reserved yet and has the same procurement group, locations and picking
        type (moves should already have them identical). Otherwise, create a new
        picking to assign them to. """
        Picking = self.env['stock.picking']
        grouped_moves = groupby(self, key=lambda m: m._key_assign_picking())
        for group, moves in grouped_moves:
            moves = self.env['stock.move'].concat(*moves)
            new_picking = False
            # Could pass the arguments contained in group but they are the same
            # for each move that why moves[0] is acceptable
            picking = moves[0]._search_picking_for_assignation()
            if picking:
                # If a picking is found, we'll append `move` to its move list and thus its
                # `partner_id` and `ref` field will refer to multiple records. In this
                # case, we chose to wipe them.
                vals = {}
                if any(picking.partner_id.id != m.partner_id.id for m in moves):
                    vals['partner_id'] = False
                if any(picking.origin != m.origin for m in moves):
                    origins = []
                    if picking.origin != False:
                        origins = picking.origin.split(',')
                    for m in moves:
                        if m.origin in origins:
                            continue
                        origins.append(m.origin)
                    vals['origin'] = ','.join(origins)
                if vals:
                    picking.write(vals)
            else:
                # Don't create picking for negative moves since they will be
                # reverse and assign to another picking
                moves = moves.filtered(lambda m: float_compare(m.product_uom_qty, 0.0, precision_rounding=m.product_uom.rounding) >= 0)
                if not moves:
                    continue
                new_picking = True
                picking = Picking.create(moves._get_new_picking_values())

            moves.write({'picking_id': picking.id})
            moves._assign_picking_post_process(new=new_picking)
        return True

    def _assign_picking_post_process(self, new=False):
        super(StockMove, self)._assign_picking_post_process(new=new)
        if not new:
            return

        work_order_line_ids = self.mapped('work_order_line_id')
        picking_id = self.mapped('picking_id')
        if len(work_order_line_ids) == 1:
            work_order_line = work_order_line_ids[0]
            if picking_id.picking_type_id.asset_activity == 'attach':
                picking_id.write({
                    'owner_src_id': work_order_line.assigned_owner_id.id,
                    'owner_id': work_order_line.partner_id.id
                })
            else:
                picking_id.write({
                    'owner_id': work_order_line.assigned_owner_id.id,
                    'owner_src_id': work_order_line.partner_id.id
                })
        origins = []
        if picking_id.origin != False:
            origins = picking_id.origin.split(',')
        if len(origins) > 0:
            group = self.env['procurement.group'].search([
                ('name', '=', origins[0])
            ])
            if len(group) == 1 and len(group.work_order_id) == 1:
                picking_id.write({
                    'owner_src_id': group.work_order_id.company_id.partner_id.id,
                    'owner_id': group.work_order_id.assigned_owner_id.id
                })
    
    def _get_available_move_lines_in(self):
        move_lines_in = self.move_orig_ids.filtered(lambda m: m.state == 'done').mapped('move_line_ids')

        def _keys_in_groupby(ml):
            return (ml.location_dest_id, ml.lot_id, ml.result_package_id, ml.owner_id, ml.entity_asset_id)

        grouped_move_lines_in = {}
        for k, g in groupby(move_lines_in, key=_keys_in_groupby):
            quantity = 0
            for ml in g:
                quantity += ml.product_uom_id._compute_quantity(ml.quantity, ml.product_id.uom_id)
            grouped_move_lines_in[k] = quantity

        return grouped_move_lines_in

    def _get_available_move_lines_out(self, assigned_moves_ids, partially_available_moves_ids):
        move_lines_out_done = (self.move_orig_ids.mapped('move_dest_ids') - self)\
            .filtered(lambda m: m.state in ['done'])\
            .mapped('move_line_ids')
        # As we defer the write on the stock.move's state at the end of the loop, there
        # could be moves to consider in what our siblings already took.
        StockMove = self.env['stock.move']
        moves_out_siblings = self.move_orig_ids.mapped('move_dest_ids') - self
        moves_out_siblings_to_consider = moves_out_siblings & (StockMove.browse(assigned_moves_ids) + StockMove.browse(partially_available_moves_ids))
        reserved_moves_out_siblings = moves_out_siblings.filtered(lambda m: m.state in ['partially_available', 'assigned'])
        move_lines_out_reserved = (reserved_moves_out_siblings | moves_out_siblings_to_consider).mapped('move_line_ids')

        def _keys_out_groupby(ml):
            return (ml.location_id, ml.lot_id, ml.package_id, ml.owner_id, ml.entity_asset_id)

        grouped_move_lines_out = {}
        for k, g in groupby(move_lines_out_done, key=_keys_out_groupby):
            quantity = 0
            for ml in g:
                quantity += ml.product_uom_id._compute_quantity(ml.quantity, ml.product_id.uom_id)
            grouped_move_lines_out[k] = quantity
        for k, g in groupby(move_lines_out_reserved, key=_keys_out_groupby):
            grouped_move_lines_out[k] = sum(self.env['stock.move.line'].concat(*list(g)).mapped('quantity_product_uom'))
        
        return grouped_move_lines_out
    
    def _update_reserved_quantity(self, need, location_id, quant_ids=None, lot_id=None, package_id=None, owner_id=None, entity_asset_id=None, strict=True):
        """ Create or update move lines and reserves quantity from quants
            Expects the need (qty to reserve) and location_id to reserve from.
            `quant_ids` can be passed as an optimization since no search on the database
            is performed and reservation is done on the passed quants set
        """
        self.ensure_one()
        if quant_ids is None:
            quant_ids = self.env['stock.quant']
        if not lot_id:
            lot_id = self.env['stock.lot']
        if not package_id:
            package_id = self.env['stock.quant.package']
        if not owner_id:
            owner_id = self.env['res.partner']
        if not entity_asset_id:
            entity_asset_id = self.env['entity.asset']

        quants = quant_ids._get_reserve_quantity(
            self.product_id, location_id, need, product_packaging_id=self.product_packaging_id,
            uom_id=self.product_uom, lot_id=lot_id, package_id=package_id, owner_id=owner_id, entity_asset_id=entity_asset_id, strict=strict)

        taken_quantity = 0
        rounding = self.env['decimal.precision'].precision_get('Product Unit of Measure')
        # Find a candidate move line to update or create a new one.
        for reserved_quant, quantity in quants:
            taken_quantity += quantity
            to_update = next((line for line in self.move_line_ids if line._reservation_is_updatable(quantity, reserved_quant)), False)
            if to_update:
                uom_quantity = self.product_id.uom_id._compute_quantity(quantity, to_update.product_uom_id, rounding_method='HALF-UP')
                uom_quantity = float_round(uom_quantity, precision_digits=rounding)
                uom_quantity_back_to_product_uom = to_update.product_uom_id._compute_quantity(uom_quantity, self.product_id.uom_id, rounding_method='HALF-UP')
            if to_update and float_compare(quantity, uom_quantity_back_to_product_uom, precision_digits=rounding) == 0:
                to_update.with_context(reserved_quant=reserved_quant).quantity += uom_quantity
            else:
                if self.product_id.tracking == 'serial':
                    vals_list = self._add_serial_move_line_to_vals_list(reserved_quant, quantity)
                    if vals_list:
                        self.env['stock.move.line'].with_context(reserved_quant=reserved_quant).create(vals_list)
                else:
                    self.env['stock.move.line'].with_context(reserved_quant=reserved_quant).create(self._prepare_move_line_vals(quantity=quantity, reserved_quant=reserved_quant))
        return taken_quantity

    def _prepare_move_line_vals(self, quantity=None, reserved_quant=None):
        self.ensure_one()
        vals = {
            'move_id': self.id,
            'product_id': self.product_id.id,
            'product_uom_id': self.product_uom.id,
            'location_id': self.location_id.id,
            'location_dest_id': self.location_dest_id.id,
            'picking_id': self.picking_id.id,
            'company_id': self.company_id.id,
        }
        if quantity:
            # TODO could be also move in create/write
            rounding = self.env['decimal.precision'].precision_get('Product Unit of Measure')
            uom_quantity = self.product_id.uom_id._compute_quantity(quantity, self.product_uom, rounding_method='HALF-UP')
            uom_quantity = float_round(uom_quantity, precision_digits=rounding)
            uom_quantity_back_to_product_uom = self.product_uom._compute_quantity(uom_quantity, self.product_id.uom_id, rounding_method='HALF-UP')
            if float_compare(quantity, uom_quantity_back_to_product_uom, precision_digits=rounding) == 0:
                vals = dict(vals, quantity=uom_quantity)
            else:
                vals = dict(vals, quantity=quantity, product_uom_id=self.product_id.uom_id.id)
        package = None
        if reserved_quant:
            package = reserved_quant.package_id
            vals = dict(
                vals,
                location_id=reserved_quant.location_id.id,
                lot_id=reserved_quant.lot_id.id or False,
                package_id=package.id or False,
                owner_id=reserved_quant.owner_id.id or False,
                entity_asset_id=reserved_quant.entity_asset_id.id or False,
            )
        return vals

    def _get_available_quantity(self, location_id, lot_id=None, package_id=None, owner_id=None, entity_asset_id=None, strict=False, allow_negative=False):
        self.ensure_one()
        if location_id.should_bypass_reservation():
            return self.product_qty
        
        # use strict for asset activity
        if self.picking_id.picking_type_id.asset_activity != False:
            strict = True

        return self.env['stock.quant']._get_available_quantity(self.product_id, location_id, lot_id=lot_id, package_id=package_id, owner_id=owner_id, entity_asset_id=entity_asset_id, strict=strict, allow_negative=allow_negative)

    @api.model
    def _prepare_merge_moves_distinct_fields(self):
        fields = super(StockMove, self)._prepare_merge_moves_distinct_fields()

        if len(self.subscription_line_id) > 0:
            fields += ['subscription_line_id', 'component_placement_id']
        return fields
    
    @api.model_create_multi
    def create(self, vals_list):
        res = super(StockMove, self).create(vals_list)
        # make sure attach activity component placement is match with component check
        for move in res:
            if len(move.picking_type_id) == 1 \
                and len(move.work_order_line_id) == 1 \
                and len(move.entity_asset_id) == 1 \
                and len(move.subscription_line_id) == 1 \
                and len(move.component_line_id) == 1 \
                and len(move.component_placement_id) == 1:
                if move.work_order_line_id.work_order_id.work_order_type != 'move':
                    continue

                if move.picking_type_id.asset_activity != 'attach':
                    continue

                component_check = self.env['work.order.line.component.check'].search([
                    ('work_order_line_id', '=', move.work_order_line_id.id),
                    ('subscription_line_id', '=', move.subscription_line_id.id),
                    ('entity_asset_id', '=', move.entity_asset_id.id),
                ])
                if len(component_check) != 1:
                    continue
                
                move.component_placement_id = component_check.component_placement_id
        return res