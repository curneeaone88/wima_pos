from odoo import models, fields


class ProductDeductionAccount(models.Model):
    _name = 'product.deduction.account'
    _description = 'Subscription Package Default Deduction Account'

    product_id = fields.Many2one('product.template', index=True, ondelete='cascade')
    priority = fields.Integer(string="Priority", required=True)
    account_id = fields.Many2one('account.account', string='Chart of Account', index=True, ondelete='cascade', required=True)
    calculation_type = fields.Selection([('fix', 'Fix'), ('percentage', 'Percentage')], string='Calculation Type', required=True)
    calculation_value = fields.Float(digits=(16, 2), string="Value", required=True)
