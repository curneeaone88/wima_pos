from odoo import models, fields, api
from odoo.tools import float_compare


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    owner_src_id = fields.Many2one(
        comodel_name='res.partner',
        string='From Owner'
    )
    is_owner_handover = fields.Boolean(
        related='picking_type_id.internal_owner_handover'
    )
    force_default_location = fields.Boolean(
        related='picking_type_id.force_default_location'
    )
    work_order_line_id = fields.Many2one(
        comodel_name='work.order.line',
        index=True
    )
    asset_activity = fields.Selection(
        related='picking_type_id.asset_activity'
    )
    entity_asset_id = fields.Many2one(
        comodel_name='entity.asset',
        string='Asset From / To'
    )

    @api.onchange('is_owner_handover', 'partner_id')
    def _onchange_partner_id_and_is_owner_handover(self):
        if self.is_owner_handover:
            self.owner_id = self.partner_id

    def _action_done(self):
        self._check_company()

        todo_moves = self.move_ids.filtered(lambda self: self.state in ['draft', 'waiting', 'partially_available', 'assigned', 'confirmed'])
        for picking in self:
            if picking.owner_id:
                picking.move_ids.write({'restrict_partner_id': picking.owner_id.id})
                dict_ml_update = {'owner_dest_id': picking.owner_id.id}
                if picking.picking_type_code == 'incoming':
                    dict_ml_update['owner_id'] = picking.owner_id.id
                    picking.move_line_ids.write(dict_ml_update)
                elif picking.picking_type_code == 'internal':
                    picking.move_line_ids.write(dict_ml_update)
        todo_moves._action_done(cancel_backorder=self.env.context.get('cancel_backorder'))
        self.write({'date_done': fields.Datetime.now(), 'priority': '0'})

        # if incoming/internal moves make other confirmed/partially_available moves available, assign them
        done_incoming_moves = self.filtered(lambda p: p.picking_type_id.code in ('incoming', 'internal')).move_ids.filtered(lambda m: m.state == 'done')
        done_incoming_moves._trigger_assign()

        self._send_confirmation_email()
        return True
    
    @api.model_create_multi
    def create(self, vals_list):
        scheduled_dates = []
        for vals in vals_list:
            defaults = self.default_get(['name', 'picking_type_id'])
            picking_type = self.env['stock.picking.type'].browse(vals.get('picking_type_id', defaults.get('picking_type_id')))
            if vals.get('name', '/') == '/' and defaults.get('name', '/') == '/' and vals.get('picking_type_id', defaults.get('picking_type_id')):
                if picking_type.sequence_id:
                    vals['name'] = picking_type.sequence_id.next_by_id()
            
            if picking_type and picking_type.code == 'incoming':
                vals.update({
                    'owner_id': picking_type.company_id.partner_id.id
                })

            # make sure to write `schedule_date` *after* the `stock.move` creation in
            # order to get a determinist execution of `_set_scheduled_date`
            scheduled_dates.append(vals.pop('scheduled_date', False))

        pickings = super(models.Model, self).create(vals_list)

        for picking, scheduled_date in zip(pickings, scheduled_dates):
            if scheduled_date:
                picking.with_context(mail_notrack=True).write({'scheduled_date': scheduled_date})
        pickings._autoconfirm_picking()

        for picking, vals in zip(pickings, vals_list):
            # set partner as follower
            if vals.get('partner_id'):
                if picking.location_id.usage == 'supplier' or picking.location_dest_id.usage == 'customer':
                    picking.message_subscribe([vals.get('partner_id')])
            if vals.get('picking_type_id'):
                for move in picking.move_ids:
                    if not move.description_picking:
                        move.description_picking = move.product_id.with_context(lang=move._get_lang())._get_description(move.picking_id.picking_type_id)
        return pickings
    
    def check_uncomplete(self):
        prec = self.env["decimal.precision"].precision_get("Product Unit of Measure")
        not_complete = self.env['stock.move']
        for picking in self:
            for move in picking.move_ids:
                if move.product_id.type != 'product' or move.component_line_id.component_id.fulfill_quantity is False:
                    continue
                if (move.product_uom_qty and not move.picked) or float_compare(
                        move._get_picked_quantity(),
                        move.product_uom_qty,
                    precision_digits=prec) < 0:
                    not_complete += move
        return not_complete