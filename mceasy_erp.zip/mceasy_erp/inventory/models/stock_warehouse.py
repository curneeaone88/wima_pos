from odoo import models, _, _lt


ROUTE_NAMES = {
    'one_step': _lt('Receive'),
    'two_steps': _lt('Receive (input + stock)'),
    'three_steps': _lt('Receive (input + quality + stock)'),
    'crossdock': _lt('Cross-Dock'),
    'ship_only': _lt('Deliver'),
    'pick_ship': _lt('Deliver (pick + ship)'),
    'pick_pack_ship': _lt('Deliver (pick + pack + ship)'),
}

class StockWarehouse(models.Model):
    _inherit = 'stock.warehouse'

    def _create_or_update_sequences_and_picking_types(self):
        """ Create or update existing picking types for a warehouse.
        Pikcing types are stored on the warehouse in a many2one. If the picking
        type exist this method will update it. The update values can be found in
        the method _get_picking_type_update_values. If the picking type does not
        exist it will be created with a new sequence associated to it.
        """
        self.ensure_one()
        IrSequenceSudo = self.env['ir.sequence'].sudo()
        PickingType = self.env['stock.picking.type']

        # choose the next available color for the operation types of this warehouse
        all_used_colors = [res['color'] for res in PickingType.search_read([('warehouse_id', '!=', False), ('color', '!=', False)], ['color'], order='color')]
        available_colors = [zef for zef in range(0, 12) if zef not in all_used_colors]
        color = available_colors[0] if available_colors else 0

        warehouse_data = {}
        sequence_data = self._get_sequence_values()

        # suit for each warehouse: reception, internal, pick, pack, ship
        max_sequence = self.env['stock.picking.type'].search_read([('sequence', '!=', False)], ['sequence'], limit=1, order='sequence desc')
        max_sequence = max_sequence and max_sequence[0]['sequence'] or 0

        data = self._get_picking_type_update_values()
        create_data, max_sequence = self._get_picking_type_create_values(max_sequence)

        for picking_type, values in data.items():
            if self[picking_type]:
                self[picking_type].sudo().sequence_id.write(sequence_data[picking_type])
                self[picking_type].write(values)
            else:
                data[picking_type].update(create_data[picking_type])
                sequence = IrSequenceSudo.create(sequence_data[picking_type])
                values.update(warehouse_id=self.id, color=color, sequence_id=sequence.id)
                warehouse_data[picking_type] = PickingType.create(values).id

        if 'out_type_id' in warehouse_data:
            PickingType.browse(warehouse_data['out_type_id']).write({'return_picking_type_id': warehouse_data.get('in_type_id', False)})
        if 'in_type_id' in warehouse_data:
            PickingType.browse(warehouse_data['in_type_id']).write({'return_picking_type_id': warehouse_data.get('out_type_id', False)})
        return warehouse_data

    def _get_route_name(self, route_type):
        return str(ROUTE_NAMES[route_type])
    
    def _get_routes_values(self):
        """ Return information in order to update warehouse routes.
        - The key is a route field sotred as a Many2one on the warehouse
        - This key contains a dict with route values:
            - routing_key: a key used in order to match rules from
            get_rules_dict function. It would be usefull in order to generate
            the route's rules.
            - route_create_values: When the Many2one does not exist the route
            is created based on values contained in this dict.
            - route_update_values: When a field contained in 'depends' key is
            modified and the Many2one exist on the warehouse, the route will be
            update with the values contained in this dict.
            - rules_values: values added to the routing in order to create the
            route's rules.
        """
        return {
            'reception_route_id': {
                'routing_key': self.reception_steps,
                'depends': ['reception_steps'],
                'route_update_values': {
                    'name': self._format_routename(route_type=self.reception_steps),
                    'active': self.active,
                },
                'route_create_values': {
                    'product_categ_selectable': True,
                    'warehouse_selectable': True,
                    'product_selectable': False,
                    'company_id': self.company_id.id,
                    'sequence': 9,
                },
                'rules_values': {
                    'active': True,
                    'propagate_cancel': True,
                }
            },
            'delivery_route_id': {
                'routing_key': self.delivery_steps,
                'depends': ['delivery_steps'],
                'route_update_values': {
                    'name': self._format_routename(route_type=self.delivery_steps),
                    'active': self.active,
                    'work_order_applicable': 'delivery',
                },
                'route_create_values': {
                    'product_categ_selectable': True,
                    'warehouse_selectable': True,
                    'product_selectable': False,
                    'company_id': self.company_id.id,
                    'sequence': 10,
                    'work_order_applicable': 'delivery',
                },
                'rules_values': {
                    'active': True,
                    'propagate_carrier': True
                }
            },
            'crossdock_route_id': {
                'routing_key': 'crossdock',
                'depends': ['delivery_steps', 'reception_steps'],
                'route_update_values': {
                    'name': self._format_routename(route_type='crossdock'),
                    'active': self.reception_steps != 'one_step' and self.delivery_steps != 'ship_only'
                },
                'route_create_values': {
                    'product_selectable': True,
                    'product_categ_selectable': True,
                    'active': self.delivery_steps != 'ship_only' and self.reception_steps != 'one_step',
                    'company_id': self.company_id.id,
                    'sequence': 20,
                },
                'rules_values': {
                    'active': True,
                    'procure_method': 'make_to_order'
                }
            }
        }
