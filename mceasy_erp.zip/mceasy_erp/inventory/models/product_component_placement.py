from odoo import models, fields


class ProductComponentPlacement(models.Model):
    _name = 'product.component.placement'
    _description = 'Placement'

    product_component_id = fields.Many2one(
        comodel_name='product.component',
        required=True,
        ondelete='restrict'
    )
    name = fields.Char(
        required=True
    )
    external_code = fields.Char(
        required=True
    )