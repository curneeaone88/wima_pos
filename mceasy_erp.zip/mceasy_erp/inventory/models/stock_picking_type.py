from odoo import models, fields, api

class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    internal_owner_handover = fields.Boolean(
        string='Owner Handover',
        default=False
    )
    asset_activity = fields.Selection(
        selection=[
            ('attach', 'Attach to Entity'),
            ('detach', 'Detach from Entity'),
        ]
    )
    force_default_location = fields.Boolean(
        string='Force Default Location',
        default=False
    )

    @api.onchange('code')
    def _onchage_code(self):
        if self.code != 'internal':
            self.internal_owner_handover = False