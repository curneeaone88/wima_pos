from odoo import models, fields
from odoo.addons.mceasy_erp.service.models.work_order import WORK_ORDER_TYPES


class StockRoute(models.Model):
    _inherit = 'stock.route'

    work_order_applicable = fields.Selection(
        selection=WORK_ORDER_TYPES,
        string='Work Order'
    )