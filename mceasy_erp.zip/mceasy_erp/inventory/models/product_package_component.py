from odoo import models, fields


class ProductPackageComponent(models.Model):
    _name = 'product.package.component'
    _description = 'Subscription Package Component'

    product_id = fields.Many2one('product.template', string='Product', index=True, ondelete='cascade')
    name = fields.Char(string="Value", related="component_product_id.name")
    component_id = fields.Many2one('product.component', string='Type', index=True, ondelete='cascade', required=True)
    component_product_id = fields.Many2one('product.template', string='Component', index=True, ondelete='cascade', required=True)
    qty = fields.Integer(string="Qty", default=1)
    depended_to = fields.Many2one('product.package.component', string='Depended To')
    alternatives = fields.Many2many('product.template', 'product_package_component_alternative_rel', string='Alternatives')
