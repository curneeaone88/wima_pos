from odoo import models, fields, api
from odoo.addons.mceasy_erp.service.models.work_order import WORK_ORDER_TYPES
from odoo.exceptions import MissingError

class ProductOperationTemplate(models.Model):
    _name = 'product.operation.template'
    _description = 'Product Operation Template'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(
        string="Name",
        required=True,
        tracking=1,
    )
    sale_operations = fields.One2many(
        string="Sales Operations",
        comodel_name='product.operation.template.line',
        inverse_name='operation_template_id',
        domain=[
            ('type', '=', 'sale')
        ],
        tracking=1,
    )
    churn_operations = fields.One2many(
        string="Churn Operations",
        comodel_name='product.operation.template.line',
        inverse_name='operation_template_id',
        domain=[
            ('type', '=', 'churn')
        ],
        tracking=1,
    )
    move_operations = fields.One2many(
        string="Asset Migration Operations",
        comodel_name='product.operation.template.line',
        inverse_name='operation_template_id',
        domain=[
            ('type', '=', 'move')
        ],
        tracking=1,
    )
    maintenance_operations = fields.One2many(
        string="Maintenance Operations",
        comodel_name='product.operation.template.line',
        inverse_name='operation_template_id',
        domain=[
            ('type', '=', 'maintenance')
        ],
        tracking=1,
    )

    def get_next_operation(self, type, current_operation=None):
        idx = 0
        if type == 'sale':
            for op in self.sale_operations:
                if current_operation == None:
                    return op
                idx += 1
                if op.work_order_type == current_operation:
                    break
            if idx < len(self.sale_operations):
                return self.sale_operations[idx]
            return None
        elif type == 'churn':
            for op in self.churn_operations:
                if current_operation == None:
                    return op
                idx += 1
                if op.work_order_type == current_operation:
                    break
            if idx < len(self.churn_operations):
                return self.churn_operations[idx]
            return None
        elif type == 'move':
            for op in self.move_operations:
                if current_operation == None:
                    return op
                idx += 1
                if op.work_order_type == current_operation:
                    break
            if idx < len(self.move_operations):
                return self.move_operations[idx]
            return None
        elif type == 'maintenance':
            for op in self.maintenance_operations:
                if current_operation == None:
                    return op
                idx += 1
                if op.work_order_type == current_operation:
                    break
            if idx < len(self.maintenance_operations):
                return self.maintenance_operations[idx]
            return None
        else:
            raise MissingError('Unknown type')


class ProductOperationTemplateLine(models.Model):
    _name = 'product.operation.template.line'
    _description = 'Product Operation Template Line'

    operation_template_id = fields.Many2one(
        comodel_name='product.operation.template',
        ondelete='cascade'
    )
    name = fields.Char(
        compute='_compute_name',
        store=True,
        precompute=True
    )
    sequence = fields.Integer()
    type = fields.Selection(
        selection=[
            ('sale', 'Sales'),
            ('churn', 'Churn'),
            ('move', 'Asset Migration'),
            ('maintenance', 'Maintenance'),
        ],
        required=True
    )
    work_order_type = fields.Selection(
        selection=WORK_ORDER_TYPES,
        required=True
    )
    scope = fields.Selection(
        selection=[
            ('product_unit', 'Product Unit'),
            ('product_usage', 'Product Usage'),
            ('product_contract', 'Product Contract'),
        ],
        required=True,
        default='product_unit'
    )
    for_billing_action = fields.Boolean(
        default=False
    )
    activities = fields.One2many(
        comodel_name='product.operation.template.line.activity',
        inverse_name='operation_template_line_id',
        string='Activities'
    )

    @api.onchange('scope')
    def _onchange_scope(self):
        if self.scope == 'product_contract':
            self.for_billing_action = False
        else:
            for act in self.activities:
                self.write({
                    'activities': [fields.Command.delete(act._origin.id)]
                })

    @api.depends('work_order_type')
    def _compute_name(self):
        for rec in self:
            rec.name = False
            for type, name in WORK_ORDER_TYPES:
                if type == rec.work_order_type:
                    rec.name = name
                    break

    def action_manage_activities(self):
        view = self.env.ref('mceasy_erp.product_operation_template_line_activity_form_view')

        return {
            'name': 'Activities',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'product.operation.template.line',
            'views': [(view.id, 'form')],
            'view_id': view.id,
            'target': 'new',
            'res_id': self.id
        }
            
class ProductOperationTemplateLineActivities(models.Model):
    _name = 'product.operation.template.line.activity'
    _description = 'Activities'

    operation_template_line_id = fields.Many2one(
        comodel_name='product.operation.template.line',
        ondelete='cascade'
    )
    sequence = fields.Integer()
    name = fields.Char(
        string='Activity',
        required=True
    )
    for_billing_action = fields.Boolean(
        default=False
    )