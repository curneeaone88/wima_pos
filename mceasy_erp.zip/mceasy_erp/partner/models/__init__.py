from . import res_partner_size
from . import res_partner
