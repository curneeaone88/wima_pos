from odoo import fields, models, api


class ModelName(models.Model):
    _name = 'res.partner.size'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'analytic.mixin']
    _description = 'Customer Size Model'

    name = fields.Char(string="Customer Size", required=True, tracking=True)
    first_printout_payment_term_id = fields.Many2one("account.payment.term", string="First Printout Payment Term", required=True, tracking=True)
    printout_payment_term_id = fields.Many2one("account.payment.term", string="Printout Payment Term", required=True, tracking=True)
    aging_payment_term_id = fields.Many2one("account.payment.term", string="Aging Payment Term", required=True, tracking=True)




