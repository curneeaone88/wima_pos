from odoo import fields, models, api
import re
from odoo.exceptions import ValidationError, UserError

class ResPartner(models.Model):
    _name = 'res.partner'
    _inherit = ['res.partner', 'approval.mixin']

    #Get first record of partner size, if None then return False
    def get_default_res_partner_size(self):
        if self.customer_rank <= 0:
            return False
        partner_size = self.env['res.partner.size'].search([])
        customer_rank = self.env.context.get('default_customer_rank') or self.customer_rank
        if len(partner_size) > 0 and customer_rank > 0 and not self.contact_type: 
            return partner_size[0].id
        return False

    contract_id = fields.Many2one(
        comodel_name='sale.contract',
        string='Contract',
        store=False,
        compute='_compute_contract_id'
    )

    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('request', 'Request'),
            ('confirmed', 'Confirmed'),
            ('rejected', 'Rejected'),
        ],
        default=lambda f: f.get_default_state(),
        tracking=1
    )

    contact_number = fields.Char(
        compute='_compute_contact_number'
    )

    contact_type = fields.Selection(
        selection=[
            ('employee', 'Employee'),
            ('technician', 'Technician'),
            ('implementor', 'Implementor'),
        ],
        default=False,
    )

    report_address = fields.Char(
        compute='_compute_report_address'
    )

    entities = fields.One2many('entity.asset', 'partner_id', string='Registered Assets')

    fleet_category = fields.Selection([
        ('a', 'A<=5'),('b', 'B<=10'),
        ('c', 'C<=20'),('d', 'D<=50'),
        ('e', 'E<=100'),('f', 'F<400'),
        ('g', 'G>=400'),
    ], string="Fleet Category")
    res_partner_size_id = fields.Many2one('res.partner.size', string="Customer Size", default=lambda x: x.get_default_res_partner_size())

    account_number = fields.Char(string="Account ID")

    city_id = fields.Many2one("res.country.city", string="city", domain="[('state_id', '=?', state_id)]")

    @api.onchange("city_id")
    def onchange_city_id(self):
        for rec in self:
            if rec.city_id:
                rec.city = rec.city_id.name
                rec.state_id = rec.city_id.state_id.id
            if not rec.city_id or (rec.city_id.state_id and rec.state_id != rec.city_id.state_id):
                rec.state_id = False
                rec.country_id = False

    @api.onchange('country_id')
    def _onchange_country_id(self):
        for rec in self:
            if rec.country_id and rec.country_id != rec.state_id.country_id:
                rec.state_id = False
                rec.city_id = False


    def get_default_state(self):
        if self.env.user.has_group('base.group_partner_manager'):
            return 'confirmed'
        return 'draft'

    @api.onchange("account_number")
    def onchange_account_number(self):
        for rec in self:
            if rec.customer_rank <= 0:
                continue
            if rec.account_number and not re.match(r'^(ACCOUNT\-OMG\-|ACCOUNT\-OMG\-\d{1,})$', rec.account_number):
                rec.account_number = "ACCOUNT-OMG-"
                raise ValidationError("Maaf, Account ID hanya bisa diisi menggunakan Pola ACCOUNT-OMG-XXX")

    @api.constrains("account_number")
    def _check_account_number(self):
        for rec in self:
            if rec.customer_rank <= 0:
                continue
            if rec.account_number and rec.customer_rank > 0 and not rec.contact_type and not re.match(r'^(ACCOUNT\-OMG\-\d{1,})$', rec.account_number):
                raise ValidationError("Maaf, Account ID hanya bisa diisi menggunakan Pola ACCOUNT-OMG-XXX")


    @api.onchange('res_partner_size_id')
    def onchange_res_partner_size_id(self):
        for rec in self:
            if rec.res_partner_size_id:
                rec.property_payment_term_id = rec.res_partner_size_id.aging_payment_term_id.id

    def get_legal_initial(self) -> str:
        if self.ref:
            return self.ref
        name = self.name\
                    .replace(', PT', '')\
                    .replace(',PT', '')\
                    .replace(', UD', '')\
                    .replace(',UD', '')\
                    .replace(', CV', '')\
                    .replace(',CV', '')\
                    .replace(', Bapak', '')\
                    .replace(',Bapak', '')\
                    .replace(', Ibu', '')\
                    .replace(',Ibu', '')\
                    .title()
        name = re.sub(pattern='[^a-z,^A-Z, ]', repl='', string=name)
        initial_words = name.split(' ')
        self.ref = ''.join([i[0] if len(i) > 0 else '' for i in initial_words])
        return self.ref
    
    def _compute_contract_id(self):
        for record in self:
            contract = self.env['sale.contract'].search([
                ('company_id', '=', self.env.company.id),
                ('partner_id', '=', record.id),
            ])
            if not contract:
                record.contract_id = False
            else:
                record.contract_id = contract.id

    def _compute_contact_number(self):
        for rec in self:
            number = False
            if rec.phone is not False:
                number = rec.phone
            if rec.mobile is not False:
                if number is not False:
                    number = f'{number} / {rec.mobile}'
                else:
                    number = rec.mobile
            rec.contact_number = number
    
    @api.onchange('contact_type')
    def _onchange_contact_type(self):
        for rec in self:
            if rec.contact_type == 'technician':
                rec.function = 'Technician'
            elif rec.contact_type == 'implementor':
                rec.function = 'Implementor'
            else:
                rec.function = False

    def _compute_report_address(self):
        for rec in self:
            addr = rec.with_context(
                show_address=True
            ).display_name
            if addr.strip() == rec.name.strip():
                rec.report_address = False
                continue
            rec.report_address = addr.replace(rec.name, '').strip()

    def action_request(self, quite=False):
        if not self.is_need_approval and not quite:
            raise UserError("There is no approval configuration !")
        self.action_request_approval()
        for child in self.child_ids:
            child.action_request(quite=True)

    
    def action_confirm(self):
        self.state = 'confirmed'

    def action_reject(self):
        self.state = 'rejected'

    def action_draft(self):
        self.clean_approvers()
        self.state = 'draft'

    def get_approval_state(self):
        return 'request'

    def get_rejection_state(self):
        return 'rejected'