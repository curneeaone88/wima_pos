from odoo import models, fields


class CRMTeam(models.Model):
    _inherit = 'crm.team'
    
    category = fields.Many2one(
        comodel_name='crm.category'
    )