from odoo import fields, models, tools


class SaleContractEntityAsset(models.Model):
    _name = 'sale.contract.entity.asset'
    _description = 'Registered Asset'
    _auto = False

    entity_asset_id = fields.Many2one('entity.asset')
    name = fields.Char(
        related='entity_asset_id.name'
    )
    type = fields.Selection(
        related='entity_asset_id.type'
    )
    component_id = fields.Many2one(
        comodel_name='product.component'
    )
    product_id = fields.Many2one(
        comodel_name='product.product'
    )
    lot_id = fields.Many2one(
        comodel_name='stock.lot'
    )
    location_id = fields.Many2one(
        comodel_name='stock.location'
    )
    quantity = fields.Float()
    owner_id = fields.Many2one(
        comodel_name='res.partner'
    )
    contract_id = fields.Many2one(
        related='owner_id.contract_id'
    )

    def init(self):
        tools.drop_view_if_exists(self.env.cr, 'sale_contract_entity_asset')
        self.env.cr.execute("""
        CREATE VIEW sale_contract_entity_asset AS (
            select 
                sq.id,
                ea.id as entity_asset_id,
                pt.component_id,
                sq.product_id,
                sq.lot_id,
                sq.quantity,
                sq.location_id,
                sq.owner_id 
            from entity_asset ea 	
            left join stock_quant sq on sq.entity_asset_id = ea.id
            left join product_product pp on pp.id = sq.product_id 
            left join product_template pt on pt.id = pp.product_tmpl_id
            where sq.quantity >= 1
        )
""")