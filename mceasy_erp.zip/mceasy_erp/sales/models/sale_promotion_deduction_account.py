from odoo import models, fields


class SalePromotionDeductionAccount(models.Model):
    _name = 'sale.promotion.deduction.account'
    _description = 'All Product Deduction'

    sale_promotion_id = fields.Many2one(
        comodel_name='sale.promotion',
        ondelete='cascade'
    )
    priority = fields.Integer(string="Priority", required=True)
    account_id = fields.Many2one('account.account', string='Chart of Account', index=True, ondelete='cascade', required=True)
    calculation_type = fields.Selection([('fix', 'Fix'), ('percentage', 'Percentage')], string='Calculation Type', required=True)
    calculation_value = fields.Float(digits=(16, 2), string="Value", required=True)