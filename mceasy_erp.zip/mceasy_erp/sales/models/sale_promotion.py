from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from jinja2 import Template


class SalePromotion(models.Model):
    _name = 'sale.promotion'
    _description = 'Promotion'
    _order = 'id desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    def domain_external_template_id(self):
        return [('model','=', self._name)]

    name = fields.Char(
        required=True
    )
    code = fields.Char()
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('requested', 'Requested'),
            ('rejected', 'Rejected'),
            ('published', 'Published'),
        ],
        default='draft',
        tracking=1,
        required=True
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        default=lambda self: self.env.company
    )
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        store=True,
        ondelete='restrict',
        compute='_compute_currency_id',
    )
    type = fields.Selection(
        selection=[
            ('price_percentage', 'Price Percentage'),
            ('subscription_month', 'Free Subscription Month'),
        ],
        required=True,
        default='price_percentage'
    )
    subscription_month_rule = fields.Selection(
        selection=[
            ('in_front', 'In Front'),
            ('in_back', 'In Back'),
            ('average', 'Average by Effective in Month'),
            ('every_invoiced', 'Free month every invoiced'),
        ]
    )
    price_percentage_rule = fields.Selection(
        selection=[
            ('base_from_standart_price', 'Based on Standart Price'),
            ('base_from_discounted_price', 'Based on Discounted Price'),
            ('replace', 'Replace Standart & Discounted Price'),
        ]
    )
    calculation = fields.Float(
        help='In month / percentage',
    )
    effective_in_month = fields.Integer(
        required=True
    )
    promotion_activation = fields.Selection(
        selection=[
            ('based_on_quotation_first_item_activation', 'Base on Quotation: first activation'),
            ('based_on_sale_order_first_item_activation', 'Base on Sale Order: first activation'),
            ('based_on_each_item_activation', 'All item will have the same calculation'),
        ],
        default='based_on_quotation_first_item_activation',
        required=True
    )
    recurring_plan_rule = fields.Selection(
        selection=[
            ('all', 'All'),
            ('specific', 'Specific'),
        ],
        default='all',
        required=True
    )
    first_recurring_plan = fields.Many2one(
        comodel_name='subscription.plan'
    )
    allowed_recurring_plans = fields.Many2many(
        comodel_name='subscription.plan'
    )
    contract_period_rule = fields.Selection(
        selection=[
            ('all', 'All'),
            ('specific', 'Specific')
        ],
        default='all',
        required=True
    )
    allowed_contract_periods = fields.Many2many(
        comodel_name='sale.contract.period'
    )
    sales_person_rule = fields.Selection(
        selection=[
            ('all', 'All'),
            ('specific', 'Specific'),
        ],
        default='all',
        required=True
    )
    allowed_sales_persons = fields.Many2many(
        comodel_name='res.users'
    )
    allowed_order_confirmation = fields.Selection(
        selection=[
            ('signature', 'By Signature Only (Paylater)'),
            ('payment', 'By Payment (Down Payment)'),
            ('all', 'Can be Down Payment or Paylater'),
        ],
        default='all',
        required=True
    )
    product_rule = fields.Selection(
        selection=[
            ('all', 'All'),
            ('specific', 'Specific'),
        ],
        default='all',
        required=True
    )
    domain_products = fields.One2many(
        comodel_name='product.product',
        compute='_compute_domain_products'
    )
    allowed_products = fields.One2many(
        comodel_name='sale.promotion.product',
        inverse_name='sale_promotion_id'
    )
    quantity_rule = fields.Selection(
        selection=[
            ('flexible', 'Flexible'),
            ('must_greater_and_equal', 'Must Greater and Equal Than'),
            ('limited_to_maximum_quantity', 'Eligible quantity each quotation'),
        ],
        default='flexible',
        required=True
    )
    minimum_quantity_allowed = fields.Integer()
    maximum_quantity_allowed = fields.Integer()
    customer_rule = fields.Selection(
        selection=[
            ('all', 'All'),
            ('specific', 'Specific'),
        ],
        default='all',
        required=True
    )
    allowed_customers = fields.Many2many(
        comodel_name='res.partner'
    )
    deposit_rule = fields.Selection(
        selection=[
            ('none', 'Without Deposit'),
            ('required', 'Require Deposit'),
        ],
        default='none',
        required=True
    )
    total_deposit_month = fields.Integer(
        default=False
    )
    can_used_from = fields.Date(
        required=True,
        default=fields.Date.today
    )
    can_used_to = fields.Date()
    note = fields.Html(
        string='Terms and Conditions'
    )
    active = fields.Boolean(
        default=True
    )
    domain_uoms = fields.One2many(
        comodel_name='uom.uom',
        compute='_compute_domain_uoms'
    )
    promotion_deductions = fields.One2many(
        comodel_name='sale.promotion.deduction.account',
        inverse_name='sale_promotion_id'
    )

    external_template_id = fields.Many2one(
        comodel_name="external.template",
        domain=domain_external_template_id,
    )

    @api.model
    def create(self,vals):
        res = super(SalePromotion, self).create(vals)
        template = self.env['external.template'].search([('model','=', self._name),('is_default','=', True)], limit=1)
        res.external_template_id = template.id
        res.note = template.content
        return res

    def render_template(self, data):
        if not data:
            raise ValidationError("render_template need data record")
        if not self.note:
            return ""

        content = self.note.replace("%7B","{")
        content = content.replace("%7D","}")
        content = content.replace("%20"," ")
        template = Template(content)
        return template.render({'object': data})

    @api.onchange("external_template_id")
    def onchange_external_template_id(self):
        for rec in self:
            if rec.external_template_id:
                rec.note = rec.external_template_id.content
        

    @api.depends('type')
    def _compute_domain_uoms(self):
        self.domain_uoms = self.env['uom.uom'].browse()
        domain = [
            ('category_id.for_sale_quotation', '=',  True)
        ]
        if self.type == 'subscription_month':
            domain += [
                ('id', '=', self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month').id)
            ]
        else:
            domain += [
                ('id', 'in', [
                    self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month').id,
                    self.env.ref('mceasy_erp.product_uom_package_subscription_usage_month').id
                ])
            ]
        uoms = self.env['uom.uom'].search(domain)
        for uom in uoms:
            self.domain_uoms += uom

    @api.onchange('type')
    def _onchange_type(self):
        self.calculation = False
        self.effective_in_month = False
    
    @api.onchange('calculation')
    def _onchange_calculation(self):
        if self.calculation < 0:
            self.calculation = 0

    @api.onchange('subscription_month_rule', 'calculation', 'effective_in_month')
    def _onchange_subscription_rule(self):
        if self.type != 'subscription_month':
            self.subscription_month_rule = False
            return
        
        if self.subscription_month_rule in ['in_front']:
            self.effective_in_month = self.calculation
            return
        else:
            if self.effective_in_month < self.calculation:
                self.effective_in_month = self.calculation

    @api.onchange('price_percentage_rule', 'calculation', 'effective_in_month')
    def _onchange_price_percentage_rule(self):
        if self.type != 'price_percentage':
            self.price_percentage_rule = False

        if self.price_percentage_rule == 'replace':
            self.product_rule = 'specific'
            self.calculation = False
        
    @api.onchange('deposit_rule')
    def _onchange_deposit_rule(self):
        if self.deposit_rule == 'none':
            self.total_deposit_month = False
        else:
            self.total_deposit_month = 1

    @api.onchange('can_used_to')
    def _onchange_can_used_to(self):
        if self.can_used_to == False:
            return

        if self.can_used_to < self.can_used_from:
            self.can_used_to = self.can_used_from

    @api.onchange('total_deposit_month')
    def _onchange_total_deposit_month(self):
        if self.deposit_rule != 'required':
            return
        
        if self.total_deposit_month <= 0:
            self.total_deposit_month = 1

    @api.depends('allowed_products')
    def _compute_domain_products(self):
        self.domain_products = self.env['product.product'].browse()
        for p in self.allowed_products:
            self.domain_products += p.product_id

    @api.onchange('quantity_rule')
    def _onchange_quantity_rule(self):
        if self.quantity_rule == 'flexible':
            self.minimum_quantity_allowed = False
            self.maximum_quantity_allowed = False
        elif self.quantity_rule == 'must_greater_and_equal':
            self.maximum_quantity_allowed = False
        elif self.quantity_rule == 'limited_to_maximum_quantity':
            self.minimum_quantity_allowed = False

    @api.onchange('recurring_plan_rule')
    def _onchange_recurring_plan_rule(self):
        if self.recurring_plan_rule == 'all':
            self.allowed_recurring_plans = [fields.Command.clear()]

    @api.onchange('customer_rule')
    def _onchange_customer_rule(self):
        if self.customer_rule == 'all':
            self.allowed_customers = [fields.Command.clear()]

    @api.onchange('product_rule')
    def _onchange_product_rule(self):
        if self.product_rule == 'all':
            self.allowed_products = [fields.Command.clear()]
        if self.product_rule == 'specific':
            self.promotion_deductions = [fields.Command.clear()]

    def action_request(self):
        if self.product_rule == 'specific' and len(self.allowed_products) == 0:
            raise UserError("Allowed product must be set when the product rule is specific!")
        if self.effective_in_month <= 0:
            raise UserError("Effective month should larger than zero!")
        
        if self.subscription_month_rule == 'every_invoiced':
            for recurring_plan in self.allowed_recurring_plans:
                if self.effective_in_month % recurring_plan.length_in_month != 0:
                    raise UserError("The modulus of effective in month with recurring plan should be zero")
        self.state = 'requested'
    
    def action_published(self):
        self.state = 'published'

    def action_rejected(self):
        self.state = 'rejected'

    def action_draft(self):
        self.state = 'draft'

    @api.depends('company_id')
    def _compute_currency_id(self):
        for promotion in self:
            promotion.currency_id = promotion.company_id.currency_id or self.env.ref('base.main_company').currency_id

    def get_deduction_rules(self, product):
        if self.product_rule == 'all':
            return self.promotion_deductions
        else:
            products = self.allowed_products.filtered(lambda x: x.product_id == product)
            if len(products) == 0:
                return []
            return products[0].product_deductions