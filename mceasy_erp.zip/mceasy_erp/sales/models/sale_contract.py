from odoo import models, fields, api, _


CONTRACT_STATE_DRAFT = 'draft'
CONTRACT_STATE_SENT = 'sent'
CONTRACT_STATE_SIGNED = 'signed'
CONTRACT_STATE_REJECTED = 'rejected'
CONTRACT_STATE_CANCELED = 'canceled'

CONTRACT_STATE = [
    (CONTRACT_STATE_DRAFT, "Draft"),
    (CONTRACT_STATE_SENT, "Sent"),
    (CONTRACT_STATE_REJECTED, "Rejected"),
    (CONTRACT_STATE_SIGNED, "Signed"),
    (CONTRACT_STATE_CANCELED, "Canceled"),
]


class SaleContract(models.Model):
    _name = 'sale.contract'
    _description = 'Contract'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    def domain_external_template_id(self):
        return [('model','=', self._name)]

    name = fields.Char(
        string="Number",
        required=True,
        index='trigram',
        default=lambda self: _('New')
    )

    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        default=lambda self: self.env.company)

    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        tracking=1,
        domain="[('company_id', 'in', (False, company_id))]")
    
    state = fields.Selection(
        selection=CONTRACT_STATE,
        string="Status",
        readonly=True, copy=False, index=True,
        tracking=3,
        default='draft')
    
    create_date = fields.Datetime(  # Override of default create_date field from ORM
        string="Creation Date", index=True, readonly=True)
    
    signed_on = fields.Datetime(  # Override of default create_date field from ORM
        string="Signed On", index=True, readonly=True)
    
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        ondelete='restrict',
        required=True
    )

    quotations = fields.One2many('sale.quotation', 'contract_id', string='Quotations')
    confirmed_quotation_lines = fields.One2many('sale.quotation.line', 'contract_id', string="Confirmed Products")
    reserved_product_mode = fields.Boolean(string="View Product Detail", default=False, store=False)
    reserved_products = fields.One2many('sale.contract.reserved.product', 'contract_id', string="Booking Products")
    reserved_summary = fields.One2many('sale.contract.reserved.summary', 'contract_id', string="Booking Summary")
    entity_mode = fields.Boolean(string="View Entity Detail", default=False, store=False)
    entity_assets = fields.One2many(
        comodel_name='entity.asset',
        inverse_name='contract_id',
        string='Registered Assets'
    )
    entity_asset_details = fields.One2many('sale.contract.entity.asset', 'contract_id', string='Detail Registered Assets')
    subscription_count = fields.Integer(
        compute='_compute_subscription_count',
        store=False
    )
    sale_order_count = fields.Integer(
        compute='_compute_sale_order_count'
    )
    amount_untaxed = fields.Monetary(
        compute='_compute_amount_untaxed'
    )
    note = fields.Html()
    external_template_id = fields.Many2one(
        comodel_name="external.template",
        domain=domain_external_template_id
    )
    partner_pic_id = fields.Many2one("res.partner", string="Customer PIC")

    @api.model
    def create(self,vals):
        res = super(SaleContract, self).create(vals)
        template = self.env['external.template'].search([('model','=', self._name),('is_default','=', True)], limit=1)
        res.external_template_id = template.id
        res.note = template.render_template(res)
        return res

    def action_print_contract(self):
        return self.env.ref('mceasy_erp.action_report_contract').report_action(self)

    @api.onchange("external_template_id", "quotations")
    def onchange_external_template_id(self):
        if self.external_template_id and self.quotations:
            self.note = self.external_template_id.render_template(self)

    def generate_addendum(self):
        self.ensure_one()
        contract_name = self.name
        if '/ADDN-' in self.name:
            contract_name = contract_name[:contract_name.index('/ADDN-')]
        return f'{contract_name}/ADDN-{len(self.quotations)}'
    
    def action_create_sales_order(self, quotation_id=False):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order',
            'view_mode': 'form',
            'context': {
                'default_subscription_state': '1_draft',
                'default_company_id': self.company_id.id,
                'default_partner_id': self.partner_id.id,
                'default_contract_id': self.id,
                'default_quotation_id': quotation_id.id,
                'default_require_payment': len(quotation_id) == 1 and quotation_id.order_confirmation == 'payment',
                'default_prepayment_percent': 1 if len(quotation_id) == 1 and quotation_id.order_confirmation == 'payment' else 0,
                'default_pricelist_id': False
            }
        }
    
    def _compute_subscription_count(self):
        subscriptions = self.env['subscription'].search([
            ('contract_id', '=', self.id)
        ])
        self.subscription_count = len(subscriptions)
    
    def action_view_subscription(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'subscription',
            'view_mode': 'tree,form',
            'name': _('Subscriptions'),
            'domain': [
                ('contract_id', '=', self.id)
            ]
        }
    
    def _compute_sale_order_count(self):
        orders = self.env['sale.order'].search([
            ('contract_id', '=', self.id),
            ('state', '!=', 'cancel'),
        ])
        self.sale_order_count = len(orders)

    def action_view_sale_order(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order',
            'view_mode': 'tree,form',
            'name': _('Sale Orders'),
            'domain': [
                ('contract_id', '=', self.id),
                ('state', '!=', 'cancel'),
            ]
        }

    @api.depends('quotations')
    def _compute_amount_untaxed(self):
        for rec in self:
            total = 0
            for quot in rec.quotations:
                if quot.state != 'signed':
                    continue
                total = total + quot.amount_by_contract
                    
            rec.amount_untaxed = total

