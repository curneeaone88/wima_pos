from odoo import models, fields, _, api
from odoo.addons.mceasy_erp.common.helper import get_default_context, domain_quotation_pricelist_by_uom_category
from odoo.exceptions import UserError, ValidationError
import logging
import re
_logger = logging.getLogger(__name__)

QUOTATION_STATE_DRAFT = 'draft'
QUOTATION_STATE_REQUEST = 'request'
QUOTATION_STATE_SENT = 'sent'
QUOTATION_STATE_REJECTED = 'rejected'
QUOTATION_STATE_SIGNED = 'signed'
QUOTATION_STATE_ADDENDUMED = 'addendumed'
QUOTATION_STATE_CANCELED = 'canceled'

QUOTATION_STATE = [
    (QUOTATION_STATE_DRAFT, "Draft"),
    (QUOTATION_STATE_REQUEST, "Request"),
    (QUOTATION_STATE_SENT, "Quotation Sent"),
    (QUOTATION_STATE_SIGNED, "Quotation Signed"),
    (QUOTATION_STATE_ADDENDUMED, "Quotation Addendumed"),
    (QUOTATION_STATE_CANCELED, "Canceled"),
    (QUOTATION_STATE_REJECTED, "Rejected"),
]


class SaleQuotation(models.Model):
    _name = 'sale.quotation'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'approval.mixin']
    _description = 'Quotation'
    _order = 'id desc'

    def domain_external_template_id(self):
        return [('model','=', self._name)]


    name = fields.Char(
        string="Number",
        required=True, copy=False, readonly=False,
        index='trigram',
        default=lambda self: _('New')
    )
    title = fields.Char(
        string="Title",
        required=True,
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True,
        index=True,
        store=True,
        precompute=True,
        compute_sudo=True,
        readonly=False,
        compute='_compute_company_id')
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        tracking=1,
        domain="[('company_id', 'in', (False, company_id))]")
    responsible_partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Customer PIC',
        required=True,
    )
    state = fields.Selection(
        selection=QUOTATION_STATE,
        string="Status",
        readonly=True, copy=False, index=True,
        tracking=3,
        default='draft')
    create_date = fields.Datetime(  # Override of default create_date field from ORM
        string="Creation Date", index=True, readonly=True)
    quotation_date = fields.Datetime(
        string="Quotation Date",
        required=True, copy=False,
        default=fields.Datetime.now)
    valid_untill_date = fields.Datetime(
        string="Valid Till",
        required=True, copy=False,
        compute='_compute_valid_untill_date',
        store=True,
        compute_sudo=True,
        precompute=True)
    signed_on = fields.Datetime(  # Override of default create_date field from ORM
        string="Signed On", index=True, readonly=True)
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        store=True,
        compute_sudo=True,
        ondelete='restrict',
        compute='_compute_currency_id',
    )
    tax_country_id = fields.Many2one(
        comodel_name='res.country',
        compute='_compute_tax_country_id',
        compute_sudo=True
    )
    quotation_lines = fields.One2many(
        comodel_name='sale.quotation.line',
        inverse_name='quotation_id',
        string="Quotation Lines",
        copy=True, auto_join=True)
    promotion_quotation_lines = fields.One2many(
        comodel_name='sale.quotation.promotion.line',
        compute='_compute_promotion_quotation_lines',
        compute_sudo=True
    )
    contract_id = fields.Many2one('sale.contract', string="Current Contract", index=True, ondelete='restrict', readonly=True)
    contract_name = fields.Char(
        string="Contract",
        readonly=True
    )
    contract_period_id = fields.Many2one(
        'sale.contract.period',
        string='Contract Period',
        ondelete='restrict',
        required=True,
        default=lambda x: x.env.ref('mceasy_erp.sale_contract_period_1_year')
    )
    domain_contract_period = fields.One2many(
        comodel_name='sale.contract.period',
        compute='_compute_domain_contract_period',
        compute_sudo=True
    )
    is_contract_addendumed = fields.Boolean(
        compute='_compute_is_contract_addendumed',
        compute_sudo=True
    )
    recurring_plan_id = fields.Many2one(
        'subscription.plan',
        string='Recurring Payment Plan',
        index=True,
        ondelete='restrict',
        required=True,
        default=lambda x: x.env.ref('mceasy_erp.subscription_plan_month')
    )
    domain_recurring_plan = fields.One2many(
        comodel_name='subscription.plan',
        compute='_compute_domain_recurring_plan',
        compute_sudo=True
    )
    is_have_purchase_unit = fields.Boolean(
        compute='_compute_is_have_purchase_unit',
        compute_sudo=True
    )
    purchase_plan_type = fields.Selection([
        ('cash', 'Cash (A1)'),
        ('installment', 'Installment (A2)'),
    ], string='Purchase Plan')
    for_addendum_id = fields.Many2one(
        'sale.quotation',
        string="Addendumed From",
        default=False,
        readonly=True
    )
    for_repeat_id = fields.Many2one(
        'sale.quotation',
        string="Repeated From",
        default=False,
        readonly=True
    )
    addendumed_to_id = fields.Many2one(
        'sale.quotation',
        string='Addendumed To',
        default=False,
        readonly=True
    )
    user_id = fields.Many2one(
        'res.users',
        string='Sales',
        default=lambda s: s.env.user.id
    )
    crm_deal_number = fields.Char(
        string='CRM: Deals Number'
    )
    is_user_id_readonly = fields.Boolean(
        compute='_compute_is_user_id_readonly',
        compute_sudo=True
    )
    user_sales_admin_id = fields.Many2one(
        'res.users',
        string='Confirmed By',
    )
    user_sales_category_id = fields.Many2one(
        string='Sales Category',
        comodel_name='crm.team',
        related='user_id.partner_id.team_id',
    )
    user_sales_category_string = fields.Char(
        string='Sales Category String',
        related='user_sales_category_id.name',
    )
    quotation_x_sale_order = fields.Integer(
        string='Quotation x SO',
        compute='_compute_quotation_x_sale_order',
        compute_sudo=True
    )
    quotation_x_activation = fields.Integer(
        string='Quotation Progress',
        compute='_compute_quotation_x_activation',
        compute_sudo=True
    )
    sale_promotion_id = fields.Many2one(
        comodel_name='sale.promotion',
    )
    allowed_company = fields.One2many(
        comodel_name='res.company',
        compute='_compute_multi_company',
        compute_sudo=True
    )
    is_company_visible = fields.Boolean(
        compute='_compute_multi_company',
        compute_sudo=True
    )
    taxes = fields.Char(
        compute='_compute_taxes',
        compute_sudo=True
    )

    amount_promotion_recurring_untaxed = fields.Monetary(string="Untaxed Promotion Recurring Amount", compute_sudo=True, store=True, compute='_compute_promotion_recurring_amounts', tracking=5)
    amount_promotion_recurring_tax = fields.Monetary(string="Promotion Recurring Taxes", compute_sudo=True, store=True, compute='_compute_promotion_recurring_amounts')
    amount_promotion_recurring_total = fields.Monetary(string="Promotion Recurring Total", compute_sudo=True, store=True, compute='_compute_promotion_recurring_amounts')

    amount_recurring_untaxed = fields.Monetary(string="Untaxed Recurring Amount", compute_sudo=True, store=True, compute='_compute_recurring_amounts', tracking=5)
    amount_recurring_tax = fields.Monetary(string="Recurring Taxes", compute_sudo=True, store=True, compute='_compute_recurring_amounts')
    amount_recurring_total = fields.Monetary(string="Recurring Total", compute_sudo=True, store=True, compute='_compute_recurring_amounts')

    amount_non_recurring_untaxed = fields.Monetary(string="Untaxed One Time Fee Amount", compute_sudo=True, store=True, compute='_compute_non_recurring_amounts', tracking=5)
    amount_non_recurring_tax = fields.Monetary(string="One Time Fee Taxes", compute_sudo=True, store=True, compute='_compute_non_recurring_amounts')
    amount_non_recurring_total = fields.Monetary(string="One Time Fee Total", compute_sudo=True, store=True, compute='_compute_non_recurring_amounts')

    amount_untaxed = fields.Monetary(string="Untaxed Amount", compute_sudo=True, store=True, compute='_compute_amounts', tracking=5)
    amount_tax = fields.Monetary(string="Taxes", compute_sudo=True, store=True, compute='_compute_amounts')
    amount_total = fields.Monetary(string="Total", compute_sudo=True, store=True, compute='_compute_amounts', tracking=4)

    amount_by_contract = fields.Monetary(
        string="Amount by Contract",
        store=True, compute="_compute_amount_by_contract",
        tracking=5,
        compute_sudo=True,
        help='Calculated (Total Recurring x Contract Period) + OTF\n(Tax Excluded)'
    )

    signed_attachment = fields.Binary()

    tax_totals = fields.Binary(compute='_compute_tax_totals', exportable=False, compute_sudo=True)
    is_allow_change_order_confirmation = fields.Boolean(
        compute='_compute_is_allow_change_order_confirmation',
        compute_sudo=True
    )
    order_confirmation = fields.Selection(
        selection=[('signature', 'By Signature Only (Paylater)'), ('payment', 'By Payment (Down Payment)')],
        string='Order Confirmation',
        default='payment',
        required=True
    )
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string="Payment Terms",
        compute='_compute_payment_term_id',
        store=True, readonly=False, precompute=True, check_company=True,
        compute_sudo=True,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    
    sale_order_count = fields.Integer(
        compute='_compute_sale_order_count',
        compute_sudo=True
    )
    work_order_count = fields.Integer(
        compute='_compute_work_order_count',
        compute_sudo=True
    )
    domain_product_by_category = fields.One2many('uom.category', compute_sudo=True, compute='_domain_product_by_category')
    subscription_count = fields.Integer(
        compute='_compute_subscription_count',
        compute_sudo=True,
        store=False
    )
    note = fields.Html(
        string='Term and conditions'
    )
    contributions = fields.One2many(
        string='Sales Contributions',
        comodel_name='sale.quotation.contribution',
        inverse_name='sale_quotation_id',
        required=True,
    )
    domain_assigned_sales_contributions = fields.One2many(
        'res.users',
        compute='_compute_domain_assigned_sales_contributions',
        compute_sudo=True
    )
    external_template_id = fields.Many2one(
        comodel_name="external.template",
        domain=domain_external_template_id
    )

    @api.depends('quotation_lines', 'promotion_quotation_lines')
    def _compute_taxes(self):
        for rec in self:
            rec.taxes = False
            taxes = []
            for tax in rec.quotation_lines.tax_id:
                if tax.description not in taxes:
                    taxes.append(tax.description)
            for tax in rec.promotion_quotation_lines.tax_id:
                if tax.description not in taxes:
                    taxes.append(tax.description)
            rec.taxes = '(%s)' % ','.join(taxes)

    @api.model_create_multi
    def create(self, vals_list):
        quotations = super(SaleQuotation, self).create(vals_list)
        template = self.env['external.template'].search([('model','=', self._name),('is_default','=', True)], limit=1)
        for res in quotations:
            if res.sale_promotion_id:
                template = res.sale_promotion_id
            else:
                res.external_template_id = template.id
            res.note = template.render_template(res)
            res.calculate_promotion()
        return quotations
    
    @api.onchange("crm_deal_number")
    def onchange_crm_deal_number(self):
        for rec in self:
            if rec.crm_deal_number and not re.match(r'^(DEALS\-OMG\-\d{1,})$', rec.crm_deal_number):
                rec.crm_deal_number = "DEALS-OMG-"
                raise ValidationError("Maaf, Deals Number hanya bisa diisi menggunakan Pola DEALS-OMG-XXX")

    @api.constrains("crm_deal_number")
    def _check_crm_deal_number(self):
        for rec in self:
            if rec.crm_deal_number and not re.match(r'^(DEALS\-OMG\-\d{1,})$', rec.crm_deal_number):
                rec.crm_deal_number = "DEALS-OMG-"
                raise ValidationError("Maaf, Deals Number hanya bisa diisi menggunakan Pola DEALS-OMG-XXX")

    @api.onchange("external_template_id","sale_promotion_id")
    def onchange_external_template_id(self):
        if self.sale_promotion_id:
            self.note = self.sale_promotion_id.render_template(self)
        elif self.external_template_id and not self.sale_promotion_id:
            self.note = self.external_template_id.render_template(self)


    def get_approval_state(self):
        return QUOTATION_STATE_REQUEST
    
    def get_rejection_state(self):
        return 'reject'

    def action_request(self):
        if len(self.quotation_lines) == 0:
            raise UserError("Nothing to quot, please fill some product !")
        if not self.is_need_approval:
            raise UserError("There is no approval configuration !")

        self.action_request_approval()

    @api.depends('user_id')
    def _compute_is_user_id_readonly(self):
        for rec in self:
            if self.env.user.has_group('sales_team.group_sale_salesman_all_leads'):
                rec.is_user_id_readonly = False
                continue
            rec.is_user_id_readonly = True

    def action_view_wo(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'work.order',
            'view_mode': 'tree,form',
            'name': _('Work Order'),
            'domain': [
                ('work_order_products.sale_quotation_id', '=', self.id)
            ]
        }

    @api.onchange('recurring_plan_id')
    def _onchange_recurring_plan_id(self):
        usage_month_uom = self.env.ref('mceasy_erp.product_uom_package_subscription_usage_month')
        for quotation in self:
            for line in quotation.quotation_lines:
                if line.product_uom == usage_month_uom and quotation.recurring_plan_id.length_in_month > 1:
                    quotation.recurring_plan_id = self.env.ref('mceasy_erp.subscription_plan_month')
                    raise UserError(f"{line.name} must have monthly recurring plan because of the {line.product_uom.name} unit")
            
            if len(quotation.sale_promotion_id) == 0:
                continue

            effective_in_month = quotation.sale_promotion_id.effective_in_month
            if len(quotation.sale_promotion_id.first_recurring_plan) == 1:
                first_length_in_month = quotation.sale_promotion_id.first_recurring_plan.length_in_month
                if effective_in_month > first_length_in_month and effective_in_month % first_length_in_month != 0:
                    raise UserError("Sorry, the promotion (effective in month) isn't balance with the first recurring plan, it will cause miscalculate promotion")
            
            length_in_month = quotation.recurring_plan_id.length_in_month
            if effective_in_month > length_in_month and effective_in_month % length_in_month != 0:
                raise UserError("Sorry, the promotion (effective in month) isn't balance with the selected recurring plan, it will cause miscalculate promotion")
    
    @api.onchange('quotation_lines')
    def _onchange_quotation_lines(self):
        usage_month_uom = self.env.ref('mceasy_erp.product_uom_package_subscription_usage_month')
        for quotation in self:
            for line in quotation.quotation_lines:
                if line.product_uom == usage_month_uom and quotation.recurring_plan_id.length_in_month > 1:
                    quotation.recurring_plan_id = self.env.ref('mceasy_erp.subscription_plan_month')
                    continue

    @api.depends('quotation_lines')
    def _compute_promotion_quotation_lines(self):
        for rec in self:
            promotion_lines = self.env['sale.quotation.promotion.line'].browse()
            for l in rec.quotation_lines:
                for p in l.promotion_lines:
                    promotion_lines += p
            rec.promotion_quotation_lines = promotion_lines

    @api.depends('company_id')
    def _compute_tax_country_id(self):
        for record in self:
            record.tax_country_id = record.company_id.account_fiscal_country_id

    @api.depends('company_id')
    def _compute_currency_id(self):
        for quotation in self:
            quotation.currency_id = quotation.company_id.currency_id or self.env.ref('base.main_company').currency_id
    
    @api.depends('quotation_lines.price_subtotal', 'quotation_lines.price_tax', 'quotation_lines.price_total')
    def _compute_promotion_recurring_amounts(self):
        """Compute the total amounts of the Quotation."""
        for quotation in self:
            quotation_lines = quotation.promotion_quotation_lines
            tax_results = self.env['account.tax']._compute_taxes([
                line._convert_to_tax_base_line_dict(**line._convert_to_tax_base_line_kwargs())
                for line in quotation_lines if line.product_uom_category_id == self.env.ref('mceasy_erp.product_uom_categ_package_subscription')
            ])
            totals = tax_results['totals']
            amount_untaxed = totals.get(quotation.currency_id, {}).get('amount_untaxed', 0.0)
            amount_tax = totals.get(quotation.currency_id, {}).get('amount_tax', 0.0)

            quotation.amount_promotion_recurring_untaxed = amount_untaxed
            quotation.amount_promotion_recurring_tax = amount_tax
            quotation.amount_promotion_recurring_total = quotation.amount_promotion_recurring_untaxed + quotation.amount_promotion_recurring_tax

    @api.depends('quotation_lines.price_subtotal', 'quotation_lines.price_tax', 'quotation_lines.price_total')
    def _compute_recurring_amounts(self):
        """Compute the total amounts of the Quotation."""
        for quotation in self:
            quotation_lines = quotation.quotation_lines
            tax_results = self.env['account.tax']._compute_taxes([
                line._convert_to_tax_base_line_dict(**line._convert_to_tax_base_line_kwargs())
                for line in quotation_lines if line.product_uom_category_id == self.env.ref('mceasy_erp.product_uom_categ_package_subscription')
            ])
            totals = tax_results['totals']
            amount_untaxed = totals.get(quotation.currency_id, {}).get('amount_untaxed', 0.0)
            amount_tax = totals.get(quotation.currency_id, {}).get('amount_tax', 0.0)

            quotation.amount_recurring_untaxed = amount_untaxed
            quotation.amount_recurring_tax = amount_tax
            quotation.amount_recurring_total = quotation.amount_recurring_untaxed + quotation.amount_recurring_tax
    
    @api.depends('quotation_lines.price_subtotal', 'quotation_lines.price_tax', 'quotation_lines.price_total')
    def _compute_non_recurring_amounts(self):
        """Compute the total amounts of the Quotation."""
        for quotation in self:
            quotation_lines = quotation.quotation_lines
            tax_results = self.env['account.tax']._compute_taxes([
                line._convert_to_tax_base_line_dict(**line._convert_to_tax_base_line_kwargs())
                for line in quotation_lines if line.product_uom_category_id != self.env.ref('mceasy_erp.product_uom_categ_package_subscription')
            ])
            totals = tax_results['totals']
            amount_untaxed = totals.get(quotation.currency_id, {}).get('amount_untaxed', 0.0)
            amount_tax = totals.get(quotation.currency_id, {}).get('amount_tax', 0.0)

            quotation.amount_non_recurring_untaxed = amount_untaxed
            quotation.amount_non_recurring_tax = amount_tax
            quotation.amount_non_recurring_total = quotation.amount_non_recurring_untaxed + quotation.amount_non_recurring_tax
    
    @api.depends('quotation_lines.price_subtotal', 'quotation_lines.price_tax', 'quotation_lines.price_total')
    def _compute_amounts(self):
        """Compute the total amounts of the Quotation."""
        for quotation in self:
            # quotation_lines = quotation.quotation_lines
            # tax_results = self.env['account.tax']._compute_taxes([
            #     line._convert_to_tax_base_line_dict(**line._convert_to_tax_base_line_kwargs())
            #     for line in quotation_lines
            # ])
            # totals = tax_results['totals']
            # amount_untaxed = totals.get(quotation.currency_id, {}).get('amount_untaxed', 0.0)
            # amount_tax = totals.get(quotation.currency_id, {}).get('amount_tax', 0.0)

            # quotation.amount_untaxed = amount_untaxed
            # quotation.amount_tax = amount_tax
            if len(quotation.promotion_quotation_lines) > 0:
                quotation.amount_untaxed = quotation.amount_non_recurring_untaxed + quotation.amount_promotion_recurring_untaxed
                quotation.amount_tax = quotation.amount_non_recurring_tax + quotation.amount_promotion_recurring_tax
            else:
                quotation.amount_untaxed = quotation.amount_non_recurring_untaxed + quotation.amount_recurring_untaxed
                quotation.amount_tax = quotation.amount_non_recurring_tax + quotation.amount_recurring_tax

            quotation.amount_total = quotation.amount_untaxed + quotation.amount_tax
    
    @api.depends('amount_non_recurring_untaxed', 'amount_recurring_untaxed', 'contract_period_id')
    def _compute_amount_by_contract(self):
        for quotation in self:
            quotation.amount_by_contract = quotation.amount_non_recurring_untaxed + (
                quotation.amount_recurring_untaxed * quotation.contract_period_id.length_in_month
            )

    @api.depends('quotation_lines.tax_id', 'quotation_lines.discounted_price', 'amount_total', 'amount_untaxed', 'currency_id')
    def _compute_tax_totals(self):
        for quotation in self:
            quotation_lines = quotation.quotation_lines
            quotation.tax_totals = self.env['account.tax']._prepare_tax_totals(
                [x._convert_to_tax_base_line_dict(**x._convert_to_tax_base_line_kwargs()) for x in quotation_lines],
                quotation.currency_id or quotation.company_id.currency_id,
            )
    
    @api.depends('partner_id', 'order_confirmation')
    def _compute_payment_term_id(self):
        for rec in self:
            if rec.order_confirmation == 'signature':
                rec.payment_term_id = False
                continue
            
            if rec.payment_term_id:
                continue

            rec = rec.with_company(rec.company_id)
            if rec.partner_id.property_payment_term_id:
                rec.payment_term_id = rec.partner_id.property_payment_term_id
            else:
                terms = self.env['account.payment.term'].search([])
                if len(terms) > 0:
                    rec.payment_term_id = terms[0].id
    
    @api.depends('contract_name', 'contract_id')
    def _compute_is_contract_addendumed(self):
        self.is_contract_addendumed = False
        if self.contract_id:
            self.is_contract_addendumed = self.contract_name != self.contract_id.name

    @api.onchange('domain_assigned_sales_contributions')
    def _onchange_domain_assigned_sales_contributions(self):
        for c in self.contributions:
            c.percentage = 1 / len(self.domain_assigned_sales_contributions)

    @api.onchange('user_id')
    def _onchange_user_id(self):
        self.contributions = [fields.Command.clear()]
        self.contributions = [fields.Command.create({
            'sales': self.user_id.id,
            'sales_team': self.user_id.sale_team_id.id,
            'percentage': 1,
            'start_date': self.quotation_date,
        })]
    
    @api.depends('contributions')
    def _compute_domain_assigned_sales_contributions(self):
        users = []
        self.domain_assigned_sales_contributions = False
        for c in self.contributions:
            users.append(c.sales.id)
        self.domain_assigned_sales_contributions = users

    @api.depends('company_id')
    def _domain_product_by_category(self):
        self.domain_product_by_category = domain_quotation_pricelist_by_uom_category(self)

    @api.depends('sale_promotion_id')
    def _compute_domain_contract_period(self):
        for rec in self:
            if len(rec.sale_promotion_id) == 1 and rec.sale_promotion_id.contract_period_rule == 'specific':
                allowed_contract_period = self.env['sale.contract.period'].search([
                    ('id', 'in', rec.sale_promotion_id.allowed_contract_periods.ids)
                ])
            else:
                allowed_contract_period = self.env['sale.contract.period'].search([])
            rec.domain_contract_period = allowed_contract_period

    @api.depends('sale_promotion_id')
    def _compute_domain_recurring_plan(self):
        for rec in self:
            if len(rec.sale_promotion_id) == 1 and rec.sale_promotion_id.recurring_plan_rule == 'specific':
                allowed_recurring_plan = self.env['subscription.plan'].search([
                    ('id', 'in', rec.sale_promotion_id.allowed_recurring_plans.ids)
                ])
            else:
                allowed_recurring_plan = self.env['subscription.plan'].search([])
            rec.domain_recurring_plan = allowed_recurring_plan
    
    @api.onchange('sale_promotion_id')
    def _onchange_sale_promotion_id(self):
        if len(self.sale_promotion_id) == 1 and self.sale_promotion_id.recurring_plan_rule == 'specific':
            if len(self.sale_promotion_id.allowed_recurring_plans) > 0:
                self.recurring_plan_id = self.sale_promotion_id.allowed_recurring_plans[0]

        if len(self.sale_promotion_id) == 1 and self.sale_promotion_id.contract_period_rule == 'specific':
            if len(self.sale_promotion_id.allowed_contract_periods) > 0:
                self.contract_period_id = self.sale_promotion_id.allowed_contract_periods[0]
        
        if len(self.sale_promotion_id) == 1 and self.sale_promotion_id.allowed_order_confirmation != 'all':
            self.order_confirmation = self.sale_promotion_id.allowed_order_confirmation
    
    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if len(self.sale_promotion_id) == 1 and self.sale_promotion_id.customer_rule == 'specific':
            if self.partner_id.id not in self.sale_promotion_id.allowed_customers.ids:
                raise UserError(f"This customer ({self.partner_id.name}) is not allowed to use promo: {self.sale_promotion_id.name}")
        
    @api.onchange('quotation_lines', 'sale_promotion_id')
    def onchange_sale_promotion_id_or_quotation_lines(self):
        for rec in self:
            rec.calculate_promotion()

    def calculate_promotion(self):
        for l in self.quotation_lines:
            l.promotion_lines = [fields.Command.clear()]

        if len(self.sale_promotion_id) == 0:
            return
        product_ids = self.quotation_lines.mapped('product_id').ids
        if self.sale_promotion_id.product_rule == 'specific':
            product_ids = self.env['sale.promotion.product'].search([
                ('product_id', 'in', product_ids),
                ('sale_promotion_id', '=', self.sale_promotion_id.id),
            ]).mapped('product_id').ids

        if self.sale_promotion_id.product_rule == 'all':
            if self.sale_promotion_id.type == 'subscription_month':
                product_ids = self.env['product.product'].search([
                    ('product_tmpl_id.uom_id', '=', self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month').id)
                ]).ids
            else:
                product_ids = self.env['product.product'].search([
                    ('product_tmpl_id.uom_id', 'in', [
                        self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month').id,
                        self.env.ref('mceasy_erp.product_uom_package_subscription_usage_month').id,
                    ])
                ]).ids
        
        for l in self.quotation_lines:
            promotion_lines = []
            if l.product_id.id not in product_ids:
                continue

            if self.sale_promotion_id.quantity_rule == 'must_greater_and_equal' and l.uom_qty < self.sale_promotion_id.minimum_quantity_allowed:
                continue

            eligible_quantity = l.uom_qty

            if self.sale_promotion_id.quantity_rule == 'limited_to_maximum_quantity' and l.uom_qty > self.sale_promotion_id.maximum_quantity_allowed:
                eligible_quantity = self.sale_promotion_id.maximum_quantity_allowed

            standart_price = l.standart_price
            discounted_price = l.discounted_price
            
            effective_in_month = self.sale_promotion_id.effective_in_month
            full_multipler = (self.sale_promotion_id.first_recurring_plan or self.recurring_plan_id).length_in_month
            rest_multipler = full_multipler - effective_in_month
            if rest_multipler < 0:
                rest_multipler = 0
                effective_in_month = full_multipler

            if self.sale_promotion_id.type == 'price_percentage':
                if self.sale_promotion_id.price_percentage_rule == 'base_from_standart_price':
                    discounted_price = self.currency_id.round((standart_price * rest_multipler + (standart_price * effective_in_month * self.sale_promotion_id.calculation / 100)) / full_multipler)
                elif self.sale_promotion_id.price_percentage_rule == 'base_from_discounted_price':
                    discounted_price = self.currency_id.round((discounted_price * rest_multipler + (discounted_price * effective_in_month * (100 - self.sale_promotion_id.calculation) / 100)) / full_multipler)
                elif self.sale_promotion_id.price_percentage_rule == 'replace':
                    allowed_product = self.env['sale.promotion.product'].search([
                        ('product_id', '=', l.product_id.id),
                        ('sale_promotion_id', '=', self.sale_promotion_id.id),
                    ], limit=1)
                    if len(allowed_product) == 1:
                        standart_price = allowed_product.standart_price
                        discounted_price = allowed_product.discounted_price
            promotion_lines.append(fields.Command.create({
                'sale_promotion_id': self.sale_promotion_id.id,
                'name': l.name,
                'uom_qty': eligible_quantity,
                'product_id': l.product_id.id,
                'product_uom': l.product_uom.id,
                'standart_price': standart_price,
                'discounted_price': discounted_price,
                'tax_id': False if len(l.tax_id.ids) == 0 else l.tax_id.ids,
            }))
            # not eligible quantity
            if (l.uom_qty - eligible_quantity) > 0:
                promotion_lines.append(fields.Command.create({
                    'sale_promotion_id': self.sale_promotion_id.id,
                    'name': l.name,
                    'uom_qty': l.uom_qty - eligible_quantity,
                    'product_id': l.product_id.id,
                    'product_uom': l.product_uom.id,
                    'standart_price': l.standart_price,
                    'discounted_price': l.discounted_price,
                    'tax_id': False if len(l.tax_id.ids) == 0 else l.tax_id.ids,
                    'is_promotion_eligible': False
                }))
            if self.sale_promotion_id.deposit_rule == 'required':
                if l.product_id.uom_id.id == self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month').id:
                    title = f'{l.product_template_id.name}\n- Deposit {self.sale_promotion_id.total_deposit_month} Month'
                    if self.sale_promotion_id.total_deposit_month > 1:
                        title = f'{l.product_template_id.name}\n- Deposit {self.sale_promotion_id.total_deposit_month} Months'
                    promotion_lines.append(fields.Command.create({
                        'sale_promotion_id': self.sale_promotion_id.id,
                        'name': title,
                        'uom_qty': l.uom_qty,
                        'product_id': l.product_id.id,
                        'product_uom': l.product_uom.id,
                        'standart_price': standart_price,
                        'discounted_price': discounted_price,
                        'tax_id': False,
                        'total_deposit_month': self.sale_promotion_id.total_deposit_month
                    }))
            l.promotion_lines = promotion_lines

    @api.depends('sale_promotion_id')
    def _compute_is_allow_change_order_confirmation(self):
        for rec in self:
            rec.is_allow_change_order_confirmation = len(rec.sale_promotion_id) == 0 or rec.sale_promotion_id.allowed_order_confirmation == 'all'
    
    def action_confirm(self):
        if len(self.quotation_lines) == 0:
            raise UserError("Nothing to quot, please fill some product !")
        self.action_compute_deduction_account()
        if self.is_have_purchase_unit and self.purchase_plan_type == 'installment' and (self.sale_promotion_id.first_recurring_plan or self.recurring_plan_id).length_in_month >= 12:
            self.purchase_plan_type = 'cash'
            raise UserError("Recurring plan is more than 12 month, cannot use Purchase Plan: Installment (A2)")

        total_contributions = 0
        for c in self.contributions:
            total_contributions += c.percentage
        if total_contributions != 1.0:
            raise UserError("Sales Contributions must be totaled as 100%")

        contract = self.env['sale.contract'].search([
            ('company_id', '=', self.company_id.id),
            ('partner_id', '=', self.partner_id.id),
        ])
        if not contract:
            contract = self.env['sale.contract'].sudo().create({
                'company_id': self.company_id.id, 
                'partner_id': self.partner_id.id,
                'partner_pic_id': self.responsible_partner_id.id,
                'currency_id': self.currency_id.id, 
                'name': self.env['ir.sequence'].next_by_code('sale.contract').replace('{REF}', self.partner_id.get_legal_initial())
            })
            self.partner_id.write({
                'contract_id': contract.id,
                'property_product_pricelist': False,
            })
        self.write({
            'contract_id': contract.id,
            'contract_name': contract.name
        })
        sales_admin_id = self.env.user.id
        activities = self.env['approval.activity'].search([
            ('approver_id', 'in', self.approval_approvers.ids)
        ], order='id asc', limit=1)
        if len(activities) > 0:
            sales_admin_id = activities.res_user_id.id

        # Temporary used for audit
        if not self.user_sales_admin_id:
            self.write({
                'user_sales_admin_id': sales_admin_id,
            })
        # Enable this if the contract need to addendum
        # else:
        #     contract_addendum = contract.generate_addendum()
        #     contract.write({
        #         'name': contract_addendum,
        #         'partner_pic_id': self.responsible_partner_id.id,
        #     })
        #     self.write({
        #         'contract_name': contract_addendum,
        #     })
        if self.name != _('New'):
            self.write({
                'state': QUOTATION_STATE_SENT,
            })
            return True
        self.write({
            'name': self.env['ir.sequence'].next_by_code('sale.quotation').replace('{REF}', self.partner_id.get_legal_initial()),
            'state': QUOTATION_STATE_SENT,
        })
        return True
    
    def action_signed(self):
        if self.signed_attachment is False:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'type': 'warning',
                    'title': _('No signed quotation attachment !'),
                    'message': _('Please attach a signed quotation attachment !'),
                    'next': {'type': 'ir.actions.act_window_close'},
                },
            }
        if self.signed_on is False:
            self.signed_on = fields.Datetime.now()
        self.write({
            'state': QUOTATION_STATE_SIGNED,
        })
        self.do_reserve_product(self.signed_on)
        return True
    
    def do_reserve_product(self, signed_on):
        if len(self.for_addendum_id) == 0:
            self._process_reserved_product()
        else:
            self.for_addendum_id.write({
                'addendumed_to_id': self.id,
                'state': QUOTATION_STATE_ADDENDUMED,
            })
            for addendum_line in self.quotation_lines:
                addendum_line.addendumed_quotation_line_id.write({
                    'addendumed_quotation_line_id': addendum_line.id,
                    'addendumed_effective_date': fields.Date.add(
                        fields.Date.end_of(signed_on, 'month'), days=1
                    )
                })
                addendum_line.write({
                    'addendumed_quotation_line_id': False
                })

    def action_canceled(self):
        total_sale_order = self.env['sale.order'].search_count([
            ('quotation_id', '=', self.id)
        ])
        if total_sale_order > 0:
            raise UserError("Cannot cancel quotation, because already have Sales Order.")

        self.write({
            'state': QUOTATION_STATE_CANCELED,
        })
    
    def _process_reserved_product(self):
        reserved_products = []
        for quotation_line in self.quotation_lines:
            reserved = {
                'quotation_line_id': quotation_line.id,
                'company_id': quotation_line.company_id.id,
                'partner_id': quotation_line.partner_id.id
            }
            if int(quotation_line.product_uom.id) in [
                int(self.env.ref('mceasy_erp.product_uom_purchase_unit')),
                int(self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month')),
            ]:
                components = quotation_line.product_template_id.package_component_ids
                if len(components) == 0:
                    reserved['name'] = quotation_line.name
                    reserved['product_uom_category_id'] = quotation_line.product_uom_category_id.id
                    reserved['uom_qty'] = quotation_line.uom_qty
                    reserved['product_uom'] = quotation_line.product_uom.id
                    reserved['is_alternative'] = False
                    reserved_products.append(reserved.copy())
                    continue
                for component in components:
                    reserved['name'] = component.component_product_id.name
                    reserved['component_product_id'] = component.component_product_id.id
                    reserved['component_line_id'] = component.id
                    reserved['product_uom_category_id'] = component.component_product_id.uom_id.category_id.id
                    reserved['uom_qty'] = component.qty * quotation_line.uom_qty
                    reserved['product_uom'] = component.component_product_id.uom_id.id
                    reserved['is_alternative'] = False
                    reserved_products.append(reserved.copy())
                    for alternative_component in component.alternatives:
                        reserved['name'] = alternative_component.name
                        reserved['component_product_id'] = alternative_component.id
                        reserved['component_line_id'] = component.id
                        reserved['product_uom_category_id'] = alternative_component.uom_id.category_id.id
                        reserved['uom_qty'] = 0
                        reserved['product_uom'] = alternative_component.uom_id.id
                        reserved['is_alternative'] = True
                        reserved_products.append(reserved.copy())
            else:
                reserved['name'] = quotation_line.name
                reserved['product_uom_category_id'] = quotation_line.product_uom_category_id.id
                reserved['uom_qty'] = quotation_line.uom_qty
                reserved['product_uom'] = quotation_line.product_uom.id
                reserved['is_alternative'] = False
                reserved_products.append(reserved.copy())
            
        self.env['sale.contract.reserved.product'].create(reserved_products)
    
    def action_rejected(self):
        self.write({
            'state': QUOTATION_STATE_REJECTED
        })
        return True
    
    def action_set_draft(self):
        self.clean_approvers()
        self.write({
            'state': QUOTATION_STATE_DRAFT
        })
        return True
    
    def action_repeat(self):
        quotation_lines = []
        for line in self.quotation_lines:
            quotation_lines.append({
                'name': line.name,
                'product_id': line.product_id.id,
                'product_template_id': line.product_template_id.id,
                'uom_qty': 0,
                'standart_price': line.standart_price,
                'discounted_price': line.discounted_price,
            })

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.quotation',
            'view_mode': 'form',
            'context': get_default_context(self, {
                'state': QUOTATION_STATE_DRAFT,
                'contract_id': False,
                'contract_name': False,
                'signed_on': False,
                'create_date': fields.Datetime.now(),
                'quotation_date': fields.Datetime.now(),
                'quotation_lines': quotation_lines,
                'name': _('New'),
                'for_repeat_id': self.id,
                'for_addendum_id': False,
                'amount_recurring_untaxed': 0,
                'amount_recurring_tax': 0,
                'amount_recurring_total': 0,
                'amount_non_recurring_untaxed': 0,
                'amount_non_recurring_tax': 0,
                'amount_non_recurring_total': 0,
                'amount_untaxed': 0,
                'amount_tax': 0,
                'amount_total': 0,
            })
        }

    def action_addendum(self):
        quotation_lines = []
        for line in self.quotation_lines:
            quotation_lines.append({
                'name': line.name,
                'addendumed_quotation_line_id': line.id,
                'product_id': line.product_id.id,
                'product_template_id': line.product_template_id.id,
                'uom_qty': line.uom_qty,
                'standart_price': line.standart_price,
                'discounted_price': line.discounted_price,
            })

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.quotation',
            'view_mode': 'form',
            'context': get_default_context(self, {
                'state': QUOTATION_STATE_DRAFT,
                'contract_id': False,
                'contract_name': False,
                'signed_on': False,
                'create_date': fields.Datetime.now(),
                'quotation_date': fields.Datetime.now(),
                'quotation_lines': quotation_lines,
                'name': _('New'),
                'for_addendum_id': self.id,
                'for_repeat_id': False,
            })
        }
    
    def action_create_sales_order(self):
        return self.contract_id.action_create_sales_order(self)

    def action_register_promotion(self):
        pass
    
    def _compute_sale_order_count(self):
        for rec in self:
            orders = self.env['sale.order'].search([
                ('quotation_id', '=', rec.id),
                ('state', '!=', 'cancel'),
            ])
            rec.sale_order_count = len(orders)
    
    def _compute_work_order_count(self):
        wo = self.env['work.order'].sudo().search([
            ('work_order_products.sale_quotation_id', '=', self.id)
        ])
        self.work_order_count = len(wo)
    
    def action_view_sale_order(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order',
            'view_mode': 'tree,form',
            'name': _('Sale Orders'),
            'domain': [
                ('quotation_id', '=', self.id),
                ('state', '!=', 'cancel'),
            ]
        }

    def action_compute_deduction_account(self):
        for line in self.quotation_lines:
            quotation_line_deductions = self._process_deduction_accounts(line, line.product_template_id.deduction_account_ids)
            deductions = []
            for deduction in quotation_line_deductions:
                deduction['quotation_line_id'] = line.id
                deductions.append(fields.Command.create(deduction))
            
            line.deductions = deductions
            if len(line.promotion_lines) > 0:
                for promotion_line in line.promotion_lines:
                    deductions = []
                    deduction_rules = promotion_line.sale_promotion_id.get_deduction_rules(promotion_line.product_id)
                    promotion_line_deductions = self._process_deduction_accounts(promotion_line, deduction_rules)
                    for deduction in promotion_line_deductions:
                        deduction['quotation_line_id'] = line.id
                        deduction['quotation_promotion_line_id'] = promotion_line.id
                        deductions.append(fields.Command.create(deduction))
                    promotion_line.deductions = deductions

    def _process_deduction_accounts(self, line, deduction_rules):
        line.deductions = [fields.Command.clear()]
        deduction_accounts = []
        if line.product_uom_category_id != self.env.ref(
            'mceasy_erp.product_uom_categ_package_subscription'
        ):
            return []

        balance = line.standart_price - line.discounted_price
        _calc_balance = line.standart_price - line.discounted_price
        if int(balance) <= 0:
            return []

        rules = []
        for deduction in deduction_rules:
            rules.append({
                'account_id': deduction.account_id.id,
                'calculation_value': deduction.calculation_value,
                'calculation_type': deduction.calculation_type,
            })

        
        fix_deduction = 0
        i = 0
        for deduction in sorted(rules, key=lambda x: x['calculation_type']):
            is_break = False
            if deduction['calculation_type'] == 'fix':
                deduction_amount = deduction['calculation_value']
                if _calc_balance - deduction_amount <= 0:
                    deduction_amount = _calc_balance
                    fix_deduction += deduction_amount
                    is_break = True
                else:
                    fix_deduction += deduction_amount
            elif deduction['calculation_type'] == 'percentage':
                deduction_amount = (deduction['calculation_value'] / 100) * (balance - fix_deduction)
                if _calc_balance - deduction_amount <= 0:
                    deduction_amount = _calc_balance
                    is_break = True

            else:
                deduction_amount = 0
                continue

            _calc_balance = _calc_balance - deduction_amount
            
            if i+1 == len(rules) and _calc_balance > 0:
                deduction_amount = deduction_amount + _calc_balance

            i = i+1

            deduction_accounts.append({
                'account_id': deduction['account_id'],
                'amount': deduction_amount * -1
            })

            if is_break:
                break
        
        return deduction_accounts

    
    def action_view_subscription(self):
        return self.contract_id.action_view_subscription()
    
    def _compute_subscription_count(self):
        subscription_lines = self.env['subscription.line'].search([
            ('quotation_id', 'in', [self.id, self.for_addendum_id.id])
        ])
        total_subscriptions = []
        for line in subscription_lines:
            if line.subscription_id.id in total_subscriptions:
                continue
            total_subscriptions.append(line.subscription_id.id)
        self.subscription_count = len(total_subscriptions)

    @api.depends('quotation_date')
    def _compute_valid_untill_date(self):
        for rec in self:
            rec.valid_untill_date = fields.Date.add(rec.quotation_date, days=12)
    
    @api.depends('quotation_lines')
    def _compute_quotation_x_sale_order(self):
        for rec in self:
            total_ordered = 0
            total_order = 0
            rec.quotation_x_sale_order = 0
            for line in rec.quotation_lines:
                total_order += line.uom_qty
                total_ordered += line.uom_ordered_qty
            if total_order == 0:
                continue
            rec.quotation_x_sale_order = (total_ordered / total_order) * 100
    
    @api.depends('quotation_lines')
    def _compute_quotation_x_activation(self):
        for rec in self:
            rec.quotation_x_activation = 0
            total_activated = 0
            total_order = 0
            for line in rec.quotation_lines:
                total_activated += self.env['subscription.line'].search_count([
                    ('quotation_line_id', '=', line.id),
                    ('start_date', '!=', False)
                ])
                total_order += line.uom_qty
            if total_order == 0:
                continue
            rec.quotation_x_activation = (total_activated / total_order) * 100
    
    @api.depends('quotation_lines')
    def _compute_is_have_purchase_unit(self):
        purchase_unit_uom = self.env.ref('mceasy_erp.product_uom_purchase_unit')
        for rec in self:
            rec.is_have_purchase_unit = False
            for line in rec.quotation_lines:
                if line.product_uom == purchase_unit_uom:
                    rec.is_have_purchase_unit = True
                    break
            if not rec.is_have_purchase_unit:
                rec.purchase_plan_type = False

    @api.depends('allowed_company')
    def _compute_company_id(self):
        for rec in self:
            if len(rec.company_id) == 1:
                continue
            rec.company_id = rec.allowed_company[0]

    @api.depends('user_id')
    def _compute_multi_company(self):
        for rec in self:
            rec.allowed_company = self.env.user.company_ids.filtered(lambda x: x.id in self._context.get('allowed_company_ids'))
            rec.is_company_visible = len(rec.allowed_company) > 1

