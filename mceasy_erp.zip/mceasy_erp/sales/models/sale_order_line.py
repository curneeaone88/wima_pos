from odoo import models, fields, api, _
from odoo.tools import defaultdict

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    quotation_line_id = fields.Many2one(
        comodel_name='sale.quotation.line',
        name='Quotation Line',
        default=False
    )
    quotation_promotion_line_id = fields.Many2one(
        comodel_name='sale.quotation.promotion.line',
        name='Quotation Promotion Line',
        default=False
    )

    quotation_product_uom_qty = fields.Float(
        compute='_compute_quotation_product_uom_qty',
        name='Quantity Quotation'
    )

    uom_ordered_qty = fields.Float(
        related='quotation_line_id.uom_ordered_qty'
    )

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id', 'order_id.recurring_plan_id', 'quotation_line_id', 'quotation_promotion_line_id')
    def _compute_amount(self):
        """
        Compute the amounts of the SO line.
        """
        for line in self:
            tax_results = self.env['account.tax']._compute_taxes([
                (line.quotation_line_id if len(line.quotation_line_id) == 1 else line)._convert_to_tax_base_line_dict(
                    **line._convert_to_tax_base_line_kwargs() if len(line.quotation_line_id) == 1 else {}
                )
            ])
            totals = list(tax_results['totals'].values())[0]
            amount_untaxed = totals['amount_untaxed']
            amount_tax = totals['amount_tax']

            line.update({
                'price_subtotal': amount_untaxed,
                'price_tax': amount_tax,
                'price_total': amount_untaxed + amount_tax,
            })
    
    def _compute_price_unit(self):
        PURCHASE_UNIT_DEFERRED_MONTH = 12
        for line in self:
            if len(line.quotation_line_id) == 1:
                if len(line.quotation_promotion_line_id) == 0:
                    if line.quotation_line_id.is_effected_purchase_plan:
                        if line.order_id.purchase_plan_type == 'cash':
                            line.price_unit = line.quotation_line_id.discounted_price
                        else:
                            line.price_unit = line.currency_id.round(line.quotation_line_id.discounted_price / PURCHASE_UNIT_DEFERRED_MONTH) * line.order_id.recurring_plan_id.length_in_month
                    else:
                        line.price_unit = line.quotation_line_id.discounted_price
                else:
                    if line.quotation_line_id.is_effected_purchase_plan:
                        if line.order_id.purchase_plan_type == 'cash':
                            line.price_unit = line.quotation_promotion_line_id.discounted_price
                        else:
                            line.price_unit = line.currency_id.round(line.quotation_promotion_line_id.discounted_price / PURCHASE_UNIT_DEFERRED_MONTH) * line.order_id.recurring_plan_id.length_in_month
                    else:
                        line.price_unit = line.quotation_promotion_line_id.discounted_price
            else:
                super(SaleOrderLine, line)._compute_price_unit()

    def _convert_to_tax_base_line_kwargs(self):
        self.ensure_one()
        kwargs = {
            'price_unit': self.price_unit,
            'price_subtotal': self.price_subtotal,
            'taxes': self.tax_id,
        }
        if self.order_id.contract_id == False or self.order_id.recurring_plan_id == False:
            return kwargs

        if self.quotation_line_id.product_uom != self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month'):
            kwargs['quantity'] = self.product_uom_qty
            return kwargs
        
        period = self.order_id.recurring_plan_id.billing_period
        months = period.years * 12 + period.months

        if len(self.quotation_promotion_line_id) == 1:
            if self.quotation_promotion_line_id.total_deposit_month > 0:
                kwargs['quantity'] = self.product_uom_qty * self.quotation_promotion_line_id.total_deposit_month
                return kwargs
            
            months = (self.quotation_promotion_line_id.sale_promotion_id.first_recurring_plan or self.quotation_promotion_line_id.recurring_plan_id).length_in_month

            deduction_month = 0
            if self.quotation_promotion_line_id.sale_promotion_id.type == 'subscription_month' and self.quotation_promotion_line_id.is_promotion_eligible:
                deduction_month = self.quotation_promotion_line_id.sale_promotion_id.calculation
            
            multipler = (months - deduction_month)
            if multipler < 0:
                multipler = 0

            kwargs['quantity'] = self.product_uom_qty * multipler
            return kwargs
        kwargs['quantity'] = self.product_uom_qty * months
        return kwargs
    
    @api.onchange('product_uom_qty')
    def _onchange_product_uom_qty(self):
        if len(self.quotation_line_id) == 0:
            return
        
        if self.product_uom_qty > self.quotation_line_id.uom_unordered_qty:
            self.product_uom_qty = self.quotation_line_id.uom_unordered_qty
            return {'warning': {
                'title': _("Warning"),
                'message': _("Sorry, Quantity Order is over quota!")
            }}
    
    @api.depends('product_id', 'company_id', 'quotation_line_id')
    def _compute_tax_id(self):
        taxes_by_product_company = defaultdict(lambda: self.env['account.tax'])
        lines_by_company = defaultdict(lambda: self.env['sale.order.line'])
        cached_taxes = {}
        for line in self:
            if len(line.quotation_line_id) == 1:
                continue
            lines_by_company[line.company_id] += line
        for product in self.product_id:
            for tax in product.taxes_id:
                taxes_by_product_company[(product, tax.company_id)] += tax
        for company, lines in lines_by_company.items():
            for line in lines.with_company(company):
                taxes, comp = None, company
                while not taxes and comp:
                    taxes = taxes_by_product_company[(line.product_id, comp)]
                    comp = comp.parent_id
                if not line.product_id or not taxes:
                    # Nothing to map
                    line.tax_id = False
                    continue
                fiscal_position = line.order_id.fiscal_position_id
                cache_key = (fiscal_position.id, company.id, tuple(taxes.ids))
                cache_key += line._get_custom_compute_tax_cache_key()
                if cache_key in cached_taxes:
                    result = cached_taxes[cache_key]
                else:
                    result = fiscal_position.map_tax(taxes)
                    cached_taxes[cache_key] = result
                # If company_id is set, always filter taxes by the company
                line.tax_id = result
    
    def _prepare_invoice_line(self, **optional_values):
        res = super(SaleOrderLine, self)._prepare_invoice_line(**optional_values)
        if self.display_type or self.order_id.contract_id == False or self.order_id.recurring_plan_id == False:
            return res
        
        if self.quotation_line_id.product_uom == self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month'):
            if self.quotation_promotion_line_id.total_deposit_month > 0:
                res['price_unit'] *= self.quotation_promotion_line_id.total_deposit_month
                res['account_id'] = self.company_id.account_security_deposit_id.id
                res['name'] = self.name
                return res

            months = (self.quotation_promotion_line_id.sale_promotion_id.first_recurring_plan or self.order_id.recurring_plan_id).length_in_month
            deduction_month = 0
            if self.quotation_promotion_line_id.sale_promotion_id.type == 'subscription_month' and self.quotation_promotion_line_id.is_promotion_eligible:
                deduction_month = self.quotation_promotion_line_id.sale_promotion_id.calculation

            multipler = (months - deduction_month)
            if multipler < 0:
                multipler = 0

            res['price_unit'] = res['price_unit'] * multipler
            res['name'] = f"{self.quotation_line_id.product_template_id.name}\n- {int((self.quotation_promotion_line_id.sale_promotion_id.first_recurring_plan or self.order_id.recurring_plan_id).length_in_month)} {'Months' if self.order_id.recurring_plan_id.length_in_month > 1 else 'Month'}"
        
        if len(self.quotation_line_id) == 1 and len(self.company_id.account_downpayment_id) == 1:
            res['account_id'] = self.company_id.account_downpayment_id.id
        return res

    @api.depends('quotation_promotion_line_id', 'quotation_line_id')
    def _compute_quotation_product_uom_qty(self):
        for rec in self:
            if len(rec.quotation_promotion_line_id) == 1:
                rec.quotation_product_uom_qty = rec.quotation_promotion_line_id.uom_qty
            else:
                rec.quotation_product_uom_qty = rec.quotation_line_id.uom_qty
