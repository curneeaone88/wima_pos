from odoo import models, fields, api
from odoo.addons.mceasy_erp.service.models.work_order import WORK_ORDER_TYPES

class SaleProductContractActivity(models.Model):
    _name = 'sale.product.contract.activity'
    _description = 'Sale Product Contract Activity'

    name = fields.Char(
        related='product_operation_line_activity_id.name'
    )
    sale_product_contract_id = fields.Many2one(
        comodel_name='sale.product.contract',
        ondelete='cascade'
    )
    contract_id = fields.Many2one(
        related='sale_product_contract_id.contract_id'
    )
    product_template_id = fields.Many2one(
        related='sale_product_contract_id.product_template_id'
    )
    product_operation_line_id = fields.Many2one(
        comodel_name='product.operation.template.line'
    )
    product_operation_line_activity_id = fields.Many2one(
        comodel_name='product.operation.template.line.activity'
    )
    for_billing_action = fields.Boolean(
        related='product_operation_line_activity_id.for_billing_action'
    )
    outstanding_work_order = fields.Selection(
        selection=WORK_ORDER_TYPES,
        string='Outstanding Work Order',
    )
    work_order_id = fields.Many2one(
        comodel_name='work.order',
        default=False
    )
    work_order_activity_id = fields.Many2one(
        comodel_name='work.order.activity',
        default=False
    )

    def _compute_display_name(self):
        for rec in self:
            rec.display_name = f'{rec.product_template_id.name} - {rec.product_operation_line_activity_id.name}'

    def next_operation(self):
        return self.product_operation_line_id.operation_template_id.get_next_operation(
            self.product_operation_line_id.type,
            self.outstanding_work_order
        )
    
    def action_activate(self, work_order_id):
        self.work_order_id = work_order_id

    def action_activate_line(self, work_order_activity_id):
        self.work_order_activity_id = work_order_activity_id

class SaleProductContract(models.Model):
    _name = 'sale.product.contract'
    _description = 'Sale Product Contract'

    name = fields.Char(
        string='Description',
        required=True
    )
    contract_id = fields.Many2one(
        comodel_name='sale.contract'
    )
    product_template_id = fields.Many2one(
        comodel_name='product.template'
    )
    activities = fields.One2many(
        comodel_name='sale.product.contract.activity',
        inverse_name='sale_product_contract_id'
    )
    is_done = fields.Boolean(
        compute='_compute_is_done_is_for_billing'
    )
    is_billed = fields.Boolean(
        compute='_compute_is_done_is_for_billing'
    )
    is_for_billing = fields.Boolean(
        compute='_compute_is_done_is_for_billing'
    )

    @api.depends('activities')
    def _compute_is_done_is_for_billing(self):
        for rec in self:
            rec.is_done = False
            rec.is_for_billing = False
            rec.is_billed = False
            total_act = len(rec.activities)
            for act in rec.activities:
                total_act -= 1
                rec.is_for_billing = rec.is_for_billing or act.for_billing_action
                if not rec.is_billed and act.for_billing_action and len(act.work_order_id) == 1:
                    rec.is_billed = True
            rec.is_done = total_act == 0
