from odoo import models, fields, api


class SalePromotionProduct(models.Model):
    _name = 'sale.promotion.product'
    _description = 'Eligible Product'

    sale_promotion_id = fields.Many2one(
        comodel_name='sale.promotion',
        required=True,
        ondelete='cascade'
    )
    price_percentage_rule = fields.Selection(
        related='sale_promotion_id.price_percentage_rule'
    )
    parent_state = fields.Selection(
        related='sale_promotion_id.state'
    )
    currency_id = fields.Many2one(
        related='sale_promotion_id.currency_id',
    )
    product_id = fields.Many2one(
        comodel_name='product.product'
    )
    product_template_id = fields.Many2one(
        related='product_id.product_tmpl_id'
    )
    # only used if the sale promotion price percentage rule is replace
    standart_price = fields.Monetary()
    discounted_price = fields.Monetary()
    product_deductions = fields.One2many(
        comodel_name='sale.promotion.product.deduction.account',
        inverse_name='sale_promotion_product_id'
    )

    def action_product_deductions(self):
        view = self.env.ref('mceasy_erp.sale_promotion_product_deduction_account_form_view')

        return {
            'name': 'Deductions',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'sale.promotion.product',
            'views': [(view.id, 'form')],
            'view_id': view.id,
            'target': 'new',
            'res_id': self.id
        }