from odoo import models, fields, api
from collections import defaultdict


class SaleQuotationPromotionLine(models.Model):
    _name = 'sale.quotation.promotion.line'
    _description = 'Quotation Line After Promotion'

    name = fields.Char(
        string="Description",
        compute='_compute_name',
        store=True, readonly=False, required=True
    )
    product_report_description = fields.Char(
        compute='_compute_product_report_description'
    )
    quotation_id = fields.Many2one(
        comodel_name='sale.quotation',
        string="Quotation Reference",
        related='quotation_line_id.quotation_id',
        ondelete='cascade', index=True, copy=False, store=True
    )
    quotation_line_id = fields.Many2one(
        comodel_name='sale.quotation.line',
        required=True,
        ondelete='cascade'
    )
    deductions = fields.One2many(
        comodel_name='sale.quotation.line.deduction',
        inverse_name='quotation_promotion_line_id'
    )
    sale_promotion_id = fields.Many2one(
        comodel_name='sale.promotion',
        required=True
    )
    recurring_plan_id = fields.Many2one(
        related='quotation_id.recurring_plan_id',
    )
    company_id = fields.Many2one(
        related='quotation_id.company_id',
        store=True, index=True
    )
    partner_id = fields.Many2one(
        related='quotation_id.partner_id',
        store=True, index=True
    )
    contract_id = fields.Many2one(
        related='quotation_id.contract_id'
    )
    currency_id = fields.Many2one(
        related='quotation_id.currency_id',
        depends=['quotation_id.currency_id'],
        store=True)
    product_id = fields.Many2one(
        comodel_name='product.product',
        string="Product",
        change_default=True, ondelete='restrict', check_company=True, index='btree_not_null',
        store=True,
        domain="[('sale_ok', '=', True)]")
    product_template_id = fields.Many2one(
        string="Product Template",
        comodel_name='product.template',
        compute='_compute_product_template_id',
        readonly=False,
        search='_search_product_template_id',
        # previously related='product_id.product_tmpl_id'
        # not anymore since the field must be considered editable for product configurator logic
        # without modifying the related product_id when updated.
        domain=[('sale_ok', '=', True)])
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', depends=['product_id'])
    uom_qty = fields.Float(
        string="Qty",
        digits='Product Unit of Measure', default=1.0,
        store=True, readonly=False, required=True
    )
    uom_ordered_qty = fields.Float(
        string='Qty Ordered',
        compute='_compute_uom_ordered_qty'
    )
    uom_unordered_qty = fields.Float(
        string='Qty Unordered',
        compute='_compute_uom_unordered_qty'
    )
    product_uom = fields.Many2one(
        comodel_name='uom.uom',
        string="Unit of Measure",
        compute='_compute_product_uom',
        store=True, readonly=True, 
        precompute=True, 
        ondelete='restrict',
        domain="[('category_id', '=', product_uom_category_id)]")
    standart_price = fields.Monetary(
        string="Standart Price",
        required=True)
    discounted_price = fields.Monetary(
        string="Discounted Price",
        required=True)
    tax_id = fields.Many2many(
        comodel_name='account.tax',
        string="Taxes",
        store=True, readonly=False,
        context={'active_test': False},
        check_company=True)
    price_subtotal = fields.Monetary(
        string="Subtotal",
        compute='_compute_amount',
        store=True)
    price_subtotal_sales = fields.Monetary(
        string="Subtotal Sales",
        compute='_compute_price_subtotal_sales')
    price_tax = fields.Float(
        string="Total Tax",
        compute='_compute_amount',
        store=True)
    price_total = fields.Monetary(
        string="Total",
        compute='_compute_amount',
        store=True)
    is_recurring = fields.Boolean(
        compute='_compute_is_recurring'
    )
    is_effected_purchase_plan = fields.Boolean(
        compute='_compute_is_effected_purchase_plan'
    )
    is_promotion_eligible = fields.Boolean(
        default=True
    )
    total_deposit_month = fields.Integer(
        default=False
    )

    def _get_quotation_line_multiline_description_sale(self):
        self.ensure_one()
        return self.product_id.get_product_multiline_description_sale()

    @api.depends('product_id')
    def _compute_name(self):
        for line in self:
            lang = line.partner_id.lang or self.env.user.lang
            if not line.product_id:
                continue
            if not line.partner_id.is_public:
                line = line.with_context(lang=lang)
            name = line._get_quotation_line_multiline_description_sale()
            line.name = name
    
    @api.depends('product_id')
    def _compute_product_template_id(self):
        for line in self:
            line.product_template_id = line.product_id.product_tmpl_id

    def _search_product_template_id(self, operator, value):
        return [('product_id.product_tmpl_id', operator, value)]
    
    @api.depends('product_id')
    def _compute_product_uom(self):
        for line in self:
            if not line.product_uom or (line.product_id.uom_id.id != line.product_uom.id):
                line.product_uom = line.product_id.uom_id
    
    @api.depends('uom_qty', 'standart_price')
    def _compute_price_subtotal_sales(self):
        for line in self:
            if line.is_recurring:
                deduction_month = 0
                if line.sale_promotion_id.type == 'subscription_month' and line.is_promotion_eligible:
                    deduction_month = line.sale_promotion_id.calculation
                
                multipler = (((line.sale_promotion_id.first_recurring_plan or line.recurring_plan_id).length_in_month) - deduction_month)
                if multipler < 0:
                    multipler = 0
                line.price_subtotal_sales = line.standart_price * line.uom_qty * multipler
            else:
                line.price_subtotal_sales = line.standart_price * line.uom_qty

    @api.depends('product_uom_category_id')
    def _compute_is_recurring(self):
        recurring_category = self.env.ref('mceasy_erp.product_uom_categ_package_subscription')
        for rec in self:
            if rec.total_deposit_month > 0:
                rec.is_recurring = False
                continue
            rec.is_recurring = rec.product_uom_category_id == recurring_category
    
    @api.depends('product_uom_category_id')
    def _compute_is_effected_purchase_plan(self):
        purchase_category = self.env.ref('mceasy_erp.product_uom_categ_purchase')
        for rec in self:
            if rec.total_deposit_month > 0:
                rec.is_effected_purchase_plan = False
                continue
            rec.is_effected_purchase_plan = rec.product_uom_category_id == purchase_category
    
    def _convert_to_tax_base_line_dict(self, **kwargs):
        """ Convert the current record to a dictionary in order to use the generic taxes computation method
        defined on account.tax.

        :return: A python dictionary.
        """
        self.ensure_one()
        return self.env['account.tax']._convert_to_tax_base_line_dict(
            self,
            partner=self.partner_id,
            currency=self.currency_id,
            product=self.product_id,
            **kwargs,
        )
    
    def _convert_to_tax_base_line_kwargs(self):
        self.ensure_one()
        kwargs = {
            'price_unit': self.discounted_price,
            'price_subtotal': self.price_subtotal,
            'taxes': self.tax_id,
        }
        if self.product_uom != self.env.ref('mceasy_erp.product_uom_package_subscription_unit_month'):
            kwargs['quantity'] = self.uom_qty
            return kwargs
        
        if self.total_deposit_month > 0:
            kwargs['quantity'] = self.uom_qty * self.total_deposit_month
        else:
            months = (self.sale_promotion_id.first_recurring_plan or self.recurring_plan_id).length_in_month

            deduction_month = 0
            if self.sale_promotion_id.type == 'subscription_month' and self.is_promotion_eligible:
                deduction_month = self.sale_promotion_id.calculation

            multipler = (months - deduction_month)
            if multipler < 0:
                multipler = 0
            kwargs['quantity'] = self.uom_qty * multipler
        return kwargs
    
    @api.depends('uom_qty', 'sale_promotion_id', 'discounted_price', 'tax_id', 'recurring_plan_id')
    def _compute_amount(self):
        """
        Compute the amounts of the Quotation line.
        """
        for line in self:
            tax_results = self.env['account.tax']._compute_taxes([
                line._convert_to_tax_base_line_dict(**line._convert_to_tax_base_line_kwargs())
            ])
            totals = list(tax_results['totals'].values())[0]
            amount_untaxed = totals['amount_untaxed']
            amount_tax = totals['amount_tax']

            line.update({
                'price_subtotal': amount_untaxed,
                'price_tax': amount_tax,
                'price_total': amount_untaxed + amount_tax,
            })
    
    def _compute_product_report_description(self):
        for rec in self:
            if rec.name.strip() == rec.product_template_id.name.strip():
                rec.product_report_description = False
                continue
            descriptions = []
            if len(rec.name.split('\n')) == 0:
                rec.product_report_description = False
                continue

            for x in rec.name.split('\n'):
                if x.strip() == rec.product_template_id.name.strip():
                    continue
                descriptions.append(x)
            if len(descriptions) == 0:
                rec.product_report_description = False
                continue
            rec.product_report_description = '\n'.join(descriptions)
    
    def _compute_uom_ordered_qty(self):
        for rec in self:
            qty = 0.0
            lines = self.env['sale.order.line'].search([
                ('quotation_promotion_line_id', '=', rec.id),
                ('state', '=', 'sale')
            ])
            for line in lines:
                if line.quotation_promotion_line_id.total_deposit_month > 0:
                    continue
                qty = qty + line.product_uom_qty
            rec.uom_ordered_qty = qty

    @api.depends('uom_ordered_qty')
    def _compute_uom_unordered_qty(self):
        for rec in self:
            rec.uom_unordered_qty = rec.uom_qty - rec.uom_ordered_qty