from odoo import models, fields, api, _
from odoo.exceptions import UserError
import io
import qrcode
import base64


class SaleOrder(models.Model):
    _name = 'sale.order'
    _inherit = ['sale.order', 'approval.mixin']
    def domain_external_template_id(self):
        return [('model','=', self._name)]

    contract_id = fields.Many2one(
        comodel_name='sale.contract',
        readonly=True,
        default=False,
        ondelete='restrict'
    )

    quotation_id = fields.Many2one(
        comodel_name='sale.quotation',
        default=False,
        ondelete='restrict'
    )

    recurring_plan_id = fields.Many2one(
        string='Recurring Plan',
        related='quotation_id.recurring_plan_id',
        store=True
    )
    purchase_plan_type = fields.Selection(
        related='quotation_id.purchase_plan_type',
        store=True
    )

    contract_name = fields.Char(
        related='quotation_id.contract_name',
        string='Contract Number'
    )

    is_contract_addendumed = fields.Boolean(
        related='quotation_id.is_contract_addendumed'
    )

    subscription_count = fields.Integer(
        compute='_compute_subscription_count'
    )

    outstanding_work_order_count = fields.Integer(
        compute='_compute_outstanding_work_order_count'
    )
    work_order_count = fields.Integer(
        compute='_compute_work_order_count'
    )

    state = fields.Selection(
        selection_add=[
            ('draft', 'Draft'),
            ('request', 'Requested'),
            ('sent', 'Sent'),
            ('finance_request', 'Requested to Finance'),
            ('sale', 'Confirmed'),
            ('cancel', 'Canceled'),
            ('rejected', 'Rejected')
        ],
        default='draft'
    )
    external_template_id = fields.Many2one(
        comodel_name="external.template",
        domain=domain_external_template_id
    )
    confirmation_type = fields.Selection(
        selection=[
            ('payment', 'Down Payment'),
            ('signature', 'Paylater'),
        ],
        required=True,
        store=False,
        readonly=False,
        compute='_compute_confirmation_type'
    )
    confirmation_attachment = fields.Binary()

    @api.model
    def create(self,vals):
        res = super(SaleOrder, self).create(vals)
        template = self.env['external.template'].search([('model','=', self._name),('is_default','=', True)], limit=1)
        res.external_template_id = template.id
        res.note = template.render_template(res)
        return res

    @api.onchange("external_template_id")
    def onchange_external_template_id(self):
        if self.external_template_id:
            self.note = self.external_template_id.render_template(self)

    @api.onchange('company_id')
    def _onchange_company_id_warning(self):
        pass

    @api.onchange('confirmation_type')
    def _onchange_confirmation_type(self):
        for order in self:
            order.require_payment = order.confirmation_type == 'payment'
            if order.require_payment:
                order.prepayment_percent = 1

    @api.onchange('quotation_id')
    def _onchange_quotation_id(self):
        self.order_line = [fields.Command.clear()]
        order_lines = []
        if len(self.quotation_id.sale_promotion_id) == 0:
            for quotation_line in self.quotation_id.quotation_lines:
                order_lines.append(fields.Command.create({
                    'name': quotation_line.name,
                    'product_id': quotation_line.product_id.id,
                    'product_uom_qty': quotation_line.uom_unordered_qty,
                    'quotation_line_id': quotation_line.id,
                    'tax_id': quotation_line.tax_id,
                }))
        else:
            for quotation_line in self.quotation_id.quotation_lines:
                if len(quotation_line.promotion_lines) == 0:
                    order_lines.append(fields.Command.create({
                        'name': quotation_line.name,
                        'product_id': quotation_line.product_id.id,
                        'product_uom_qty': quotation_line.uom_unordered_qty,
                        'quotation_line_id': quotation_line.id,
                        'tax_id': quotation_line.tax_id,
                    }))
                else:
                    for promotion_line in quotation_line.promotion_lines:
                        order_lines.append(fields.Command.create({
                            'name': promotion_line.name,
                            'product_id': promotion_line.product_id.id,
                            'product_uom_qty': promotion_line.uom_unordered_qty,
                            'quotation_promotion_line_id': promotion_line.id,
                            'quotation_line_id': quotation_line.id,
                            'tax_id': promotion_line.tax_id,
                        })) 
        self.order_line = order_lines

    @api.depends('state', 'order_line.invoice_status')
    def _compute_invoice_status(self):
        """
        Compute the invoice status of a SO. Possible statuses:
        - no: if the SO is not in status 'sale' or 'done', we consider that there is nothing to
          invoice. This is also the default value if the conditions of no other status is met.
        - to invoice: if any SO line is 'to invoice', the whole SO is 'to invoice'
        - invoiced: if all SO lines are invoiced, the SO is invoiced.
        - upselling: if all SO lines are invoiced or upselling, the status is upselling.
        """
        confirmed_orders = self.filtered(lambda so: so.state == 'sale')
        (self - confirmed_orders).invoice_status = 'no'
        if not confirmed_orders:
            return
        line_invoice_status_all = [
            (order.id, invoice_status)
            for order, invoice_status in self.env['sale.order.line']._read_group([
                    ('order_id', 'in', confirmed_orders.ids),
                    ('is_downpayment', '=', False),
                    ('display_type', '=', False),
                ],
                ['order_id', 'invoice_status'])]
        for order in confirmed_orders:
            line_invoice_status = [d[1] for d in line_invoice_status_all if d[0] == order.id]
            if order.state != 'sale':
                order.invoice_status = 'no'
            elif len(order.contract_id) == 1 and order.require_payment is False:
                order.invoice_status = 'no'
            elif any(invoice_status == 'to invoice' for invoice_status in line_invoice_status):
                order.invoice_status = 'to invoice'
            elif line_invoice_status and all(invoice_status == 'invoiced' for invoice_status in line_invoice_status):
                order.invoice_status = 'invoiced'
            elif line_invoice_status and all(invoice_status in ('invoiced', 'upselling') for invoice_status in line_invoice_status):
                order.invoice_status = 'upselling'
            else:
                order.invoice_status = 'no'
    
    def _compute_confirmation_type(self):
        for order in self:
            if order.require_payment:
                order.confirmation_type = 'payment'
            else:
                order.confirmation_type = 'signature'

    @api.depends('contract_id')
    def _compute_require_payment(self):
        for order in self:
            if len(order.contract_id) == 1:
                if order.quotation_id.order_confirmation == 'payment':
                    order.require_payment = True
                    order.prepayment_percent = 1
                else:
                    order.prepayment_percent = 0
                    order.require_payment = False
            else:
                super(SaleOrder, order)._compute_require_payment()
    
    @api.depends_context('lang')
    @api.depends('order_line.tax_id', 'order_line.price_unit', 'amount_total', 'amount_untaxed', 'currency_id')
    def _compute_tax_totals(self):
        for order in self:
            order_lines = order.order_line.filtered(lambda x: not x.display_type)
            order.tax_totals = self.env['account.tax']._prepare_tax_totals(
                [(line.quotation_line_id if len(line.quotation_line_id) == 1 else line)._convert_to_tax_base_line_dict(
                    **line._convert_to_tax_base_line_kwargs() if len(line.quotation_line_id) == 1 else {}
                ) for line in order_lines],
                order.currency_id or order.company_id.currency_id,
            )
    
    def get_approval_state(self):
        if self.state in ['request', 'finance_request']:
            return self.state

        if self.state in 'draft':
            return 'request'
        
        if self.state == 'sent':
            return 'finance_request'

    def get_rejection_state(self):
        return 'reject'

    def action_sales_request(self):
        if len(self.order_line) == 0:
            raise UserError("Nothing to order, please fill some product !")
        if not self.is_need_approval:
            raise UserError("There is no approval configuration !")
        self.action_request_approval()

    def action_send(self):
        self.state = 'draft'
        self.action_quotation_sent()

    def action_request(self):
        if self.confirmation_attachment is False:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'type': 'warning',
                    'title': _('No attachment to confirm !'),
                    'message': _('Please attach a confirmation attachment !'),
                    'next': {'type': 'ir.actions.act_window_close'},
                },
            }
        
        if not self.is_need_approval:
            raise UserError("There is no approval configuration !")
        self.action_request_approval()

    def action_confirm(self):
        if self.confirmation_attachment is False:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'type': 'warning',
                    'title': _('No attachment to confirm !'),
                    'message': _('Please attach a confirmation attachment !'),
                    'next': {'type': 'ir.actions.act_window_close'},
                },
            }

        for line in self.order_line:
            if line.product_uom_qty == 0:
                line.unlink()
                continue
        if len(self.contract_id) == 1 and self.require_payment == False:
            self._action_confirm_by_contract(strict=True)
        
        if self.state != 'sent':
            self.state = 'sent'
        return super(SaleOrder, self).action_confirm()
    
    def action_draft(self):
        orders = self.filtered(lambda s: s.state in ['cancel', 'sent', 'request', 'finance_request', 'rejected'])
        self.clean_approvers()
        return orders.write({
            'state': 'draft',
            'signature': False,
            'signed_by': False,
            'signed_on': False,
        })

    def _action_confirm_by_contract(self, strict=False):
        subscription = self.env['subscription'].search([
            ('company_id', '=', self.company_id.id),
            ('partner_id', '=', self.partner_id.id),
            ('recurring_plan_id', '=', self.recurring_plan_id.id),
        ])
        if not subscription:
            sequence = self.env['ir.sequence'].next_by_code('subscription')
            name = f'{self.recurring_plan_id.code}/{self.partner_id.get_legal_initial()}/{sequence}'
            subscription = self.env['subscription'].create({
                'name': name,
                'company_id': self.company_id.id,
                'partner_id': self.partner_id.id,
                'currency_id': self.currency_id.id,
                'contract_id': self.contract_id.id,
                'recurring_plan_id': self.recurring_plan_id.id,
            })
        subscription_lines = []
        outsanding_workorder_type = []
        outstanding_workorder = {
            'company_id': self.company_id.id,
            'partner_id': self.partner_id.id,
            'contract_id': self.contract_id.id,
            'quotation_id': self.quotation_id.id,
            'sale_order_id': self.id,
        }

        for line in self.order_line:
            if len(line.quotation_line_id) == 0:
                continue
            if len(line.quotation_promotion_line_id) == 1 and line.quotation_promotion_line_id.total_deposit_month > 0:
                continue
            operation = line.quotation_line_id.product_template_id.product_operation_id
            if len(operation) == 0:
                raise UserError(f"Product Operation isn't set for product: {line.quotation_line_id.product_template_id.name}")
            
            if line.product_uom_qty > line.quotation_line_id.uom_unordered_qty and strict:
                raise UserError(_("Sorry, Please check again your order, Quantity is over quota!"))

            
            product_operation = operation.get_next_operation('sale')
            if not product_operation:
                continue
            
            if product_operation.work_order_type not in outsanding_workorder_type:
                outsanding_workorder_type.append(product_operation.work_order_type)
            if product_operation.scope == 'product_unit':
                for i in range(int(line.product_uom_qty)):
                    subscription_lines.append(fields.Command.create({
                        'company_id': self.company_id.id,
                        'partner_id': self.partner_id.id,
                        'contract_id': self.contract_id.id,
                        'sale_order_id': self.id,
                        'sale_order_line_id': line.id,
                        'outstanding_work_order': product_operation.work_order_type,
                        'product_operation_line_id': product_operation.id,
                        'subscription_id': subscription.id,
                        'quotation_line_id': line.quotation_line_id.id,
                        'product_operation_scope': product_operation.scope
                    }))
            elif product_operation.scope == 'product_usage':
                subscription_lines.append(fields.Command.create({
                    'company_id': self.company_id.id,
                    'partner_id': self.partner_id.id,
                    'contract_id': self.contract_id.id,
                    'sale_order_id': self.id,
                    'sale_order_line_id': line.id,
                    'outstanding_work_order': product_operation.work_order_type,
                    'product_operation_line_id': product_operation.id,
                    'subscription_id': subscription.id,
                    'quotation_line_id': line.quotation_line_id.id,
                    'product_operation_scope': product_operation.scope
                }))
            else:
                raise UserError(_("Sorry, The product operation isn't support for this case"))
    
        subscription.subscription_lines = subscription_lines
        for type in outsanding_workorder_type:
            outstanding_workorder['outstanding_work_order'] = type
            self.env['outstanding.work.order'].create(outstanding_workorder)

        return subscription
    
    def action_view_subscription(self):
        return self.contract_id.action_view_subscription()

    def action_view_wo(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'work.order',
            'view_mode': 'tree,form',
            'name': _('Work Order'),
            'domain': [
                ('work_order_products.sale_order_id', '=', self.id)
            ]
        }

    def action_reject(self):
        self.state = 'rejected'
    
    def action_cancel(self):
        if len(self.contract_id) == 0:
            return super(SaleOrder, self).action_cancel()
        
        subscription_lines = self.env['subscription.line'].search_count([
            ('sale_order_id', '=', self.id),
            ('start_date', '!=', False),
        ])
        if subscription_lines > 0:
            raise UserError(_("Can't cancel sale order because some item already activated"))

        subscription_line_planned = self.env['subscription.line'].search_count([
            ('sale_order_id', '=', self.id),
            ('start_date', '=', False),
            ('entity_asset_id', '!=', False),
        ])

        if subscription_line_planned > 0:
            raise UserError(_("Can't cancel sale order because some item already planned"))

        all_subscription_lines = self.env['subscription.line'].search([
            ('sale_order_id', '=', self.id)
        ])

        planned_wo = self.env['work.order.line'].search_count([
            ('subscription_line_ids', 'in', all_subscription_lines.ids)
        ])

        if planned_wo > 0:
            raise UserError(_("Can't cancel sale order because some item already planned"))
        
        deleted_subscription_lines = self.env['subscription.line'].search([
            ('sale_order_id', '=', self.id),
            ('start_date', '=', False),
        ])
        deleted_subscription_lines.unlink()

        deleted_subscription_line_planned = self.env['subscription.line'].search([
            ('sale_order_id', '=', self.id),
            ('start_date', '=', False),
            ('entity_asset_id', '=', False),
        ])
        deleted_subscription_line_planned.unlink()

        deleted_outstandings = self.env['outstanding.work.order'].search([
            ('sale_order_id', '=', self.id)
        ])
        deleted_outstandings.unlink()

        return super(SaleOrder, self).action_cancel()
    
    def action_create_work_order(self):
        outstanding = self.env['outstanding.work.order'].search([
            ('sale_order_id', '=', self.id)
        ], limit=1)
        if len(outstanding) == 0:
            raise UserError("There is no outstanding work order")
        return outstanding.action_create_wo()
    
    def _compute_outstanding_work_order_count(self):
        outstanding = self.env['outstanding.work.order'].search([
            ('sale_order_id', '=', self.id)
        ])
        self.outstanding_work_order_count = len(outstanding)
    def _compute_work_order_count(self):
        wo = self.env['work.order'].sudo().search([
            ('work_order_products.sale_order_id', '=', self.id)
        ])
        self.work_order_count = len(wo)
        
    def _compute_subscription_count(self):
        subscription_lines = self.env['subscription.line'].search([
            ('sale_order_id', '=', self.id)
        ])
        total_subscriptions = []
        for line in subscription_lines:
            if line.subscription_id.id in total_subscriptions:
                continue
            total_subscriptions.append(line.subscription_id.id)
        self.subscription_count = len(total_subscriptions)

    def create_invoice_sale_order(self):
        invoice = self._create_invoices(final=False, grouped=False)

        #set default payment term invoice from SO
        if self.payment_term_id:
            invoice.write({'invoice_payment_term_id': self.payment_term_id})

        return self.action_view_invoice(invoices=invoice)

    def action_download_proforma(self):
        return self.env.ref('sale.action_report_pro_forma_invoice').report_action(self)

    def set_link(self):
        base_url = self.env["ir.config_parameter"].sudo().get_param("web_payment_url") or self.env["ir.config_parameter"].sudo().get_param("web.base.url")
        return f"{base_url}{self.get_portal_url()}"

    def set_qrcode(self, link):
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
        qr.add_data(link)
        qr.make(fit=True)
        img = qr.make_image()
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        qrcode_img = base64.b64encode(buffer.getvalue())

        return qrcode_img.decode("utf-8")

