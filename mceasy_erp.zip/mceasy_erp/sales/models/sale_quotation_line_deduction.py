from odoo import models, fields


class SaleQuotationLineDeduction(models.Model):
    _name = 'sale.quotation.line.deduction'
    _description = 'Calculated Sale Quotation Line Deduction Account'

    quotation_line_id = fields.Many2one(
        comodel_name='sale.quotation.line',
        string="Quotation Line",
        required=True, ondelete='cascade', index=True
    )
    quotation_promotion_line_id = fields.Many2one(
        comodel_name='sale.quotation.promotion.line',
        ondelete='cascade', index=True
    )
    quotation_id = fields.Many2one(
        comodel_name='sale.quotation',
        related='quotation_line_id.quotation_id'
    )
    account_id = fields.Many2one('account.account', ondelete='cascade', required=True)
    amount = fields.Float(digits=(16, 2), string="Value", required=True)
    # used for specific installation
    # valid_registration_from =fields.Date(
    #     default=None
    # )
    # TODO: use it as configuration
    valid_activation_until =fields.Date(
        default='2023-12-31'
    )