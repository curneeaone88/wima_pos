from odoo import models, fields


class SalePromotionProductDeductionAccount(models.Model):
    _name = 'sale.promotion.product.deduction.account'
    _description = 'Specific Product Deduction'

    sale_promotion_product_id = fields.Many2one(
        comodel_name='sale.promotion.product',
        ondelete='cascade'
    )
    priority = fields.Integer(string="Priority", required=True)
    account_id = fields.Many2one('account.account', string='Chart of Account', index=True, ondelete='cascade', required=True)
    calculation_type = fields.Selection([('fix', 'Fix'), ('percentage', 'Percentage')], string='Calculation Type', required=True)
    calculation_value = fields.Float(digits=(16, 2), string="Value", required=True)