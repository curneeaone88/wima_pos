from odoo import models, fields


class CRMCategory(models.Model):
    _name = 'crm.category'
    _description = 'CRM Category'

    name = fields.Char(string='Category')