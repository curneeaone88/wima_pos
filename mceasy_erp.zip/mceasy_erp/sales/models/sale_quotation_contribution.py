from odoo import models, fields, api


class SaleQuotationContribution(models.Model):
    _name = 'sale.quotation.contribution'
    _description = 'Sales Contribution'

    sale_quotation_id = fields.Many2one(
        comodel_name='sale.quotation',
        required=True,
        ondelete='cascade'
    )
    sales = fields.Many2one(
        comodel_name='res.users',
        required=True
    )
    sales_team = fields.Many2one(
        comodel_name='crm.team',
        required=True
    )
    percentage = fields.Float()
    start_date = fields.Date(
        compute='_compute_start_date',
        precompute=True,
        required=True,
        store=True
    )
    end_date = fields.Date()

    def _compute_display_name(self):
        for rec in self:
            rec.display_name = f'{rec.sale_quotation_id.name} - {rec.sales.name}'

    @api.onchange('sales')
    def onchange_sales(self):
        for rec in self:
            rec.sales_team = rec.sales.sale_team_id

    @api.depends('sale_quotation_id')
    def _compute_start_date(self):
        for rec in self:
            rec.start_date = False
            if rec.sale_quotation_id.quotation_date:
                rec.start_date = rec.sale_quotation_id.quotation_date