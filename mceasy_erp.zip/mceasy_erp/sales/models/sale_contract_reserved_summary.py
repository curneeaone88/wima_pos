from odoo import models, tools, fields

class SaleContractReservedSummary(models.Model):
    _name = 'sale.contract.reserved.summary'
    _description = 'Booking Product Summary'
    _auto = False

    contract_id = fields.Many2one(
        comodel_name='sale.contract',
        string="Contract",
        readonly=True
    )
    product_id = fields.Many2one(
        comodel_name="product.template",
        string="Product",
        readonly=True
    )
    product_uom_category_id = fields.Many2one(comodel_name='uom.category', readonly=True)
    product_uom = fields.Many2one(
        comodel_name='uom.uom',
        string="Unit of Measure",
        readonly=True, 
    )
    uom_qty = fields.Float(
        string="Quantity",
        readonly=True
    )

    def init(self):
        tools.drop_view_if_exists(self.env.cr, 'sale_contract_reserved_summary')
        self.env.cr.execute("""
        CREATE VIEW sale_contract_reserved_summary AS (
            select 
                min(id) id,
                contract_id,
                product_id, 
                product_uom_category_id,
                product_uom,
                sum(uom_qty) uom_qty
            from (
                select 
                    scrp.id,
                    coalesce(scrp.component_product_id, sql2.product_id) product_id,
                    sq.contract_id,
                    scrp.product_uom_category_id,
                    scrp.product_uom,
                    scrp.uom_qty 
                from sale_contract_reserved_product scrp 
                left join sale_quotation_line sql2 on sql2.id = scrp.quotation_line_id 
                left join sale_quotation sq on sq.id = sql2.quotation_id 
            ) sale_contract_summary_booking
            group by contract_id, product_id, product_uom_category_id, product_uom having sum(uom_qty) > 0
        )
        """)