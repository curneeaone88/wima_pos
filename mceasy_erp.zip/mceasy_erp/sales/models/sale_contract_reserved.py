from odoo import models, fields, api


class SaleContractReservedProduct(models.Model):
    _name = 'sale.contract.reserved.product'
    _description = 'Reserved Product'

    quotation_id = fields.Many2one(
        related="quotation_line_id.quotation_id"
    )
    quotation_line_id = fields.Many2one(
        'sale.quotation.line',
        string='Quotation Line',
        required=True,
        ondelete='restrict'
    )
    contract_name = fields.Char(
        related="quotation_id.contract_name"
    )
    contract_id = fields.Many2one(
        related='quotation_line_id.contract_id'
    )
    name = fields.Char(
        string="Product",
        required=True,
        readonly=True
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True, index=True,
        readonly=True
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        readonly=True
    )
    component_product_id = fields.Many2one(
        comodel_name='product.template',
        string="Component",
        readonly=True
    )
    component_line_id = fields.Many2one(
        comodel_name='product.package.component',
        string="Component Line",
        readonly=True
    )
    component_id = fields.Many2one(
        related='component_line_id.component_id'
    )
    product_uom_category_id = fields.Many2one(
        comodel_name='uom.category',
        readonly=True,
        required=True
    )
    uom_qty = fields.Float(
        string="Quantity",
        digits='Product Unit of Measure', default=1.0,
        store=True, readonly=True, required=True
    )
    product_uom = fields.Many2one(
        comodel_name='uom.uom',
        string="Unit of Measure",
        store=True, readonly=True, 
        ondelete='restrict',
    )
    currency_id = fields.Many2one(
        related="quotation_line_id.currency_id"
    )
    standart_price = fields.Monetary(
        compute="_compute_standart_price"
    )
    discounted_price = fields.Monetary(
        compute="_compute_discounted_price"
    )
    is_alternative = fields.Boolean(
        string="Is Alternative?",
        default=False
    )

    @api.depends('quotation_id')
    def _compute_standart_price(self):
        for rec in self:
            rec.standart_price = rec.quotation_line_id.standart_price_on()

    @api.depends('quotation_id')
    def _compute_discounted_price(self):
        for rec in self:
            rec.discounted_price = rec.quotation_line_id.discounted_price_on()
