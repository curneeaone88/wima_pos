from odoo import models, fields, api

class SaleContractPeriod(models.Model):
    _name = 'sale.contract.period'
    _description = 'Contract Period'

    name = fields.Char(
        string="Contract Period",
        required=True
    )

    value = fields.Integer(
        string="Value",
        default=1
    )

    unit = fields.Selection(
        [("month", "Month"), ('year', 'Year')],
        string="Unit", required=True, default='year'
    )

    length_in_month = fields.Integer(
        string="Length in Month",
        compute='_compute_length'
    )

    @api.depends('value', 'unit')
    def _compute_length(self):
        for record in self:
            record.length_in_month = record.value * (12 if record.unit == 'year' else 1)