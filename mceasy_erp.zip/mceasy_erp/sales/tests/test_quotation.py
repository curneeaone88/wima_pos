from odoo.tests import TransactionCase
from odoo.tests import tagged

@tagged('quotation')
class TestQuotation(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.properties = cls.env['sale.quotation'].create({
            'partner_id': 1,
            'title': 'Test Quotation'
        })
    
    def test_create_quotation(self):
        self.assertEqual(True, True)
