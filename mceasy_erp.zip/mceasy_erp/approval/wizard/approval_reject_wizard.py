from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging
_logger = logging.getLogger(__name__)

class ApprovalRejectWizard(models.TransientModel):
    _name = 'approval.reject.wizard'
    _description = 'Approval Reject Wizard'

    approval_id = fields.Many2one(string='Approval', comodel_name='approval')
    approval_line_id = fields.Many2one(string='Approval Line Id', comodel_name='approval.line')
    res_model = fields.Char(string='Model')
    res_id = fields.Many2oneReference('Related Document ID', model_field='res_model')
    note = fields.Html(string='Note')

    def action_do_reject(self):
        self.ensure_one()
        res_data = self.env[self.res_model].browse(self.res_id)
        if len(res_data) == 0:
            return
        
        if self.approval_line_id.action_reject_function and hasattr(self.env[self.res_model].browse(self.res_id), self.approval_line_id.action_reject_function):
            reject_function = getattr(self.env[self.res_model].browse(self.res_id), self.approval_line_id.action_reject_function)
            reject_function()
        else:
            raise UserError("Internal Error, Action reject is not set, please contact ERP Team !")
        res_data._log_approval_activity('rejected', self.approval_id, self.approval_line_id, self.res_id, self.res_model, self.note)
        for approver in res_data.approval_approvers:
            if approver.approval_response is False or approver.approval_response == 'requesting':
                approver.approval_response = 'none'