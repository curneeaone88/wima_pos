from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import ast
import logging
_logger = logging.getLogger(__name__)

class Approval(models.Model):
    _name = 'approval'
    _description = 'Approval'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _sql_constraints = [
        ('approval_unique', 'unique(company_id, ir_model_id)', 'The approval for this model already exist!'),
    ]
    
    name = fields.Char(string='Name')
    ir_model_id = fields.Many2one(string='Model',comodel_name='ir.model',tracking=True, store=True)
    domain_models = fields.Many2many(string='Domain Model',comodel_name='ir.model', compute='_compute_domain_models',)
    model_name = fields.Char(string='Model', related="ir_model_id.model")
    states = fields.One2many(string='States',comodel_name='approval.state',inverse_name='approval_id',tracking=True, store=True)
    approval_lines = fields.One2many(string='Approval Lines',comodel_name='approval.line',inverse_name='approval_id',tracking=True)
    ir_ui_view_id = fields.Many2one(string='Ir UI View', comodel_name='ir.ui.view',tracking=True,)
    view_id = fields.Many2one(string='Inherit View Id', comodel_name='ir.ui.view',tracking=True)
    sum_data_approve = fields.Integer(string='Need To Approve', compute="_compute_sum_data_approve")
    allowed_company = fields.One2many(comodel_name='res.company',compute='_compute_multi_company')
    company_id = fields.Many2one(comodel_name='res.company',index=True,store=True,precompute=True,readonly=False,compute='_compute_company_id')
    is_company_visible = fields.Boolean(compute='_compute_multi_company')
    user_id = fields.Many2one('res.users',string='Sales',default=lambda s: s.env.user.id)

    @api.depends('ir_model_id')
    def _compute_domain_models(self):
        for rec in self:
            models = self.env['ir.model.fields'].search([('name', '=', 'is_need_approval')]).mapped('model_id')
            domain_models = []
            for model in models:
                if len(model.view_ids) == 0:
                    continue
                domain_models.append(model.id)
            rec.domain_models = domain_models


    @api.depends('allowed_company')
    def _compute_company_id(self):
        for rec in self:
            if len(rec.company_id) == 1:
                continue
            rec.company_id = rec.allowed_company[0] if rec.allowed_company else False

    @api.depends('user_id')
    def _compute_multi_company(self):
        for rec in self:
            rec.allowed_company = self.env.user.company_ids.filtered(lambda x: x.id in self._context.get('allowed_company_ids')) if self._context.get('allowed_company_ids') else []
            rec.is_company_visible = len(rec.allowed_company) > 1

    @api.onchange('ir_model_id')
    def _onchange_ir_model_id(self):
        self.ensure_one()
        state_field = self.env['ir.model.fields'].search([('model', '=', self.ir_model_id.model), ('name', '=', 'state')], limit=1)
        state_selections = self.env['ir.model.fields.selection'].search([('field_id', '=', state_field.id),], order="sequence ASC")

        self.states = [fields.Command.clear()]
        for state in state_selections: self.states = [fields.Command.create({'approval_id': self.id, 'key': state.value, 'value': state.name})]
    
    def create(self, vals):
        values = []
        if isinstance(vals, dict):
            values = [vals]
        else:
            values = vals

        for val in values:
            is_exist = self.search_count([('ir_model_id', '=', val['ir_model_id']), ('company_id', '=', val['company_id'])]) > 0
            if is_exist:
                raise UserError("The approval for this model already exist!")

        res = super(Approval, self).create(vals)

        if len(res.view_id) == 0:
            approval_id = self.search([('ir_model_id', '=', res.ir_model_id.id), ('view_id', '!=', False)], limit=1)
            if approval_id:
                inherited_view = approval_id.view_id
            else:
                inherited_view = self.action_inherit_view_form(res.ir_model_id.id, res.ir_ui_view_id.id)
            res.view_id = inherited_view
        
        if len(res.states) == 0:
            state_field = self.env['ir.model.fields'].search([('model', '=', res.ir_model_id.model), ('name', '=', 'state')], limit=1)
            if len(state_field) == 0:
                return res
            
            state_selections = self.env['ir.model.fields.selection'].search([('field_id', '=', state_field.id),], order="sequence ASC")
            for state in state_selections: res.states = [fields.Command.create({'approval_id': res.id, 'key': state.value, 'value': state.name})]

        return res
    

    def action_refresh_view(self):
        approval_ids = self.env['approval'].search([('ir_model_id', '=', self.ir_model_id.id), ('view_id', '!=', False)])
        if len(approval_ids) > 0:
            approval_ids[0].view_id.unlink()
        
        approval_view = self.action_inherit_view_form(self.ir_model_id.id, self.ir_ui_view_id.id)
        for approval_id in approval_ids:
            approval_id.view_id = approval_view
        
        self.view_id = approval_view

    def action_inherit_view_form(self, model_id, view_id):
        ir_ui_view = self.env['ir.ui.view']
        ir_model = self.env['ir.model'].sudo().browse(model_id)

        # Create a new view inherit from the base view
        new_view = {
            'name': f'approval.managament.inherit.{ir_model.model.lower()}',
            'type': 'form',
            'priority': '40',
            'model': ir_model.model,
            'inherit_id': view_id,
            'arch': '''
                <data>
                    <xpath expr='//form/header/button[1]' position="before">
                        <field name="is_the_approver" invisible="True"/>
                        <field name="is_need_approval" invisible="True"/>
                        <field name="approval_id" invisible="True"/>
                        <field name="approval_line_id" invisible="True"/>
                        <button name="action_do_approve" string="Approve" type="object" invisible="is_the_approver == False" class="btn-primary"/>
                        <button name="action_do_reject" string="Reject" type="object" invisible="is_the_approver == False"/>
                    </xpath>
                    <xpath expr='//notebook' position="inside">
                        <page string="Approval Activities" name="approval_activities_page" invisible="not approval_activities">
                            <field name="approval_activities">
                                <tree editable="bottom" create="0" delete="0" readonly="1">
                                    <field name="type" readonly="1"/>
                                    <field name="res_user_id" readonly="1"/>
                                    <field name="activity_datetime" readonly="1"/>
                                    <field name="note" widget="html" readonly="1"/>
                                </tree>
                            </field>
                        </page>
                        <page string="Approval" name="approval_approvers_page" invisible="not approval_approvers">
                            <field name="approval_type" invisible="1"/>
                            <field name="approval_approvers">
                                <tree editable="bottom" create="0" delete="0" readonly="1" default_order="approval_line_id,approval_sequence">
                                    <field name="approval_line_id" readonly="1"/>
                                    <field name="res_user_id" readonly="1"/>
                                    <field name="res_user_alternative_id" readonly="1" column_invisible="parent.approval_type != 'multi_level'" widget="many2many_tags"/>
                                    <field name="activity_datetime" readonly="1"/>
                                    <field name="approval_response" readonly="1"/>
                                </tree>
                            </field>
                        </page>
                    </xpath>
                </data>
            '''
        }

        inherited_view = ir_ui_view.create(new_view)
        return inherited_view

    def _compute_records_need_to_approve(self):
        for rec in self:
            data = []
            approvers = self.env['approval.approver'].search([
                '&',
                '&',
                ('res_model', '=', rec.model_name),
                ('approval_response', '=', 'requesting'),
                '|',
                ('res_user_id', '=', self.env.user.id),
                ('res_user_alternative_id', 'in', [self.env.user.id]),
            ])
            for id in approvers.mapped('res_id'): data.append(id)
            return data

    def _compute_sum_data_approve(self):
        for rec in self:
            rec.sum_data_approve = len(rec._compute_records_need_to_approve())

    def action_list_to_approve(self):
        for rec in self:
            records = rec._compute_records_need_to_approve()
            return {
                'type': 'ir.actions.act_window',
                'name': self.name,
                'res_model': self.ir_model_id.model,
                'view_mode': 'list,form',
                'domain': [('id', 'in', records)],
            }
        
    def unlink(self):
        for rec in self:
            if rec.view_id: rec.view_id.unlink()
        return super(Approval, self).unlink()