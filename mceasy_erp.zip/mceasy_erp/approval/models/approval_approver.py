from odoo import models, fields, api, _
import logging
_logger = logging.getLogger(__name__)

class ApprovalApprover(models.Model):
    _name = 'approval.approver'
    _description = 'Approval Approver'

    approval_line_approver_id = fields.Many2one(string='Approval Line Approver', comodel_name='approval.line.approver')
    approval_line_id = fields.Many2one(related='approval_line_approver_id.approval_line_id', store=True)
    approval_type = fields.Selection(related='approval_line_id.approval_type')
    res_model = fields.Char(string='Model', store=True)
    res_id = fields.Many2oneReference('Related Document ID', model_field='res_model', store=True)
    res_user_id = fields.Many2one(string='User', comodel_name='res.users')
    res_user_alternative_id = fields.Many2many(string='User Alternative', comodel_name='res.users')
    activity_datetime = fields.Datetime(string='Activity Date')
    approval_response = fields.Selection(string='Response', selection=[('requesting', 'Requesting'), ('rejected', 'Rejected'), ('approved', 'Approved'), ('none', 'None')])
    approval_state = fields.Many2one(string='Approval State', comodel_name='approval.state', related='approval_line_approver_id.approval_state', store=True)
    approval_sequence = fields.Integer(string='Approval Sequence')