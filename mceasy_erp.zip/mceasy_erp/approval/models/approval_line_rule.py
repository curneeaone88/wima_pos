from odoo import models, fields, api, _
import logging
_logger = logging.getLogger(__name__)

class ApprovalLineRule(models.Model):
    _name = 'approval.line.rule'
    _description = 'Approval Line Rule'

    approval_line_approver_id = fields.Many2one(string='Approval Line', comodel_name='approval.line.approver')
    name = fields.Char(string='Name')
    model_name = fields.Char(string='Model Name', related='approval_line_approver_id.model_name')
    ir_model_id = fields.Many2one(string='Model Name', related='approval_line_approver_id.ir_model_id', comodel_name='ir.model')
    domain_list = fields.Char(string='Domain List')
    company_id = fields.Many2one(comodel_name='res.company',index=True,store=True,readonly=False,related='approval_line_approver_id.company_id')