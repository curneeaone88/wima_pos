from odoo import models, fields, api, _
import logging
_logger = logging.getLogger(__name__)

class ApprovalActivity(models.Model):
    _name = 'approval.activity'
    _description = 'Approval Activity'
    _order = 'id desc'

    approval_line_id = fields.Many2one(string='Approval Line', comodel_name='approval.line', store=True)
    approver_id = fields.Many2one(comodel_name='approval.approver')
    res_model = fields.Char(string='Model', store=True)
    res_id = fields.Many2oneReference('Related Document ID', model_field='res_model', store=True)
    type = fields.Selection(string='Type', selection=[('approved', 'Approved'), ('rejected', 'Rejected')])
    res_user_id = fields.Many2one(string='User', comodel_name='res.users')
    activity_datetime = fields.Datetime(string='Activity Date')
    note = fields.Html(string='Note')