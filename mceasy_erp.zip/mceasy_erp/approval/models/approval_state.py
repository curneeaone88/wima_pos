from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import logging
_logger = logging.getLogger(__name__)

class ApprovalState(models.Model):
    _name = 'approval.state'
    _description = 'Approval State'

    name = fields.Char(string='Name', compute="_compute_name", default='New')
    approval_id = fields.Many2one(string='Approval', comodel_name='approval', ondelete='cascade')
    key = fields.Char(string='Key')
    value = fields.Char(string='value')

    def _compute_name(self):
       for rec in self:
           rec.name = rec.value