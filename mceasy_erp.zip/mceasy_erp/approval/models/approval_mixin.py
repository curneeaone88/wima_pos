from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime
import ast
import logging
_logger = logging.getLogger(__name__)

class ApprovalMixin(models.AbstractModel):
    _name = 'approval.mixin'
    _description = 'Approval Mixin'

    is_the_approver = fields.Boolean(string='Is The Approver', compute='_compute_is_the_approver', default=False)
    approver_id = fields.Many2one('approval.approver', compute='_compute_is_the_approver')
    approval_id = fields.Many2one(string='Approval Id', comodel_name='approval', compute="_get_approval_id", default=False)
    approval_line_id = fields.Many2one(string='Approval Line Id', comodel_name='approval.line', compute="_compute_approval_line_id", default=False)
    approval_type = fields.Char(string='Approval Type', compute="_compute_approval_line_id")
    approval_activities = fields.One2many(string='Approval Activity', comodel_name='approval.activity', inverse_name='res_id')
    approval_approvers = fields.One2many(string='Approval', comodel_name='approval.approver', inverse_name='res_id')
    is_need_approval = fields.Boolean(compute='_compute_is_need_approval')

    def get_configuration(self, approval_state=False):
        self.ensure_one()
        approval_id = self._compute_approval_id()
        approval_configurations = approval_id.approval_lines
        if approval_state:
            approval_configurations = approval_configurations.filtered(lambda x:x.approval_state.key == approval_state)

        approvers = []
        approval_sequence = 1
        map_approver_id = []
        check_approval_group = []
        company_id = self._get_requestor_company_id()
        for approval_line in approval_configurations:
            for approval_line_approver in approval_line.approval_line_approvers.sorted('sequence'):
                if company_id not in approval_line_approver.approver_id.company_ids.ids: continue
                validation_check = False
                for approval_rule in approval_line_approver.approval_rules:
                    if not approval_rule.domain_list: continue
                    domain_list = ast.literal_eval(approval_rule.domain_list)
                    records = self.sudo().search(domain_list).ids
                    validation_check = True if self.id in records else False
                    if not validation_check: break

                if validation_check and approval_line_approver.approver_id.id not in map_approver_id: 
                    approval_response = 'requesting'
                    if approval_line.approval_type == 'multi_level' and approval_sequence != 1:
                        approval_response = False
                    approvers.append(fields.Command.create({
                        'approval_line_approver_id': approval_line_approver.id,
                        'res_user_id': approval_line_approver.approver_id.id,
                        'res_user_alternative_id': approval_line_approver.approver_alternative_id.ids if approval_line.approval_type == 'multi_level' else False,
                        'res_id': self.id,
                        'res_model': self._name,
                        'approval_response': approval_response,
                        'approval_sequence': approval_sequence
                    }))
                    approval_sequence += 1
                    if approval_line.id not in check_approval_group:
                        check_approval_group.append(approval_line.id)

                    map_approver_id.append(approval_line_approver.approver_id.id)
        return len(check_approval_group) == 1, approvers

    def action_request_approval(self):
        self.ensure_one()
        approval_state = self.get_approval_state()
        check_approval_group, approvers = self.get_configuration(approval_state)
        self.clean_approvers()

        if not check_approval_group:
            raise UserError("Integrity error, multiple or empty approval type on approval request !")
        self.approval_approvers = approvers
        self.state = self.get_approval_state()
        return True
    
    def clean_approvers(self):
        if len(self.approval_id.approval_lines) == 1 or self.get_rejection_state() == self.state:
            self.approval_approvers = [fields.Command.clear()]
        
        impacted_approvers = self.approval_approvers.filtered(lambda x: x.approval_line_id.id == self.approval_line_id.id)
        impacted_approvers.unlink()
        

    def _compute_approval_id(self):
        model_id = self.env['ir.model'].sudo().search([('model', '=', self._name)],limit=1)
        company_id = self._get_requestor_company_id()
        approval_id = self.env['approval'].search([('ir_model_id', '=', model_id.id), ('company_id', '=', company_id)],limit=1)
        return approval_id
    
    def _get_requestor_company_id(self):
        company_id = self.company_id.id
        if company_id is False:
            company_id = self.env.user.company_id.id
        return company_id
    
    def _compute_approval_line_id(self):
        for rec in self:
            approval_line = rec.approval_approvers.mapped('approval_line_id')
            appr_line = approval_line.filtered(lambda x: x.approval_state.key == rec.get_approval_state())
            if len(appr_line) > 0:
                rec.approval_line_id = appr_line[0].id
                rec.approval_type = appr_line[0].approval_type
            else:
                rec.approval_line_id = False
                rec.approval_type = False
    
    def _compute_is_need_approval(self):
        for rec in self:
            approval_state = rec.get_approval_state()
            _, approvers = rec.get_configuration(approval_state)
            rec.is_need_approval = len(approvers) > 0
    
    def get_approval_state(self):
        return False
    
    def get_rejection_state(self):
        return False

    def _get_approval_id(self):
        approval_id = self._compute_approval_id()
        for rec in self: rec.approval_id = approval_id

    def _compute_is_the_approver(self):
        for rec in self: 
            rec.approver_id = False
            rec.is_the_approver = False
            approvers = rec.approval_approvers.mapped('res_user_id').ids
            approvers += rec.approval_approvers.mapped('res_user_alternative_id').ids
            if rec.approval_approvers and self.env.user.id in approvers:
                approval_approver = rec.approval_approvers.filtered(
                    lambda x: (
                        x.res_user_id.id == self.env.user.id or self.env.user.id in x.res_user_alternative_id.ids
                    ) and x.approval_state.key == rec.state
                    and x.approval_response == 'requesting'
                )
                states = rec.approval_id.approval_lines.mapped('approval_state')
                configured_states = []
                for s in states:
                    configured_states.append(s.key)
                if rec.approval_type is False and rec.state in configured_states:
                    raise UserError('Integrity error, multiple approval type for the approvers')
                
                rec.is_the_approver = approval_approver.approval_response == 'requesting'
                rec.approver_id = approval_approver

    def _log_approval_activity(self, response, approval_id, approval_line_id, res_id, res_model, note):
        self.ensure_one()
        self.approval_activities = [fields.Command.create({
            'type': response,
            'approver_id': self.approver_id.id,
            'approval_line_id': approval_line_id.id,
            'res_model': res_model,
            'res_id': res_id,
            'note': note,
            'res_user_id': self.env.user.id,
            'activity_datetime': datetime.now()
        })]
        self.approver_id.activity_datetime = datetime.now()
        self.approver_id.approval_response = response

    def check_state_approval_approved(self):
        self.ensure_one()

        is_proceed = False
        if self.approval_type is False:
            raise UserWarning('Integrity error, multiple approval type')

        approval_responses = self.approval_approvers.mapped('approval_response')
        if self.approval_type == 'multi_level': is_proceed = True if not any(approval_response == False or approval_response == 'rejected' for approval_response in approval_responses) else False
        elif self.approval_type == 'any': is_proceed = True if 'approved' in approval_responses else False
        else: raise UserWarning('Invaild approval type')

        return is_proceed

    def action_do_approve(self):
        if self.approval_id and self.approval_line_id:
            note = f'Approved by {self.env.user.name} at {datetime.now()}'
            self._log_approval_activity('approved', self.approval_id, self.approval_line_id, self.id, self._name, note)

            is_proceed = self.check_state_approval_approved()
            if self.approval_line_id.approval_type == 'any':
                for approver in self.approval_approvers:
                    if approver.approval_response is False or approver.approval_response == 'requesting':
                        approver.approval_response = 'none'
            else:
                for approver in self.approval_approvers:
                    if approver.approval_response is False:
                        approver.approval_response = 'requesting'
                        break


            if self.approval_line_id.action_approve_function and hasattr(self, self.approval_line_id.action_approve_function):
                if is_proceed:
                    action = getattr(self, self.approval_line_id.action_approve_function)
                    action()
            else:
                raise UserError("Internal Error, Action approve is not set, please contact ERP Team !")



    def action_do_reject(self):
        if self.approval_id and self.approval_line_id:

            return {
                'name': _('Reject Reason'),
                'type': 'ir.actions.act_window',
                'res_model': 'approval.reject.wizard',
                'view_mode': 'form',
                'view_type': 'form',
                'target': 'new',
                'context': {'default_approval_id': self.approval_id.id,
                            'default_approval_line_id': self.approval_line_id.id,
                            'default_res_model': self._name,
                            'default_res_id': self.id,},
            }