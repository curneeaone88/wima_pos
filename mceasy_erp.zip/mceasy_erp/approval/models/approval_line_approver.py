from odoo import models, fields, api, _
import logging
from odoo.osv import expression
_logger = logging.getLogger(__name__)

class ApprovalLineApprover(models.Model):
    _name = 'approval.line.approver'
    _description = 'Approval Line Approver'

    approval_line_id = fields.Many2one(string='Approval Line', comodel_name='approval.line')
    name = fields.Char(string='Name')
    sequence = fields.Integer(string='Sequence')
    approver_id = fields.Many2one(string='Approver', comodel_name='res.users')
    approver_alternative_id = fields.Many2many(string='Approver Alternative', comodel_name='res.users')
    approval_type = fields.Selection(related='approval_line_id.approval_type')
    approval_rules = fields.One2many(string='Approval Rule', comodel_name='approval.line.rule', inverse_name='approval_line_approver_id')
    approval_rules_string = fields.Char(string='Rules', compute='_compute_approval_rules_string')
    model_name = fields.Char(string='Model Name', related='approval_line_id.model_name')
    ir_model_id = fields.Many2one(string='Model Name', related='approval_line_id.ir_model_id', comodel_name='ir.model')
    approval_state = fields.Many2one(string='Approval State', comodel_name='approval.state', related='approval_line_id.approval_state')
    company_id = fields.Many2one(comodel_name='res.company',index=True,store=True,readonly=False,related='approval_line_id.company_id')

    def _compute_approval_rules_string(self):
        for rec in self:
            rule_string = []
            for approval_rule in rec.approval_rules:
                rule_string = expression.AND([eval(approval_rule.domain_list), rule_string])
            rec.approval_rules_string = f'{rule_string}'

    def action_open_approval_rules(self):
        self.ensure_one()
        return {
            'name': _('Rules'),
            'type': 'ir.actions.act_window',
            'res_model': 'approval.line.approver',
            'res_id': self.id,
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
        }