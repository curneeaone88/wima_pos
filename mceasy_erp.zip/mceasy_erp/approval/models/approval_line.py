from odoo import models, fields, api, _
import logging
_logger = logging.getLogger(__name__)

APPROVAL_TYPES = [
    ('any', 'Anyone Can Approve'),
    ('multi_level', 'Multi Level Approval'),
]

class ApprovalLine(models.Model):
    _name = 'approval.line'
    _description = 'Approval Line'

    name = fields.Char(string='Name')
    approval_id = fields.Many2one(string='Approval', comodel_name='approval', store=True)
    approval_state = fields.Many2one(string='Approval State', comodel_name='approval.state', required=True)
    approval_type = fields.Selection(string='Approval Type', selection=APPROVAL_TYPES, required=True)
    action_approve_function = fields.Char(string='Action Approve Function', required=True)
    action_reject_function = fields.Char(string='Action Reject Function', required=True)
    model_name = fields.Char(string='Model Name', related='approval_id.model_name')
    ir_model_id = fields.Many2one(string='Model Name', related='approval_id.ir_model_id', comodel_name='ir.model')
    approval_line_approvers = fields.One2many(string='Approval Line Approver', comodel_name='approval.line.approver', inverse_name='approval_line_id')
    company_id = fields.Many2one(comodel_name='res.company',index=True,store=True,readonly=False,related='approval_id.company_id')

    def action_open_approval_line(self):
        self.ensure_one()
        return {
                'name': _('Approval Line'),
                'type': 'ir.actions.act_window',
                'res_model': 'approval.line',
                'res_id': self.id,
                'view_mode': 'form',
                'view_type': 'form',
                'target': 'current',
            }