from odoo import fields, models, api


class AfterSaleOrderLine(models.Model):
    _name = 'after.sale.order.line'
    _description = 'After Sales Order Line'

    after_sale_order_id = fields.Many2one(
        comodel_name='after.sale.order',
        required=True,
        ondelete="cascade"
    )
    company_id = fields.Many2one(
        related='after_sale_order_id.company_id',
        store=True, index=True, precompute=True
    )
    partner_id = fields.Many2one(
        related='after_sale_order_id.partner_id',
        store=True, index=True, precompute=True
    )
    partner_domain_id = fields.Many2one(
        comodel_name='partner.domain',
        required=True
    )
    entity_asset_id = fields.Many2one(
        comodel_name='entity.asset',
        required=True
    )
    subscription_line_ids = fields.Many2many(
        comodel_name='subscription.line',
        relation='after_sale_order_line_2_subscription_line_rel',
        string='Product',
        required=True
    )
    new_entity_asset_id = fields.Many2one(
        comodel_name='entity.asset',
        help='Used for asset migration'
    )
    note = fields.Text(
        string='Additional Note'
    )

    @api.onchange('partner_domain_id')
    def _onchange_partner_domain_id(self):
        self.entity_asset_id = False

    @api.onchange('entity_asset_id')
    def _onchange_entity_asset_id(self):
        self.new_entity_asset_id = False
        subscription_line_ids = self.env['subscription.line'].browse()
        for l in self:
            for sub_line in l.entity_asset_id.subscriptions:
                if sub_line.id not in subscription_line_ids.ids:
                    if sub_line.product_type != 'package':
                        continue
                    if sub_line.product_operation_scope != 'product_unit':
                        continue
                    product_template_operation = sub_line.current_product_id.product_operation_id
                    if hasattr(
                        product_template_operation, f'{l.after_sale_order_id.type}_operations'
                    ) and len(getattr(product_template_operation, f'{l.after_sale_order_id.type}_operations')) == 0:
                        continue
                    if sub_line.end_date is not False:
                        continue

                    subscription_line_ids += sub_line
        self.subscription_line_ids = subscription_line_ids
