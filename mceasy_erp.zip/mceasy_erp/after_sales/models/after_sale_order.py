from odoo import models, fields, _, api
from odoo.exceptions import UserError


class AfterSaleOrder(models.Model):
    _name = 'after.sale.order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'After Sales Order'
    _order = 'id desc'

    name = fields.Char(
        string='Number',
        default=lambda self: _('New')
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True,
        index=True,
        store=True,
        precompute=True,
        readonly=False,
        compute='_compute_company_id')
    allowed_company = fields.One2many(
        comodel_name='res.company',
        compute='_compute_multi_company',
    )
    is_company_visible = fields.Boolean(
        compute='_compute_multi_company',
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string="Customer",
        required=True, change_default=True, index=True,
        tracking=1,
        domain="[('company_id', 'in', (False, company_id))]"
    )
    contract_id = fields.Many2one(
        comodel_name='sale.contract',
        readonly=True,
        default=False,
    )
    user_id = fields.Many2one(
        'res.users',
        string='Sales',
        default=lambda s: s.env.user.id
    )
    type = fields.Selection(
        selection=[
            ('maintenance', 'Maintenance'),
            ('move', 'Pindah Unit'),
            ('churn', 'Berhenti Berlangganan'),
        ],
        required=True,
        default='maintenance'
    )
    request_date = fields.Datetime(
        string="Requested on",
        required=True, copy=False,
        default=fields.Datetime.now
    )
    scheduled_date = fields.Datetime(
        string="Scheduled on",
        required=True, copy=False,
        default=fields.Datetime.now
    )
    lines = fields.One2many(
        comodel_name='after.sale.order.line',
        inverse_name='after_sale_order_id',
        required=True
    )
    domain_entity_assets = fields.One2many(
        comodel_name='entity.asset',
        compute='_compute_domain_entity_assets'
    )
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('review', 'Review'),
            ('requested', 'Requested'),
            ('done', 'Done'),
            ('cancelled', 'Cancelled'),
        ],
        required=True,
        default='draft'
    )
    note = fields.Html(
        string='Note'
    )
    domain_subscription_ids = fields.One2many(
        comodel_name='subscription.line',
        compute='_compute_domain_subscription_ids'
    )

    @api.onchange('partner_id', 'company_id')
    def _onchange_partner_id(self):
        for rec in self:
            rec.contract_id = False
            contract = self.env['sale.contract'].search([
                ('company_id', '=', rec.company_id.id),
                ('partner_id', '=', rec.partner_id.id),
            ])
            if len(contract) == 1:
                rec.contract_id = contract

    @api.depends('lines')
    def _compute_domain_entity_assets(self):
        self.domain_entity_assets = False
        requested_assets = []

        for l in self.lines:
            requested_assets.append(l.entity_asset_id.id)

        if len(requested_assets) > 0:
            self.domain_entity_assets = requested_assets
    
    @api.onchange('type', 'partner_id', 'company_id')
    def _onchange_subject(self):
        for rec in self:
            rec.lines = [fields.Command.clear()]
    
    @api.depends('type', 'partner_id', 'company_id')
    def _compute_domain_subscription_ids(self):
        for after_sale in self:
            after_sale.domain_subscription_ids = False
            available_lines = self.env['subscription.line'].search([
                ('company_id', '=', after_sale.company_id.id),
                ('contract_id', '=', after_sale.contract_id.id),
                ('partner_id', '=', after_sale.partner_id.id),
                ('start_date', '!=', False),
                ('end_date', '=', False),
            ])
            lines = self.env['subscription.line'].browse([])
            for x in available_lines:
                if hasattr(
                    x.current_product_id.product_operation_id, f'{after_sale.type}_operations'
                ) and len(getattr(x.current_product_id.product_operation_id, f'{after_sale.type}_operations')) > 0:
                    lines += x
            after_sale.domain_subscription_ids = lines

    
    def action_review(self):
        self.state = 'review'

    def action_draft(self):
        self.state = 'draft'

    def action_request(self):
        if self.name != _("New"):
            self._process_request()
            self.state = 'requested'
            return
        
        self.name = self.env['ir.sequence'].next_by_code(
            f'after.sale.order.{self.type}'
        ).replace('{REF}', self.partner_id.get_legal_initial())
        self._process_request()
        self.state = 'requested'
    
    def action_cancelled(self):
        progress_count = self.env['work.order.line'].search_count([
            ('after_sale_order_id', '=', self.id),
            ('work_order_id.state', 'not in', ['canceled'])
        ])
        # Need to strict check if some operation already processed
        if progress_count > 0:
            raise UserError("Can't cancel, some task in work order already planned or done")

        self.state = 'cancelled'
        outstanding = self.env['outstanding.work.order'].search([
            ('after_sale_order_id', '=', self.id)
        ])
        if len(outstanding) == 0:
            return
        
        subscription_line_ids = self._get_subscription_line_ids()
        subscription_line_ids.outstanding_work_order = False
        subscription_line_ids.product_operation_line_id = False
        outstanding.unlink()
    
    def action_done(self, quite=False):
        outstandings = self.env['outstanding.work.order'].search([
            ('after_sale_order_id', '=', self.id),
        ])
        is_all_done = True
        for outstanding in outstandings:
            if outstanding.active is False:
                continue
        
            if outstanding.qty_after_sale_unit > 0 or outstanding.qty_recurring > 0:
                is_all_done = False
                if not quite:
                    raise UserError("Can't mark as done, because the outstanding work order isn't complete")
                continue
        
        if is_all_done:
            self.state = 'done'
        
    def _get_subscription_line_ids(self):
        subscription_line_ids = self.env['subscription.line'].browse()
        for l in self.lines:
            for sub_line in l.subscription_line_ids:
                if sub_line.id not in subscription_line_ids.ids:
                    if sub_line.product_type != 'package' and sub_line.product_operation_scope != 'product_unit':
                        continue
                    if sub_line.end_date is not False:
                        continue

                    subscription_line_ids += sub_line
        return subscription_line_ids

    def _process_request(self):
        subscription_line_ids = self._get_subscription_line_ids()
        outsanding_workorder_type = []
        processed_subscriptions = 0
        for sub in subscription_line_ids:
            operation = sub.product_id.product_operation_id
            if len(operation) == 0:
                continue

            product_operation = operation.get_next_operation(self.type)
            if len(sub.product_operation_line_id) == 1:
                continue

            if sub.product_operation_scope != product_operation.scope:
                continue

            if sub.outstanding_work_order == product_operation.work_order_type:
                continue

            if product_operation.work_order_type not in outsanding_workorder_type:
                outsanding_workorder_type.append(product_operation.work_order_type)

            processed_subscriptions += 1
            sub.outstanding_work_order = product_operation.work_order_type
            sub.product_operation_line_id = product_operation.id

        if processed_subscriptions == 0:
            raise UserError("Nothing to request / your request already proceed before.")
        
        for type in outsanding_workorder_type:
            is_exist = self.env['outstanding.work.order'].search_count([
                ('after_sale_order_id', '=', self.id)
            ]) > 0
            if is_exist:
                continue

            outstanding_workorder = {
                'company_id': self.company_id.id,
                'partner_id': self.partner_id.id,
                'contract_id': self.contract_id.id,
                'after_sale_order_id': self.id,
                'outstanding_work_order': type,
            }
            self.env['outstanding.work.order'].create(outstanding_workorder)
    
    @api.depends('allowed_company')
    def _compute_company_id(self):
        for rec in self:
            if len(rec.company_id) == 1:
                continue
            rec.company_id = rec.allowed_company[0]

    @api.depends('user_id')
    def _compute_multi_company(self):
        for rec in self:
            rec.allowed_company = self.env.user.company_ids.filtered(lambda x: x.id in self._context.get('allowed_company_ids'))
            rec.is_company_visible = len(rec.allowed_company) > 1
